import { isDemo } from './lib/supabase';
import { AuthApp } from './features/auth/AuthApp';
import { BlockRoot } from './features/block/BlockRoot';

// La home (y /hyrox) venden y entregan el bloque "Hyrox — Mejorar Estaciones"
// (compra única vía Lemon Squeezy, ver src/features/block). El motor de
// programación adaptativa diaria por suscripción (Stripe + Supabase) sigue
// intacto en /programa-adaptativo por si se retoma más adelante.
export default function App() {
  const path = window.location.pathname;
  const isAdaptiveEngine = path.startsWith('/programa-adaptativo');

  if (!isAdaptiveEngine) return <BlockRoot />;

  if (isDemo) return <p style={{ color: 'white', padding: 20 }}>Faltan las variables de Supabase (.env)</p>;
  return <AuthApp />;
}
