import { isDemo } from './lib/supabase';
import { AuthApp } from './features/auth/AuthApp';
import { BlockRoot } from './features/block/BlockRoot';
import { ProgramLandingRoot } from './features/block/ProgramLandingRoot';
import { PROGRAM_DEFS } from './features/block/data';

// La home (y /hyrox) venden y entregan el bloque "Hyrox — Mejorar Estaciones"
// (compra única vía Lemon Squeezy, ver src/features/block). El motor de
// programación adaptativa diaria por suscripción (Stripe + Supabase) sigue
// intacto en /programa-adaptativo por si se retoma más adelante.
//
// /programas/<id> es la página de producto individual de cada programa
// (pensada para tráfico directo desde Instagram) — ver ProgramLanding.tsx.
export default function App() {
  const path = window.location.pathname;
  const isAdaptiveEngine = path.startsWith('/programa-adaptativo');
  const programMatch = path.match(/^\/programas\/([a-z0-9-]+)\/?$/);

  if (programMatch && PROGRAM_DEFS[programMatch[1]]) {
    return <ProgramLandingRoot programId={programMatch[1]} />;
  }

  if (!isAdaptiveEngine) return <BlockRoot />;

  if (isDemo) return <p style={{ color: 'white', padding: 20 }}>Faltan las variables de Supabase (.env)</p>;
  return <AuthApp />;
}
