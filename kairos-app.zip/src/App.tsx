import { lazy, Suspense } from 'react';
import { BlockRoot } from './features/block/BlockRoot';
import { ProgramLandingRoot } from './features/block/ProgramLandingRoot';
import { EnlacesPage } from './features/block/EnlacesPage';
import { PROGRAM_DEFS } from './features/block/data';

// La home (y /hyrox) venden y entregan el bloque "Hyrox — Mejorar Estaciones"
// (compra única vía Lemon Squeezy, ver src/features/block). El motor de
// programación adaptativa diaria por suscripción (Stripe + Supabase) sigue
// intacto en /programa-adaptativo por si se retoma más adelante — pero se
// carga en diferido (React.lazy) para que su peso (Supabase incluido) no
// penalice la home ni las páginas de producto.
//
// /programas/<id> es la página de producto individual de cada programa
// (pensada para tráfico directo desde Instagram) — ver ProgramLanding.tsx.
const AdaptiveApp = lazy(() => import('./features/auth/AdaptiveApp'));

export default function App() {
  const path = window.location.pathname;
  const isAdaptiveEngine = path.startsWith('/programa-adaptativo');
  const programMatch = path.match(/^\/programas\/([a-z0-9-]+)\/?$/);

  if (programMatch && PROGRAM_DEFS[programMatch[1]]) {
    return <ProgramLandingRoot programId={programMatch[1]} />;
  }

  // Link-in-bio de Instagram: /enlaces (visitas y clics medidos en Analytics).
  if (path === '/enlaces' || path === '/enlaces/') {
    return <EnlacesPage />;
  }

  if (!isAdaptiveEngine) return <BlockRoot />;

  return (
    <Suspense fallback={<p style={{ color: 'white', padding: 20 }}>Cargando…</p>}>
      <AdaptiveApp />
    </Suspense>
  );
}
