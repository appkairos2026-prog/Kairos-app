// Punto de entrada del motor adaptativo antiguo (/programa-adaptativo).
// Existe como módulo separado para que App.tsx pueda cargarlo con
// React.lazy: así todo Supabase y las pantallas legacy quedan en un chunk
// aparte que el 99% de visitantes (home y páginas de producto) nunca
// descarga — el bundle principal baja ~la mitad de peso.
import { isDemo } from '../../lib/supabase';
import { AuthApp } from './AuthApp';

export default function AdaptiveApp() {
  if (isDemo) return <p style={{ color: 'white', padding: 20 }}>Faltan las variables de Supabase (.env)</p>;
  return <AuthApp />;
}
