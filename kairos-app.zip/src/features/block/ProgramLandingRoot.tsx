import { useEffect } from 'react';
import './block.css';
import { ProgramLanding } from './ProgramLanding';

interface Props {
  programId: string;
}

// Página de producto independiente (una por programa), pensada para recibir
// tráfico directo (p. ej. desde el bio de Instagram) sin pasar por la home.
// No gestiona estado de desbloqueo propio: si el visitante ya tiene un
// código, se le enlaza de vuelta a la home, que es donde vive ese flujo.
export function ProgramLandingRoot({ programId }: Props) {
  useEffect(() => {
    // Si Lemon Squeezy redirige de vuelta aquí tras el pago con
    // ?license_key=... en la URL (en vez de a la home), no podemos activar
    // el código en esta página — el flujo de activación vive en la home.
    // En lugar de dejar al comprador viendo la landing de venta como si no
    // hubiera comprado nada, le mandamos a la home con el mismo query string
    // para que se active automáticamente, sin que tenga que copiar el
    // código a mano.
    const params = new URLSearchParams(window.location.search);
    if (params.get('license_key')) {
      window.location.replace('/' + window.location.search);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="kb-root">
      <ProgramLanding programId={programId} />
    </div>
  );
}
