import './block.css';
import { ProgramLanding } from './ProgramLanding';

interface Props {
  programId: string;
}

// Página de producto independiente (una por programa), pensada para recibir
// tráfico directo (p. ej. desde el bio de Instagram) sin pasar por la home.
// No gestiona estado de desbloqueo propio: si el visitante ya tiene un
// código, se le enlaza de vuelta a la home, que es donde vive ese flujo.
export function ProgramLandingRoot({ programId }: Props) {
  return (
    <div className="kb-root">
      <ProgramLanding programId={programId} />
    </div>
  );
}
