import { useEffect, useMemo } from 'react';
import { PROGRAM_DEFS, PROGRAM_PRODUCTS, PROGRAM_EXTRAS, PROGRAM_ORDER, sessionsFor } from './data';
import { PROGRAM_LANDING_COPY, UNIVERSAL_FAQ } from './landingContent';

interface Props {
  programId: string;
}

export function ProgramLanding({ programId }: Props) {
  const def = PROGRAM_DEFS[programId];
  const product = PROGRAM_PRODUCTS[programId];
  const extras = PROGRAM_EXTRAS[programId];
  const copy = PROGRAM_LANDING_COPY[programId];

  useEffect(() => {
    document.title = def ? `${def.name} — Kairos` : 'Kairos';
  }, [def]);

  const weeks = useMemo(() => {
    if (!def) return [];
    const sessions = sessionsFor(programId);
    const seen = new Set<number>();
    const out: { week: number; phaseLabel: string; intro: string }[] = [];
    for (const s of sessions) {
      if (seen.has(s.week)) continue;
      seen.add(s.week);
      out.push({ week: s.week, phaseLabel: s.phaseLabel, intro: s.weekIntro });
    }
    return out;
  }, [def, programId]);

  if (!def || !product || !copy) {
    return (
      <div className="kb-app">
        <div className="kb-content">
          <p>Programa no encontrado. <a href="/">Volver a la home →</a></p>
        </div>
      </div>
    );
  }

  const shortName = def.name.replace(/^(Hyrox|CrossFit) — /, '');
  const faqItems = [copy.specificFaq, ...UNIVERSAL_FAQ];
  const otherPrograms = PROGRAM_ORDER.filter((pid) => pid !== programId);

  return (
    <div className="kb-app">
      <div className="kb-content" style={{ padding: 0 }}>

        {/* breadcrumb ligero */}
        <div className="kb-program-breadcrumb">
          <a href="/">← Ver los 7 programas</a>
        </div>

        {/* ---------- HERO: qué conseguiré + precio + comprar ---------- */}
        <section className="kb-land-hero kb-program-hero">
          <div className="kb-land-mark">{def.discipline === 'hyrox' ? 'Hyrox' : 'CrossFit'} · Kairos</div>
          <h1 className="kb-display kb-land-title kb-program-hero-title">{copy.resultTitle}</h1>
          <p className="kb-land-sub">{product.pitch}</p>
          <div className="kb-program-hero-price">
            <span className="kb-price-tag kb-price-tag-lg kb-mono">{product.priceLabel}</span>
            <span className="kb-muted kb-program-hero-priceNote">pago único</span>
          </div>
          <div className="kb-land-cta">
            <a className="kb-btn kb-btn-primary" style={{ textDecoration: 'none' }} href={product.checkoutUrl}>
              Comprar programa
            </a>
          </div>
          <p className="kb-faint kb-program-hero-meta">{def.weeks} semanas · 3 sesiones/semana</p>
        </section>

        {/* ---------- PARA QUIÉN ES ---------- */}
        <section className="kb-land-section" style={{ paddingTop: 0 }}>
          <h2 className="kb-eyebrow kb-eyebrow-heading">Para quién es</h2>
          <p className="kb-program-forwhom">{copy.forWhom}</p>
        </section>

        {/* ---------- CÓMO FUNCIONA ---------- */}
        <section className="kb-land-section" style={{ paddingTop: 0 }}>
          <div className="kb-eyebrow">Cómo funciona</div>
          <h2 className="kb-display">3 pasos, sin complicarlo</h2>
          <ol className="kb-steps">
            <li className="kb-step">
              <span className="kb-step-num kb-mono">1</span>
              <div>
                <h3 className="kb-step-title">Compras el programa</h3>
                <p className="kb-muted kb-step-text">Pago único a través de Lemon Squeezy, {product.priceLabel}.</p>
              </div>
            </li>
            <li className="kb-step">
              <span className="kb-step-num kb-mono">2</span>
              <div>
                <h3 className="kb-step-title">Activas tu código</h3>
                <p className="kb-muted kb-step-text">Recibes un código tras la compra y lo activas en la web al momento.</p>
              </div>
            </li>
            <li className="kb-step">
              <span className="kb-step-num kb-mono">3</span>
              <div>
                <h3 className="kb-step-title">Entrenas y registras tu progreso</h3>
                <p className="kb-muted kb-step-text">Sesión a sesión, marcando tu RPE y tu progreso semana a semana, sin conexión.</p>
              </div>
            </li>
          </ol>
        </section>

        {/* ---------- ESTRUCTURA DEL PROGRAMA ---------- */}
        <section className="kb-land-section" style={{ paddingTop: 0 }}>
          <div className="kb-eyebrow">Cómo está estructurado</div>
          <h2 className="kb-display">{def.weeks} semanas, con un plan por fase</h2>
          <div className="kb-week-grid">
            {weeks.map((w) => (
              <div className="kb-week-row" key={w.week}>
                <div className="kb-week-num kb-mono">{w.week}</div>
                <div>
                  <div className="kb-week-phase">{w.phaseLabel}</div>
                  <p className="kb-muted kb-week-intro">{w.intro}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* ---------- QUÉ INCLUYE ---------- */}
        <section className="kb-land-section" style={{ paddingTop: 0 }}>
          <div className="kb-eyebrow">Qué incluye</div>
          <h2 className="kb-display">Todo lo que necesitas para entrenarlo</h2>
          <div className="kb-benefit-grid">
            <div className="kb-benefit-card">
              <h3 className="kb-benefit-title">{def.weeks} semanas programadas sesión a sesión</h3>
              <p className="kb-muted kb-benefit-text">Cada sesión trae sus bloques (calentamiento, técnica, fuerza o metcon según el día) con series, repeticiones y notas de coach.</p>
            </div>
            {extras?.warmupStandard?.length ? (
              <div className="kb-benefit-card">
                <h3 className="kb-benefit-title">Calentamiento estándar del programa</h3>
                <p className="kb-muted kb-benefit-text">{extras.warmupNote}</p>
              </div>
            ) : null}
            {def.hasTestProtocol ? (
              <div className="kb-benefit-card">
                <h3 className="kb-benefit-title">Test inicial y test final</h3>
                <p className="kb-muted kb-benefit-text">Mides tus números al empezar y los vuelves a medir al terminar, con la comparación hecha automáticamente en la app.</p>
              </div>
            ) : null}
            {extras?.substitutions?.length ? (
              <div className="kb-benefit-card">
                <h3 className="kb-benefit-title">Sustituciones si falta material</h3>
                <p className="kb-muted kb-benefit-text">Alternativas ya previstas para las estaciones o el material más específico del programa.</p>
              </div>
            ) : null}
            <div className="kb-benefit-card">
              <h3 className="kb-benefit-title">Seguimiento de tu progreso</h3>
              <p className="kb-muted kb-benefit-text">Marcas cada sesión como completada y anotas tu RPE. Todo queda guardado en tu móvil.</p>
            </div>
            <div className="kb-benefit-card">
              <h3 className="kb-benefit-title">Acceso sin conexión</h3>
              <p className="kb-muted kb-benefit-text">Una vez activado, entrenas sin necesidad de internet. Puedes añadir la app a la pantalla de inicio de tu móvil.</p>
            </div>
          </div>
        </section>

        {/* ---------- PRECIO + CTA ---------- */}
        <section className="kb-land-section" style={{ paddingTop: 0 }}>
          <div className="kb-card kb-program-price-card">
            <div className="kb-eyebrow">Precio</div>
            <div className="kb-program-price-row">
              <span className="kb-price-tag kb-price-tag-xl kb-mono">{product.priceLabel}</span>
              <span className="kb-muted">pago único · sin suscripción</span>
            </div>
            <a className="kb-btn kb-btn-primary" style={{ textDecoration: 'none', marginTop: 14 }} href={product.checkoutUrl}>
              Comprar programa
            </a>
            <a className="kb-program-detail-link" href="/?activate=1">¿Ya tienes tu código? Actívalo aquí →</a>
          </div>
        </section>

        {/* ---------- CONFIANZA ---------- */}
        <section className="kb-land-section" style={{ paddingTop: 0 }}>
          <div className="kb-eyebrow">Por qué confiar</div>
          <h2 className="kb-display">Nada que no puedas comprobar tú</h2>
          <div className="kb-trust-grid">
            <div className="kb-trust-item">
              <h3 className="kb-trust-title">Pago único y seguro</h3>
              <p className="kb-muted kb-trust-text">El cobro lo procesa Lemon Squeezy. Nosotros no gestionamos ni guardamos tus datos de pago.</p>
            </div>
            <div className="kb-trust-item">
              <h3 className="kb-trust-title">Activación inmediata</h3>
              <p className="kb-muted kb-trust-text">El código llega justo después de la compra y desbloquea el programa al momento.</p>
            </div>
            <div className="kb-trust-item">
              <h3 className="kb-trust-title">Sin conexión</h3>
              <p className="kb-muted kb-trust-text">Entrena aunque no tengas datos o wifi: una vez activado, el programa se queda guardado en tu móvil.</p>
            </div>
          </div>
        </section>

        {/* ---------- FAQ ---------- */}
        <section className="kb-land-section" style={{ paddingTop: 0 }}>
          <div className="kb-eyebrow">Preguntas frecuentes</div>
          <h2 className="kb-display">Antes de comprar</h2>
          <div className="kb-faq-list">
            {faqItems.map((f) => (
              <details className="kb-faq-item" key={f.q}>
                <summary>{f.q}</summary>
                <p className="kb-muted">{f.a}</p>
              </details>
            ))}
          </div>
        </section>

        {/* ---------- CTA FINAL ---------- */}
        <section className="kb-land-section kb-land-final-cta">
          <div className="kb-eyebrow">Empieza ahora</div>
          <h2 className="kb-display">{shortName}</h2>
          <p className="kb-muted">{def.weeks} semanas · {product.priceLabel} · pago único.</p>
          <div className="kb-land-cta">
            <a className="kb-btn kb-btn-primary" style={{ textDecoration: 'none' }} href={product.checkoutUrl}>
              Comprar programa
            </a>
          </div>
        </section>

        {/* ---------- otros programas ---------- */}
        <section className="kb-land-section" style={{ paddingTop: 0 }}>
          <div className="kb-eyebrow">Otros objetivos</div>
          <div className="kb-program-crosslinks">
            {otherPrograms.map((pid) => (
              <a key={pid} className="kb-program-crosslink" href={`/programas/${pid}`}>
                {PROGRAM_DEFS[pid].name.replace(/^(Hyrox|CrossFit) — /, '')}
                <span className="kb-mono">{PROGRAM_PRODUCTS[pid].priceLabel}</span>
              </a>
            ))}
          </div>
        </section>

        <footer className="kb-land-footer">
          <div className="kb-wordmark kb-display" style={{ fontSize: 16 }}>KAI<span>ROS</span></div>
          <p className="kb-faint" style={{ fontSize: 11 }}>Entrena donde quieras, sin conexión.</p>
          <p className="kb-faint" style={{ fontSize: 10, lineHeight: 1.6, maxWidth: '42ch', margin: '10px auto 0' }}>
            HYROX® y CrossFit® son marcas registradas de sus respectivos titulares.
            Kairos no está afiliado, patrocinado ni avalado por ellas: se mencionan
            únicamente para describir la finalidad de los programas.
          </p>
        </footer>
      </div>
    </div>
  );
}
