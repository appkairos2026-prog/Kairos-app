import { useState } from 'react';
import { formatMetricValue, type TestComparisonResult } from './state';

interface BarPoint { v: number; label: string }

export function WeeklyBarChart({ values }: { values: BarPoint[] }) {
  const [caption, setCaption] = useState('Toca una barra para ver el detalle.');
  const w = 380, h = 110, pad = 18, n = values.length;
  const max = Math.max(1, ...values.map((v) => v.v));
  const bw = ((w - pad * 2) / n) * 0.6;
  const gap = (w - pad * 2) / n;

  return (
    <div className="kb-card">
      <div className="kb-eyebrow" style={{ marginBottom: 10 }}>Adherencia por semana</div>
      <svg viewBox={`0 0 ${w} ${h}`} width="100%" role="img" aria-label="Adherencia semanal">
        <line x1={pad} y1={h - 24} x2={w - pad} y2={h - 24} stroke="var(--kb-line)" strokeWidth={1} />
        {values.map((pt, i) => {
          const x = pad + gap * i + (gap - bw) / 2;
          const bh = Math.max(2, (pt.v / max) * (h - 30));
          const y = h - 24 - bh;
          return (
            <g key={i}>
              <rect x={x} y={y} width={bw} height={bh} rx={3} fill="var(--kb-accent)" opacity={i === n - 1 ? 1 : 0.55}
                tabIndex={0} style={{ cursor: 'pointer' }}
                onClick={() => setCaption(`${pt.label}: ${pt.v}% de adherencia.`)} />
              <text x={x + bw / 2} y={h - 8} fontSize={8} fill="var(--kb-ink-faint)" textAnchor="middle" fontFamily="IBM Plex Mono, monospace">{pt.label}</text>
            </g>
          );
        })}
      </svg>
      <div className="kb-chart-caption">{caption}</div>
    </div>
  );
}

export function TestComparisonCard({ result }: { result: TestComparisonResult }) {
  return (
    <div className="kb-card">
      <div className="kb-eyebrow" style={{ marginBottom: 10 }}>Test inicial vs. test final</div>
      {result.status === 'need-initial' && (
        <div className="kb-empty">Haz el test inicial (Semana 1 · Día 1) para empezar a medir tu progreso.</div>
      )}
      {result.status === 'need-final' && (
        <div className="kb-empty">Test inicial registrado. Completa el test final en la Semana 8 para ver la comparativa.</div>
      )}
      {result.status === 'done' && result.rows.map((r, i) => {
        const initTxt = r.initial != null ? formatMetricValue(r.initial, r.category) : '—';
        const finalTxt = r.final != null ? formatMetricValue(r.final, r.category) : '—';
        let deltaTxt = '—';
        let deltaCls = 'kb-pill-neutral';
        if (r.delta != null) {
          // Para tiempo, menos es mejor. Para carga o reps, más es mejor.
          const improved = r.category === 'time' ? r.delta < 0 : r.delta > 0;
          const sign = r.delta === 0 ? '=' : r.delta > 0 ? '+' : '-';
          deltaTxt = sign + formatMetricValue(Math.abs(r.delta), r.category);
          deltaCls = r.delta === 0 ? 'kb-pill-neutral' : improved ? 'kb-pill-good' : 'kb-pill-critical';
        }
        return (
          <div className="kb-kv" key={i}>
            <span className="kb-k">{r.label}</span>
            <span className="kb-v" style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
              {initTxt} → {finalTxt} <span className={`kb-pill ${deltaCls}`}>{deltaTxt}</span>
            </span>
          </div>
        );
      })}
    </div>
  );
}
