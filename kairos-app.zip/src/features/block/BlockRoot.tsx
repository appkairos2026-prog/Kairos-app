import { useEffect, useState } from 'react';
import './block.css';
import { loadState, saveState } from './state';
import type { BlockAppState, UnlockInfo } from './types';
import { BlockGate } from './BlockGate';
import { BlockApp } from './BlockApp';

export function BlockRoot() {
  const [state, setState] = useState<BlockAppState>(() => loadState());
  // Programa que se acaba de desbloquear en ESTA sesión de navegador (no se
  // guarda en el estado persistido): sirve solo para mostrar una
  // confirmación de "compra activada" una vez, justo después del pago o de
  // introducir el código. Un refresco de página la hace desaparecer sola.
  const [justUnlocked, setJustUnlocked] = useState<string | null>(null);

  useEffect(() => {
    saveState(state);
  }, [state]);

  useEffect(() => {
    document.title = 'Kairos — Entrenamiento por objetivos';
  }, []);

  const update = (updater: (s: BlockAppState) => BlockAppState) => setState((s) => updater(s));

  const unlocked = Object.keys(state.unlocked).length > 0;

  const onUnlocked = (programId: string, info: UnlockInfo) => {
    setState((s) => ({
      ...s,
      unlocked: { ...s.unlocked, [programId]: info },
      activeProgram: programId,
    }));
    setJustUnlocked(programId);
  };

  return (
    <div className="kb-root" data-kb-theme={state.theme !== 'auto' ? state.theme : undefined}>
      {unlocked
        ? <BlockApp state={state} update={update} justUnlocked={justUnlocked} onDismissJustUnlocked={() => setJustUnlocked(null)} />
        : <BlockGate onUnlocked={onUnlocked} />}
    </div>
  );
}
