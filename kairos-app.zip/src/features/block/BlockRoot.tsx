import { useEffect, useState } from 'react';
import './block.css';
import { loadState, saveState } from './state';
import type { BlockAppState, UnlockInfo } from './types';
import { BlockGate } from './BlockGate';
import { BlockApp } from './BlockApp';

export function BlockRoot() {
  const [state, setState] = useState<BlockAppState>(() => loadState());

  useEffect(() => {
    saveState(state);
  }, [state]);

  useEffect(() => {
    document.title = 'Kairos — Entrenamiento por objetivos · Korriban Club';
  }, []);

  const update = (updater: (s: BlockAppState) => BlockAppState) => setState((s) => updater(s));

  const unlocked = Object.keys(state.unlocked).length > 0;

  const onUnlocked = (programId: string, info: UnlockInfo) => {
    setState((s) => ({
      ...s,
      unlocked: { ...s.unlocked, [programId]: info },
      activeProgram: programId,
    }));
  };

  return (
    <div className="kb-root" data-kb-theme={state.theme !== 'auto' ? state.theme : undefined}>
      {unlocked ? <BlockApp state={state} update={update} /> : <BlockGate onUnlocked={onUnlocked} />}
    </div>
  );
}
