// Tipos del "bloque" — producto de compra única (8 semanas), distinto
// del motor de programación adaptativa diaria (src/core).

export type BlockDiscipline = 'hyrox' | 'crossfit';
export type MetricCategory = 'reps' | 'time' | 'load';

export interface ProgramBlockLine {
  letter: string;
  title: string;
  lines: string[];
  note?: string | null;
}

export interface FocusItem {
  name: string;
  category: MetricCategory;
}

export interface ProgramDay {
  heading: string;
  subtitle: string;
  isTest?: boolean;
  focus?: FocusItem[] | null;
  blocks: ProgramBlockLine[];
}

export interface WeekMeta {
  phase: string;
  phaseLabel: string;
  intro: string;
}

export interface TestFieldDef {
  key: string;
  label: string;
  placeholder: string;
}

export interface TestRowDef {
  label: string;
  key: string;
  category: MetricCategory;
}

export interface ProgramDef {
  id: string;
  name: string;
  short: string;
  discipline: BlockDiscipline;
  weeks: number;
  /** día ISO (1=lunes...6=sábado) de cada sesión de la semana, en orden */
  days: number[];
  hasTestProtocol?: boolean;
  /** Campos del formulario de test (solo si hasTestProtocol) */
  testFields?: TestFieldDef[];
  /** Filas a comparar en test inicial vs. final (solo si hasTestProtocol) */
  testRows?: TestRowDef[];
}

export interface Session {
  week: number;
  slot: number;
  weekdayIso: number;
  phase: string;
  phaseLabel: string;
  weekIntro: string;
  heading: string;
  subtitle: string;
  blocks: ProgramBlockLine[];
  isTest: boolean;
  focus: FocusItem[] | null;
  warmupNote: string;
  key: string;
}

export interface FocusLogValue {
  kg?: string;
  reps?: string;
  time?: string;
}

export interface BlockLog {
  completed: boolean;
  completedAt?: string;
  values?: Record<string, FocusLogValue> | Record<string, string>;
  rpe?: number | null;
}

export interface UnlockInfo {
  activatedAt: string;
  licenseKey?: string;
  instanceId?: string;
  source?: 'demo' | 'lemonsqueezy' | 'coach';
}

export interface BlockAppState {
  unlocked: Record<string, UnlockInfo>;
  activeProgram: string | null;
  logs: Record<string, Record<string, BlockLog>>;
  theme: 'auto' | 'light' | 'dark';
  hideInstallHint: boolean;
}
