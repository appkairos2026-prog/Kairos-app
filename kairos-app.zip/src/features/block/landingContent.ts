// Copy específica de cada página de producto (ProgramLanding). Todo lo que
// hay aquí está redactado a partir de contenido real que ya existe en
// data.ts (el pitch del programa, la semana 1, los test protocolados, las
// fases de cada bloque) — no se inventan resultados, plazos ni requisitos
// que no estén ya reflejados en la programación real.

export interface ProgramLandingCopy {
  /** Titular de la página, orientado al resultado concreto del programa. */
  resultTitle: string;
  /** A quién está pensado el programa (basado en lo que exige/mide la semana 1). */
  forWhom: string;
  /** Una pregunta y respuesta específica de este programa para la FAQ. */
  specificFaq: { q: string; a: string };
}

export const PROGRAM_LANDING_COPY: Record<string, ProgramLandingCopy> = {
  hyrox8: {
    resultTitle: 'Baja tus tiempos en las estaciones de Hyrox',
    forWhom: 'Para quien ya entrena Hyrox o CrossFit orientado a Hyrox y quiere bajar tiempos concretos en sled push, sled pull, ski erg y wall balls — no es un programa de acondicionamiento general.',
    specificFaq: {
      q: '¿Necesito ya entrenar Hyrox o CrossFit?',
      a: 'Sí. Es un programa específico de estaciones (sled, ski, wall balls), pensado para quien ya entrena y quiere bajar tiempos concretos en esos gestos, no para empezar desde cero.',
    },
  },
  'hyrox-carrera': {
    resultTitle: 'Corre mejor con las piernas ya cargadas',
    forWhom: 'Para quien hace Hyrox y nota que su ritmo de carrera se cae cuando las piernas ya vienen fatigadas de la estación anterior — la habilidad más específica y menos entrenada de la carrera.',
    specificFaq: {
      q: '¿Necesito ser corredor para hacer este programa?',
      a: 'No hace falta ser corredor. El programa empieza con tres semanas de base aeróbica y técnica antes de entrar en la parte específica de correr con las piernas cargadas.',
    },
  },
  'cf-fuerza': {
    resultTitle: 'Sube tu fuerza real en los cuatro básicos',
    forWhom: 'Para quien entrena CrossFit y quiere una progresión de fuerza estructurada en back squat, front squat, peso muerto y press militar, con su 1RM medido al empezar y al terminar.',
    specificFaq: {
      q: '¿Necesito saber ya mi 1RM en los cuatro básicos?',
      a: 'No. El programa empieza con un test para medir tu 1RM real en los cuatro movimientos antes de construir la progresión sobre esos números.',
    },
  },
  'cf-primera-dominada': {
    resultTitle: 'Consigue tu primera dominada estricta',
    forWhom: 'Para quien todavía no puede hacer ninguna dominada estricta y quiere una progresión por bandas, paso a paso, hasta conseguirla.',
    specificFaq: {
      q: '¿Necesito poder hacer ya alguna dominada?',
      a: 'No. El programa empieza midiendo cuánto aguantas colgado (dead hang) y con la asistencia de banda más alta, no con dominadas.',
    },
  },
  'cf-gim-nivel1': {
    resultTitle: 'Encadena dominadas y toes-to-bar con kip',
    forWhom: 'Para quien ya tiene dominadas o kipping sueltos y quiere automatizar el balanceo (kip) para encadenar dominadas y toes-to-bar sin soltarse de la barra.',
    specificFaq: {
      q: '¿Necesito ya tener el kip automatizado?',
      a: 'No. El programa empieza por la técnica del balanceo (kip swing) desde cero, antes de sumar repeticiones encadenadas.',
    },
  },
  'cf-gim-nivel2': {
    resultTitle: 'Consigue tu primer bar muscle-up',
    forWhom: 'Para quien ya encadena chest-to-bar seguidas y quiere dar el salto a su primer bar muscle-up con una transición asistida por banda que se va afinando semana a semana.',
    specificFaq: {
      q: '¿Necesito ya tener chest-to-bar?',
      a: 'Sí. El programa empieza midiendo cuántas chest-to-bar seguidas consigues, así que necesitas tenerlas ya antes de trabajar la transición del muscle-up.',
    },
  },
  'cf-anillas-rmu': {
    resultTitle: 'Consigue tu ring muscle-up',
    forWhom: 'Para quien ya tiene una base de fondos y dominadas en anillas y quiere trabajar el falso agarre y la transición asistida hasta conseguir el ring muscle-up — el movimiento con más exigencia de hombro y muñeca del catálogo.',
    specificFaq: {
      q: '¿Necesito ya tener fondos y dominadas en anillas?',
      a: 'Sí. La primera semana evalúa tu soporte, tus fondos y tu primer contacto con el falso agarre, así que conviene llegar con esa base ya construida.',
    },
  },
};
