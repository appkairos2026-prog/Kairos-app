// Copy específica de cada página de producto (ProgramLanding). Todo lo que
// hay aquí está redactado a partir de contenido real que ya existe en
// data.ts (el pitch del programa, la semana 1, los test protocolados, las
// fases de cada bloque) — no se inventan resultados, plazos ni requisitos
// que no estén ya reflejados en la programación real.

export interface FaqItem {
  q: string;
  a: string;
}

// FAQ de la home. Única fuente de verdad: la usan tanto BlockGate (contenido
// visible) como el script de SEO (schema.org/FAQPage), así que el markup
// estructurado nunca puede desincronizarse del texto que ve la persona.
export const HOME_FAQ: FaqItem[] = [
  {
    q: '¿Qué recibo exactamente al comprar?',
    a: 'Un código de activación. Lo introduces en esta misma web (o se activa solo si vuelves desde el enlace de compra) y tu programa se desbloquea al momento.',
  },
  {
    q: '¿Es una suscripción?',
    a: 'No. Es un pago único por programa. No hay cuotas mensuales ni renovaciones automáticas.',
  },
  {
    q: '¿Necesito internet para entrenar?',
    a: 'Solo la primera vez, para activar el código. Después, el programa funciona sin conexión desde tu móvil.',
  },
  {
    q: '¿Cuánto dura cada programa y cuántos días entreno?',
    a: 'Entre 6 y 8 semanas según el programa, con 3 sesiones por semana. Cada programa indica su duración exacta antes de comprar.',
  },
  {
    q: '¿Puedo comprar más de un programa?',
    a: 'Sí. Puedes tener varios activos a la vez y cambiar entre ellos desde Ajustes.',
  },
  {
    q: '¿Puedo ver mi progreso?',
    a: 'Sí. Marcas cada sesión como completada, anotas tu RPE y, en los programas con test inicial y final, comparas los resultados.',
  },
];

// FAQ genérica de cualquier página de producto (además de la pregunta
// específica de cada programa, ver PROGRAM_LANDING_COPY más abajo).
export const UNIVERSAL_FAQ: FaqItem[] = [
  {
    q: '¿Qué recibo exactamente al comprar?',
    a: 'Un código de activación. Lo introduces en la web (o se activa solo si vuelves desde el enlace de compra) y el programa se desbloquea al momento.',
  },
  {
    q: '¿Es una suscripción?',
    a: 'No. Es un pago único por este programa. No hay cuotas mensuales ni renovaciones automáticas.',
  },
  {
    q: '¿Necesito internet para entrenar?',
    a: 'Solo la primera vez, para activar el código. Después, el programa funciona sin conexión desde tu móvil.',
  },
  {
    q: '¿Puedo comprar más de un programa?',
    a: 'Sí. Puedes tener varios activos a la vez y cambiar entre ellos desde Ajustes, cada uno con su propio progreso.',
  },
];

export interface ProgramLandingCopy {
  /** Titular de la página, orientado al resultado concreto del programa. */
  resultTitle: string;
  /** A quién está pensado el programa (basado en lo que exige/mide la semana 1). */
  forWhom: string;
  /** Una pregunta y respuesta específica de este programa para la FAQ. */
  specificFaq: { q: string; a: string };
}

export const PROGRAM_LANDING_COPY: Record<string, ProgramLandingCopy> = {
  hyrox8: {
    resultTitle: 'Baja tus tiempos en las estaciones de Hyrox',
    forWhom: 'Para quien ya entrena Hyrox o CrossFit orientado a Hyrox y quiere bajar tiempos concretos en sled push, sled pull, ski erg y wall balls — no es un programa de acondicionamiento general.',
    specificFaq: {
      q: '¿Necesito ya entrenar Hyrox o CrossFit?',
      a: 'Sí. Es un programa específico de estaciones (sled, ski, wall balls), pensado para quien ya entrena y quiere bajar tiempos concretos en esos gestos, no para empezar desde cero.',
    },
  },
  'hyrox-carrera': {
    resultTitle: 'Corre mejor con las piernas ya cargadas',
    forWhom: 'Para quien hace Hyrox y nota que su ritmo de carrera se cae cuando las piernas ya vienen fatigadas de la estación anterior — la habilidad más específica y menos entrenada de la carrera.',
    specificFaq: {
      q: '¿Necesito ser corredor para hacer este programa?',
      a: 'No hace falta ser corredor. El programa empieza con tres semanas de base aeróbica y técnica antes de entrar en la parte específica de correr con las piernas cargadas.',
    },
  },
  'cf-fuerza': {
    resultTitle: 'Sube tu fuerza real en los cuatro básicos',
    forWhom: 'Para quien entrena CrossFit y quiere una progresión de fuerza estructurada en back squat, front squat, peso muerto y press militar, con su 1RM medido al empezar y al terminar.',
    specificFaq: {
      q: '¿Necesito saber ya mi 1RM en los cuatro básicos?',
      a: 'No. El programa empieza con un test para medir tu 1RM real en los cuatro movimientos antes de construir la progresión sobre esos números.',
    },
  },
  'cf-primera-dominada': {
    resultTitle: 'Consigue tu primera dominada estricta',
    forWhom: 'Para quien todavía no puede hacer ninguna dominada estricta y quiere una progresión por bandas, paso a paso, hasta conseguirla.',
    specificFaq: {
      q: '¿Necesito poder hacer ya alguna dominada?',
      a: 'No. El programa empieza midiendo cuánto aguantas colgado (dead hang) y con la asistencia de banda más alta, no con dominadas.',
    },
  },
  'cf-gim-nivel1': {
    resultTitle: 'Encadena dominadas y toes-to-bar con kip',
    forWhom: 'Para quien ya tiene dominadas o kipping sueltos y quiere automatizar el balanceo (kip) para encadenar dominadas y toes-to-bar sin soltarse de la barra.',
    specificFaq: {
      q: '¿Necesito ya tener el kip automatizado?',
      a: 'No. El programa empieza por la técnica del balanceo (kip swing) desde cero, antes de sumar repeticiones encadenadas.',
    },
  },
  'cf-gim-nivel2': {
    resultTitle: 'Consigue tu primer bar muscle-up',
    forWhom: 'Para quien ya encadena chest-to-bar seguidas y quiere dar el salto a su primer bar muscle-up con una transición asistida por banda que se va afinando semana a semana.',
    specificFaq: {
      q: '¿Necesito ya tener chest-to-bar?',
      a: 'Sí. El programa empieza midiendo cuántas chest-to-bar seguidas consigues, así que necesitas tenerlas ya antes de trabajar la transición del muscle-up.',
    },
  },
  'cf-anillas-rmu': {
    resultTitle: 'Consigue tu ring muscle-up',
    forWhom: 'Para quien ya tiene una base de ring dips y dominadas en anillas y quiere trabajar el false grip y la transición asistida hasta conseguir el ring muscle-up — el movimiento con más exigencia de hombro y muñeca del catálogo.',
    specificFaq: {
      q: '¿Necesito ya tener ring dips y dominadas en anillas?',
      a: 'Sí. La primera semana evalúa tu soporte, tus ring dips y tu primer contacto con el false grip, así que conviene llegar con esa base ya construida.',
    },
  },
};
