import { useState } from 'react';
import type { BlockLog, FocusItem, ProgramDef, Session } from './types';
import { DOW_FULL } from './state';

interface Props {
  def: ProgramDef;
  session: Session;
  dateObj: Date;
  log: BlockLog;
  onSetLog: (patch: Partial<BlockLog>) => void;
}

function todayMidnightLocal(): Date {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
}

export function SessionCard({ def, session, dateObj, log, onSetLog }: Props) {
  const isPast = dateObj < todayMidnightLocal();
  const isToday = dateObj.getTime() === todayMidnightLocal().getTime();

  const [testValues, setTestValues] = useState<Record<string, string>>(
    (log.values as Record<string, string>) || {},
  );
  const [focusValues, setFocusValues] = useState<Record<string, { kg?: string; reps?: string; time?: string }>>(
    (log.values as Record<string, { kg?: string; reps?: string; time?: string }>) || {},
  );

  const statusPill = log.completed
    ? <span className="kb-pill kb-pill-good">✓ Completada</span>
    : isPast
      ? <span className="kb-pill kb-pill-critical">No registrada</span>
      : isToday
        ? <span className="kb-pill kb-pill-accent">Hoy toca</span>
        : <span className="kb-pill kb-pill-neutral">Programada</span>;

  const toggleComplete = () => {
    if (session.isTest) {
      onSetLog({ completed: !log.completed, completedAt: new Date().toISOString(), values: testValues });
    } else {
      onSetLog({ completed: !log.completed, completedAt: new Date().toISOString(), values: focusValues });
    }
  };

  const setFocusField = (idx: number, field: 'kg' | 'reps' | 'time', value: string) => {
    setFocusValues((prev) => ({ ...prev, [idx]: { ...prev[idx], [field]: value } }));
  };

  const focusInputs = (item: FocusItem, idx: number) => {
    const vals = focusValues[idx] || {};
    if (item.category === 'load') {
      return (
        <div className="kb-focus-inputs">
          <input type="number" inputMode="decimal" placeholder="kg" value={vals.kg ?? ''} onChange={(e) => setFocusField(idx, 'kg', e.target.value)} />
          <input type="number" inputMode="numeric" placeholder="reps" value={vals.reps ?? ''} onChange={(e) => setFocusField(idx, 'reps', e.target.value)} />
        </div>
      );
    }
    if (item.category === 'time') {
      return (
        <div className="kb-focus-inputs">
          <input type="text" inputMode="numeric" placeholder="mm:ss" value={vals.time ?? ''} onChange={(e) => setFocusField(idx, 'time', e.target.value)} />
        </div>
      );
    }
    return (
      <div className="kb-focus-inputs">
        <input type="number" inputMode="numeric" placeholder="reps" value={vals.reps ?? ''} onChange={(e) => setFocusField(idx, 'reps', e.target.value)} />
      </div>
    );
  };

  return (
    <div className="kb-card">
      <div className="kb-eyebrow">
        Semana {session.week} de {def.weeks} · {session.phaseLabel} · {DOW_FULL[session.weekdayIso - 1]} {dateObj.getDate()}/{dateObj.getMonth() + 1}
      </div>
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 10, margin: '4px 0 10px' }}>
        <h2 className="kb-display">{session.heading}</h2>
        {statusPill}
      </div>

      {session.subtitle && <p className="kb-muted" style={{ marginTop: -6 }}>{session.subtitle}</p>}
      {session.warmupNote && <p className="kb-faint" style={{ fontSize: 11.5, margin: '2px 0 12px' }}>{session.warmupNote}</p>}

      {session.blocks.map((bl, i) => (
        <div className="kb-block" key={i}>
          <div className="kb-block-head">
            <span className="kb-block-title">{bl.letter ? bl.letter + ' · ' : ''}{bl.title}</span>
          </div>
          <ul className="kb-linelist">
            {bl.lines.map((line, li) => <li key={li}>{line}</li>)}
          </ul>
          {bl.note && <p className="kb-muted" style={{ fontSize: 12, margin: '6px 0 0' }}>→ {bl.note}</p>}
        </div>
      ))}

      <hr className="kb-divider" />

      {session.isTest ? (
        <>
          <div className="kb-eyebrow" style={{ marginBottom: 2 }}>Registrar el test</div>
          <div style={{ marginBottom: 10 }}>
            {(def.testFields || []).map((f) => (
              <div className="kb-focus-row" key={f.key}>
                <div className="kb-focus-name">{f.label}</div>
                <div className="kb-focus-inputs">
                  <input type="text" inputMode="numeric" placeholder={f.placeholder}
                    value={testValues[f.key] ?? ''}
                    onChange={(e) => setTestValues((prev) => ({ ...prev, [f.key]: e.target.value }))} />
                </div>
              </div>
            ))}
          </div>
          <button className={`kb-btn ${log.completed ? 'kb-btn-ghost' : 'kb-btn-primary'}`} style={{ marginTop: 4 }} onClick={toggleComplete}>
            {log.completed ? 'Editar test' : 'Guardar test'}
          </button>
        </>
      ) : (
        <>
          {session.focus && session.focus.length > 0 && (
            <>
              <div className="kb-eyebrow" style={{ marginBottom: 2 }}>Registrar resultado</div>
              <div style={{ marginBottom: 10 }}>
                {session.focus.map((item, idx) => (
                  <div className="kb-focus-row" key={idx}>
                    <div className="kb-focus-name">{item.name}</div>
                    {focusInputs(item, idx)}
                  </div>
                ))}
              </div>
            </>
          )}
          <div className="kb-eyebrow" style={{ marginBottom: 6 }}>RPE de la sesión</div>
          <div className="kb-rpe-row">
            {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((n) => (
              <button key={n} className="kb-rpe-chip" data-active={log.rpe === n ? '1' : '0'} onClick={() => onSetLog({ rpe: n })}>{n}</button>
            ))}
          </div>
          <button className={`kb-btn ${log.completed ? 'kb-btn-ghost' : 'kb-btn-primary'}`} style={{ marginTop: 16 }} onClick={toggleComplete}>
            {log.completed ? 'Editar registro' : 'Marcar sesión completa'}
          </button>
        </>
      )}
    </div>
  );
}
