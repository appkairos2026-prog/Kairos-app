import { useEffect, useState } from 'react';
import { PROGRAM_DEFS, PROGRAM_PRODUCTS, PROGRAM_ORDER, DEMO_CODES, COACH_UNLOCK_CODE } from './data';
import { HOME_FAQ } from './landingContent';
import { callLicenseApi } from './license';
import type { UnlockInfo } from './types';

const DEMO_CODE_LIST = Object.keys(DEMO_CODES).join(', ');

const BENEFITS = [
  {
    title: 'Un objetivo, no un cajón de sastre',
    text: 'Cada programa está pensado para un único objetivo — tu primera dominada, tu ring muscle-up, una estación de Hyrox — no para "entrenar un poco de todo".',
  },
  {
    title: 'Progresión semana a semana',
    text: 'Cada semana cumple una función dentro del plan: evaluación, base, progresión y ajuste final antes de terminar. No son sesiones sueltas.',
  },
  {
    title: 'Mides tu progreso',
    text: 'Marcas cada sesión como completada, anotas tu RPE y, en los programas con test, comparas tu punto de partida con el resultado final.',
  },
  {
    title: 'Entrena sin conexión',
    text: 'Una vez activado, el programa funciona sin internet. Puedes añadirlo a la pantalla de inicio de tu móvil como una app.',
  },
  {
    title: 'Pago único, sin suscripción',
    text: 'Compras el programa una vez y es tuyo. Sin cuotas mensuales ni renovaciones automáticas.',
  },
  {
    title: 'Activación al momento',
    text: 'Tras la compra recibes un código de activación. Lo introduces y tu programa se desbloquea al instante.',
  },
];

const STEPS = [
  {
    title: 'Eliges tu objetivo',
    text: 'Miras los 7 programas y eliges el que corresponde a lo que quieres conseguir.',
  },
  {
    title: 'Compras tu programa',
    text: 'Pago único a través de Lemon Squeezy. Recibes tu código de activación tras la compra.',
  },
  {
    title: 'Entrenas y registras tu progreso',
    text: 'Activas el código, entrenas sesión a sesión y vas marcando tu progreso semana a semana.',
  },
];

const TRUST_ITEMS = [
  {
    title: 'Pago único y seguro',
    text: 'El cobro lo procesa Lemon Squeezy. Nosotros no gestionamos ni guardamos tus datos de pago.',
  },
  {
    title: 'Activación inmediata',
    text: 'El código llega justo después de la compra y desbloquea tu programa al momento, sin esperas.',
  },
  {
    title: 'Sin conexión',
    text: 'Entrena aunque no tengas datos o wifi: una vez activado, el programa se queda guardado en tu móvil.',
  },
  {
    title: 'Varios programas a la vez',
    text: 'Si compras más de uno, cambias entre ellos desde Ajustes sin perder el progreso de ninguno.',
  },
];

interface Props {
  onUnlocked: (programId: string, info: UnlockInfo) => void;
}

export function BlockGate({ onUnlocked }: Props) {
  const [code, setCode] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [autoChecking, setAutoChecking] = useState(false);
  const [showCodeField, setShowCodeField] = useState(false);

  const activate = async (raw: string) => {
    const value = raw.trim();
    if (!value) { setError('Escribe tu código.'); return; }
    setBusy(true);
    setError('');
    const upper = value.toUpperCase();
    if (upper === COACH_UNLOCK_CODE) {
      const now = new Date().toISOString();
      PROGRAM_ORDER.forEach((pid) => onUnlocked(pid, { activatedAt: now, source: 'coach' }));
      setBusy(false);
      return;
    }
    if (DEMO_CODES[upper]) {
      onUnlocked(DEMO_CODES[upper], { activatedAt: new Date().toISOString(), source: 'demo' });
      setBusy(false);
      return;
    }
    const result = await callLicenseApi('activate', value);
    setBusy(false);
    if (result.ok) {
      // Si el servidor no sabe a qué programa pertenece esta licencia (falta
      // configurar LEMONSQUEEZY_PRODUCT_MAP), caemos en hyrox8 por compatibilidad.
      onUnlocked(result.programId || 'hyrox8', { activatedAt: new Date().toISOString(), licenseKey: value, instanceId: result.instanceId, source: 'lemonsqueezy' });
    } else {
      setError(result.error || 'Código no reconocido. Revisa mayúsculas y guiones.');
    }
  };

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const fromRedirect = params.get('license_key');
    if (fromRedirect) {
      setCode(fromRedirect);
      setShowCodeField(true);
      setAutoChecking(true);
      activate(fromRedirect).finally(() => setAutoChecking(false));
      window.history.replaceState({}, '', window.location.pathname);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="kb-app">
      <div className="kb-content" style={{ padding: 0 }}>

        {/* ---------- 1. HERO ---------- */}
        <section className="kb-land-hero">
          <div className="kb-land-mark">Kairos · entrenamiento por objetivo</div>
          <h1 className="kb-display kb-land-title">Elige tu<br />objetivo.<br />Entrénalo.</h1>
          <p className="kb-land-sub">
            Siete programas de 6 a 8 semanas, cada uno para un objetivo concreto.
            Compras el tuyo, lo activas con un código y entrenas paso a paso desde el móvil, sin conexión.
          </p>
          <div className="kb-land-cta">
            <a className="kb-btn kb-btn-primary" style={{ textDecoration: 'none' }} href="#programas">
              Ver los 7 programas
            </a>
          </div>
        </section>

        {/* ---------- 2. BENEFICIOS ---------- */}
        <section className="kb-land-section" style={{ paddingTop: 0 }}>
          <div className="kb-eyebrow">Por qué Kairos</div>
          <h2 className="kb-display">Un plan, no una lista de ejercicios</h2>
          <div className="kb-benefit-grid">
            {BENEFITS.map((b) => (
              <div className="kb-benefit-card" key={b.title}>
                <h3 className="kb-benefit-title">{b.title}</h3>
                <p className="kb-muted kb-benefit-text">{b.text}</p>
              </div>
            ))}
          </div>
        </section>

        {/* ---------- 3. CÓMO FUNCIONA ---------- */}
        <section className="kb-land-section" style={{ paddingTop: 0 }}>
          <div className="kb-eyebrow">Cómo funciona</div>
          <h2 className="kb-display">3 pasos, sin complicarlo</h2>
          <ol className="kb-steps">
            {STEPS.map((s, i) => (
              <li className="kb-step" key={s.title}>
                <span className="kb-step-num kb-mono">{i + 1}</span>
                <div>
                  <h3 className="kb-step-title">{s.title}</h3>
                  <p className="kb-muted kb-step-text">{s.text}</p>
                </div>
              </li>
            ))}
          </ol>
        </section>

        {/* ---------- 4. PROGRAMAS ---------- */}
        <section className="kb-land-section" style={{ paddingTop: 0 }} id="programas">
          <div className="kb-eyebrow" style={{ marginBottom: 10 }}>Programas disponibles</div>
          <h2 className="kb-display" style={{ marginBottom: 14 }}>7 objetivos. Elige el tuyo.</h2>
          {PROGRAM_ORDER.map((pid) => {
            const def = PROGRAM_DEFS[pid];
            const product = PROGRAM_PRODUCTS[pid];
            return (
              <div className="kb-card kb-program-card" key={pid}>
                <div className="kb-program-card-head">
                  <span className="kb-pill kb-pill-neutral">{def.discipline === 'hyrox' ? 'Hyrox' : 'CrossFit'}</span>
                  <div className="kb-price-tag kb-price-tag-lg kb-mono">{product.priceLabel}</div>
                </div>
                <h3 className="kb-display kb-program-name">{def.name.replace(/^(Hyrox|CrossFit) — /, '')}</h3>
                <p className="kb-muted kb-program-meta">{def.weeks} semanas · 3 sesiones/semana</p>
                <p className="kb-program-pitch">{product.pitch}</p>
                <a className="kb-btn kb-btn-primary" style={{ textDecoration: 'none' }} href={product.checkoutUrl}>
                  Comprar programa
                </a>
                <a className="kb-program-detail-link" href={`/programas/${pid}`}>Ver programa completo →</a>
              </div>
            );
          })}
        </section>

        {/* ---------- código ya comprado ---------- */}
        <section className="kb-land-section" style={{ paddingTop: 0 }}>
          <div className="kb-card">
            <button className="kb-btn kb-btn-ghost" onClick={() => setShowCodeField((v) => !v)}>
              Ya tengo un código
            </button>
            {showCodeField && (
              <div style={{ marginTop: 14 }}>
                <div className="kb-field">
                  <label htmlFor="unlock-input">Código de tu programa</label>
                  <input id="unlock-input" type="text" placeholder="Pégalo aquí o escríbelo"
                    value={code} onChange={(e) => setCode(e.target.value)}
                    onKeyDown={(e) => { if (e.key === 'Enter') activate(code); }}
                    autoComplete="off" />
                </div>
                {error && <div className="kb-gate-error">{error}</div>}
                <button className="kb-btn kb-btn-primary" disabled={busy} onClick={() => activate(code)}>
                  {busy ? 'Comprobando…' : 'Activar programa'}
                </button>
                {autoChecking && <p className="kb-faint" style={{ fontSize: 11.5, marginTop: 8 }}>Activando tu compra automáticamente…</p>}
                <p className="kb-faint" style={{ fontSize: 11, marginTop: 10 }}>Modo demo: prueba con {DEMO_CODE_LIST}</p>
              </div>
            )}
          </div>
        </section>

        {/* ---------- 5. CONFIANZA ---------- */}
        <section className="kb-land-section" style={{ paddingTop: 0 }}>
          <div className="kb-eyebrow">Por qué confiar</div>
          <h2 className="kb-display">Nada que no puedas comprobar tú</h2>
          <div className="kb-trust-grid">
            {TRUST_ITEMS.map((t) => (
              <div className="kb-trust-item" key={t.title}>
                <h3 className="kb-trust-title">{t.title}</h3>
                <p className="kb-muted kb-trust-text">{t.text}</p>
              </div>
            ))}
          </div>
        </section>

        {/* ---------- 6. FAQ ---------- */}
        <section className="kb-land-section" style={{ paddingTop: 0 }}>
          <div className="kb-eyebrow">Preguntas frecuentes</div>
          <h2 className="kb-display">Antes de comprar</h2>
          <div className="kb-faq-list">
            {HOME_FAQ.map((f) => (
              <details className="kb-faq-item" key={f.q}>
                <summary>{f.q}</summary>
                <p className="kb-muted">{f.a}</p>
              </details>
            ))}
          </div>
        </section>

        {/* ---------- 7. CTA FINAL ---------- */}
        <section className="kb-land-section kb-land-final-cta">
          <div className="kb-eyebrow">Empieza ahora</div>
          <h2 className="kb-display">¿Cuál es tu objetivo?</h2>
          <p className="kb-muted">Elige tu programa, actívalo con tu código y empieza esta misma semana.</p>
          <div className="kb-land-cta">
            <a className="kb-btn kb-btn-primary" style={{ textDecoration: 'none' }} href="#programas">
              Ver los 7 programas
            </a>
          </div>
        </section>

        <footer className="kb-land-footer">
          <div className="kb-wordmark kb-display" style={{ fontSize: 16 }}>KAI<span>ROS</span></div>
          <p className="kb-faint" style={{ fontSize: 11 }}>Entrena donde quieras, sin conexión.</p>
        </footer>
      </div>
    </div>
  );
}
