import { useEffect, useState } from 'react';
import { PROGRAM_DEFS, DEMO_CODES } from './data';
import { callLicenseApi } from './license';
import type { UnlockInfo } from './types';

// TODO Adrián — para cada programa, sustituye el enlace de compra de Lemon Squeezy
// (Lemon Squeezy → ese producto → "Copiar enlace de compra"). Los precios ya están
// puestos; cámbialos aquí si quieres otro valor.
interface ProductMeta {
  checkoutUrl: string;
  priceLabel: string;
  pitch: string;
}

const PRODUCTS: Record<string, ProductMeta> = {
  hyrox8: {
    checkoutUrl: 'https://TU-TIENDA.lemonsqueezy.com/buy/TU-PRODUCTO-HYROX',
    priceLabel: '29 €',
    pitch: '8 semanas para bajar tu tiempo en sled, ski y wall balls. Test inicial y test final para verlo en números.',
  },
  'cf-fuerza': {
    checkoutUrl: 'https://TU-TIENDA.lemonsqueezy.com/buy/TU-PRODUCTO-FUERZA',
    priceLabel: '29 €',
    pitch: '8 semanas de progresión en back squat, front squat, peso muerto y press militar, con test de 1RM inicial y final.',
  },
  'cf-primera-dominada': {
    checkoutUrl: 'https://TU-TIENDA.lemonsqueezy.com/buy/TU-PRODUCTO-DOMINADA',
    priceLabel: '19 €',
    pitch: '6 semanas de progresión por bandas, de cero a tu primera dominada estricta.',
  },
  'cf-gim-nivel1': {
    checkoutUrl: 'https://TU-TIENDA.lemonsqueezy.com/buy/TU-PRODUCTO-GIM1',
    priceLabel: '24 €',
    pitch: '6 semanas para automatizar el kip y encadenar dominadas y toes-to-bar sin soltarte de la barra.',
  },
  'cf-gim-nivel2': {
    checkoutUrl: 'https://TU-TIENDA.lemonsqueezy.com/buy/TU-PRODUCTO-GIM2',
    priceLabel: '29 €',
    pitch: '6 semanas de transición asistida con banda, de chest-to-bar a tu primer bar muscle-up.',
  },
  'cf-anillas-rmu': {
    checkoutUrl: 'https://TU-TIENDA.lemonsqueezy.com/buy/TU-PRODUCTO-RMU',
    priceLabel: '34 €',
    pitch: '8 semanas de falso agarre y transición asistida en anillas, hasta tu ring muscle-up.',
  },
  'hyrox-carrera': {
    checkoutUrl: 'https://TU-TIENDA.lemonsqueezy.com/buy/TU-PRODUCTO-CARRERA',
    priceLabel: '29 €',
    pitch: '8 semanas para correr mejor con las piernas cargadas: base aeróbica, series de umbral y carrera comprometida, con test inicial y final.',
  },
};

const PROGRAM_ORDER = ['hyrox8', 'hyrox-carrera', 'cf-fuerza', 'cf-primera-dominada', 'cf-gim-nivel1', 'cf-gim-nivel2', 'cf-anillas-rmu'];

const DEMO_CODE_LIST = Object.keys(DEMO_CODES).join(', ');

interface Props {
  onUnlocked: (programId: string, info: UnlockInfo) => void;
}

export function BlockGate({ onUnlocked }: Props) {
  const [code, setCode] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [autoChecking, setAutoChecking] = useState(false);
  const [showCodeField, setShowCodeField] = useState(false);
  const [expanded, setExpanded] = useState<string | null>(PROGRAM_ORDER[0]);

  const activate = async (raw: string) => {
    const value = raw.trim();
    if (!value) { setError('Escribe tu código.'); return; }
    setBusy(true);
    setError('');
    const upper = value.toUpperCase();
    if (DEMO_CODES[upper]) {
      onUnlocked(DEMO_CODES[upper], { activatedAt: new Date().toISOString(), source: 'demo' });
      setBusy(false);
      return;
    }
    const result = await callLicenseApi('activate', value);
    setBusy(false);
    if (result.ok) {
      // Si el servidor no sabe a qué programa pertenece esta licencia (falta
      // configurar LEMONSQUEEZY_PRODUCT_MAP), caemos en hyrox8 por compatibilidad.
      onUnlocked(result.programId || 'hyrox8', { activatedAt: new Date().toISOString(), licenseKey: value, instanceId: result.instanceId, source: 'lemonsqueezy' });
    } else {
      setError(result.error || 'Código no reconocido. Revisa mayúsculas y guiones.');
    }
  };

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const fromRedirect = params.get('license_key');
    if (fromRedirect) {
      setCode(fromRedirect);
      setShowCodeField(true);
      setAutoChecking(true);
      activate(fromRedirect).finally(() => setAutoChecking(false));
      window.history.replaceState({}, '', window.location.pathname);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="kb-app">
      <div className="kb-content" style={{ padding: 0 }}>
        <section className="kb-land-hero">
          <div className="kb-land-mark">Korriban Club · programación específica</div>
          <h1 className="kb-display kb-land-title">Elige tu<br />objetivo</h1>
          <p className="kb-land-sub">
            Seis bloques de entreno enfocados, con progresión semana a semana.
            Compra el que necesites, actívalo con tu código y entrena sin conexión.
          </p>
        </section>

        <section className="kb-land-section" style={{ paddingTop: 0 }}>
          <div className="kb-eyebrow" style={{ marginBottom: 10 }}>Programas disponibles</div>
          {PROGRAM_ORDER.map((pid) => {
            const def = PROGRAM_DEFS[pid];
            const product = PRODUCTS[pid];
            const isOpen = expanded === pid;
            return (
              <div className="kb-card" key={pid} style={{ marginBottom: 12 }}>
                <div
                  style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 10, cursor: 'pointer' }}
                  onClick={() => setExpanded(isOpen ? null : pid)}
                >
                  <div>
                    <h3 className="kb-display" style={{ margin: '0 0 4px', fontSize: 18 }}>{def.name.replace(/^(Hyrox|CrossFit) — /, '')}</h3>
                    <p className="kb-muted" style={{ fontSize: 12.5, margin: 0 }}>{def.weeks} semanas · 3 sesiones/semana</p>
                  </div>
                  <div className="kb-price-tag kb-mono" style={{ flexShrink: 0 }}>{product.priceLabel}</div>
                </div>
                {isOpen && (
                  <>
                    <p className="kb-muted" style={{ fontSize: 13, marginTop: 10 }}>{product.pitch}</p>
                    <a className="kb-btn kb-btn-primary" style={{ textDecoration: 'none', marginTop: 8 }} href={product.checkoutUrl}>
                      Comprar {def.short}
                    </a>
                  </>
                )}
              </div>
            );
          })}
        </section>

        <section className="kb-land-section" style={{ paddingTop: 0 }}>
          <div className="kb-card">
            <button className="kb-btn kb-btn-ghost" onClick={() => setShowCodeField((v) => !v)}>
              Ya tengo un código
            </button>
            {showCodeField && (
              <div style={{ marginTop: 14 }}>
                <div className="kb-field">
                  <label htmlFor="unlock-input">Código de tu programa</label>
                  <input id="unlock-input" type="text" placeholder="Pégalo aquí o escríbelo"
                    value={code} onChange={(e) => setCode(e.target.value)}
                    onKeyDown={(e) => { if (e.key === 'Enter') activate(code); }}
                    autoComplete="off" />
                </div>
                {error && <div className="kb-gate-error">{error}</div>}
                <button className="kb-btn kb-btn-primary" disabled={busy} onClick={() => activate(code)}>
                  {busy ? 'Comprobando…' : 'Activar programa'}
                </button>
                {autoChecking && <p className="kb-faint" style={{ fontSize: 11.5, marginTop: 8 }}>Activando tu compra automáticamente…</p>}
                <p className="kb-faint" style={{ fontSize: 11, marginTop: 10 }}>Modo demo: prueba con {DEMO_CODE_LIST}</p>
              </div>
            )}
          </div>
        </section>

        <section className="kb-land-section">
          <div className="kb-eyebrow">Cómo funciona</div>
          <h2 className="kb-display">Compra, activa, entrena</h2>
          <p className="kb-muted">
            Al comprar recibes un código. Lo pegas aquí una vez y esta misma página se
            convierte en tu cuaderno de entreno: funciona sin conexión y puedes añadirla
            a la pantalla de inicio de tu iPhone como una app. Puedes desbloquear varios
            programas a la vez y cambiar entre ellos desde Ajustes.
          </p>
        </section>

        <footer className="kb-land-footer">
          <div className="kb-wordmark kb-display" style={{ fontSize: 16 }}>KAI<span>ROS</span></div>
          <p className="kb-faint" style={{ fontSize: 11 }}>Un producto de Korriban Club.</p>
        </footer>
      </div>
    </div>
  );
}
