import type { ProgramBlockLine, ProgramDay, ProgramDef, Session, TestFieldDef, TestRowDef, WeekMeta } from './types';

function b(letter: string, title: string, lines: string[], note?: string): ProgramBlockLine {
  return { letter, title, lines, note: note || null };
}

/* ==================================================================== */
/* Hyrox — Mejorar Estaciones (8 semanas)                                */
/* ==================================================================== */

const HYROX_TEST_FIELDS: TestFieldDef[] = [
  { key: 'sledPushTime', label: 'Sled Push 25 m', placeholder: 'mm:ss' },
  { key: 'sledPushLoad', label: '↳ carga usada', placeholder: 'kg' },
  { key: 'sledPullTime', label: 'Sled Pull 25 m', placeholder: 'mm:ss' },
  { key: 'sledPullLoad', label: '↳ carga usada', placeholder: 'kg' },
  { key: 'skiErgTime', label: 'SkiErg 500 m', placeholder: 'mm:ss' },
  { key: 'wallBallsTime', label: 'Wall Balls × 30', placeholder: 'mm:ss' },
  { key: 'wallBallsWeight', label: '↳ peso del balón', placeholder: 'kg' },
];

const HYROX_TEST_ROWS: TestRowDef[] = [
  { label: 'Sled Push 25 m', key: 'sledPushTime', category: 'time' },
  { label: 'Sled Pull 25 m', key: 'sledPullTime', category: 'time' },
  { label: 'SkiErg 500 m', key: 'skiErgTime', category: 'time' },
  { label: 'Wall Balls × 30', key: 'wallBallsTime', category: 'time' },
];

const HYROX_WEEK_META: Record<number, WeekMeta> = {
  1: { phase: 'test', phaseLabel: 'Test y familiarización', intro: 'Esta semana no busca fatiga: busca números. Ve descansado a las tres sesiones.' },
  2: { phase: 'base', phaseLabel: 'Base', intro: 'Volumen y técnica. Debes acabar cada sesión pudiendo hacer una más.' },
  3: { phase: 'base', phaseLabel: 'Base', intro: 'Entra el sled pull. Cuidado con el agarre el resto de la semana.' },
  4: { phase: 'base', phaseLabel: 'Base', intro: 'Cierre del bloque. La sesión de ski de esta semana es la que marca tu ritmo.' },
  5: { phase: 'specific', phaseLabel: 'Específico', intro: 'Sube la intensidad y bajan los descansos. Las sesiones se parecen más a competir.' },
  6: { phase: 'specific', phaseLabel: 'Específico', intro: 'Semana de carga alta. Si entrenas 5 o 6 días en el box, valora quitar una clase.' },
  7: { phase: 'specific', phaseLabel: 'Específico · la más dura', intro: 'El pico del ciclo. A partir de aquí solo se descarga.' },
  8: { phase: 'deload', phaseLabel: 'Descarga y test final', intro: 'Baja el volumen a la mitad. El objetivo es llegar fresco al test, no seguir entrenando.' },
};

const HYROX_PROGRAM_DATA: Record<number, ProgramDay[]> = {
  1: [
    { heading: 'Test inicial', subtitle: 'Descanso completo entre pruebas. Esto no es un metcon.', isTest: true,
      blocks: [
        b('A', 'Las cuatro medidas', ['Sled push 25 m — tiempo + carga usada', 'Sled pull 25 m — tiempo + carga usada', 'SkiErg 500 m — tiempo', 'Wall balls × 30 sin parar — tiempo + peso del balón'], 'Mínimo 3 min de descanso entre pruebas. Usa la carga con la que puedas moverte sin pararte, no la máxima.'),
        b('B', 'Anota todo', ['Estos cuatro números son tus referencias de ritmo durante las 8 semanas', 'En la semana 8 repetirás lo mismo con la misma carga'], 'Si cambias la carga, pierdes la comparación. Es el error más común.'),
      ] },
    { heading: 'Familiarización SkiErg', subtitle: 'Técnica antes que intensidad.',
      blocks: [
        b('A', 'Técnica de SkiErg · 10 min', ['5 × 1 min a ritmo suave · descanso 1 min', 'Busca 38-42 brazadas por minuto'], 'Tirón desde el tronco, no desde los brazos. Cadera atrás, cierre completo.'),
        b('B', 'Intervalos de reconocimiento', ['6 × 250 m · descanso 90 s'], 'Anota el tiempo del primero y del último: no deberían diferenciarse en más de 3 segundos.'),
        b('C', 'Accesorio', ['3 × 12 remo con mancuerna a un brazo', '3 × 15 face pull o band pull apart']),
      ] },
    { heading: 'Familiarización Wall Ball', subtitle: 'Gesto limpio y carrera suave.',
      blocks: [
        b('A', 'Técnica de wall ball · 8 min', ['4 × 10 repeticiones sin prisa · descanso 60 s'], 'Mismo punto de impacto en la pared, recepción en sentadilla completa, respirar arriba.'),
        b('B', 'Compromiso ligero', ['3 rondas: 400 m carrera suave + 12 wall balls', 'Descanso 2 min entre rondas'], 'Sales de cada ronda pudiendo hablar.'),
        b('C', 'Accesorio', ['3 × 20 zancadas caminando sin peso', '2 min de plancha acumulada']),
      ] },
  ],
  2: [
    { heading: 'Trineos', subtitle: 'Fuerza de tirón primero, con el sistema fresco.', focus: [{ name: 'Sled Push', category: 'time' }],
      blocks: [
        b('A', 'Fuerza tren superior', ['A1 · Remo con barra — 4 × 8 · RPE 7 · descanso 90 s', 'A2 · Press militar con mancuernas — 3 × 10 · descanso 60 s']),
        b('B', 'Trineos', ['6 × 25 m sled push · descanso 90 s'], 'Carga moderada: debes poder empujar sin detenerte en ningún momento.'),
        b('C', 'Complementario', ['3 × 20 m zancadas caminando con mancuernas', '3 × 12 step up por pierna']),
      ] },
    { heading: 'Motor', subtitle: 'SkiErg como eje + rotatoria.', focus: [{ name: 'SkiErg', category: 'time' }],
      blocks: [
        b('A', 'SkiErg', ['8 × 250 m · descanso 60 s'], 'Ritmo: 2-3 s más lento que tu ritmo de test por 250 m.'),
        b('B', 'Rotatoria · Burpee broad jumps', ['4 × 10 repeticiones · descanso 90 s'], 'Céntrate en la distancia del salto, no en la velocidad.'),
        b('C', 'Core', ['3 × 15 hollow rock', '3 × 30 s plancha lateral por lado']),
      ] },
    { heading: 'Compromiso', subtitle: 'El día que más se parece a competir.', focus: [{ name: 'Compromiso', category: 'time' }],
      blocks: [
        b('A', 'Wall ball + carrera', ['4 rondas: 400 m carrera + 15 wall balls', 'Descanso 90 s entre rondas']),
        b('B', 'Rotatoria · Remo', ['3 × 500 m · descanso 90 s'], 'Ritmo constante, sin sprint final.'),
        b('C', 'Accesorio', ['3 × 12 curl de femoral o peso muerto rumano ligero']),
      ] },
  ],
  3: [
    { heading: 'Trineos', subtitle: 'Se añade el tirón.', focus: [{ name: 'Sled Push', category: 'time' }, { name: 'Sled Pull', category: 'time' }],
      blocks: [
        b('A', 'Fuerza tren superior', ['A1 · Remo con barra — 4 × 6 · algo más pesado que la semana 2', 'A2 · Press militar con mancuernas — 3 × 10']),
        b('B', 'Trineos', ['6 × 25 m sled push · descanso 90 s', '4 × 25 m sled pull · descanso 90 s']),
        b('C', 'Complementario', ['3 × 20 m zancadas caminando con mancuernas · sube algo de peso', '3 × 15 elevación de talones']),
      ] },
    { heading: 'Motor', subtitle: 'Intervalo más largo.', focus: [{ name: 'SkiErg', category: 'time' }],
      blocks: [
        b('A', 'SkiErg', ['6 × 400 m · descanso 90 s']),
        b('B', 'Rotatoria · Sandbag lunges', ['4 × 20 m · descanso 90 s'], 'Si se te cae el saco, baja el peso: la posición importa más que la carga.'),
        b('C', 'Core', ['3 × 15 v-up', '3 × 30 s plancha lateral por lado']),
      ] },
    { heading: 'Compromiso', subtitle: 'Sube el volumen de wall ball.', focus: [{ name: 'Compromiso', category: 'time' }],
      blocks: [
        b('A', 'Wall ball + carrera', ['4 rondas: 400 m carrera + 20 wall balls', 'Descanso 90 s entre rondas']),
        b('B', 'Rotatoria · Farmers carry', ['4 × 50 m · descanso 90 s'], 'Peso alto: debe costarte llegar, pero sin soltar.'),
        b('C', 'Accesorio', ['3 × 12 peso muerto rumano']),
      ] },
  ],
  4: [
    { heading: 'Trineos', subtitle: 'El día más pesado del bloque base.', focus: [{ name: 'Sled Push', category: 'time' }, { name: 'Sled Pull', category: 'time' }],
      blocks: [
        b('A', 'Fuerza tren superior', ['A1 · Remo con barra — 5 × 5 · el más pesado del bloque', 'A2 · Press militar con mancuernas — 3 × 8']),
        b('B', 'Trineos', ['8 × 25 m alternando push y pull · descanso 75 s']),
        b('C', 'Complementario', ['3 × 20 m zancadas caminando con mancuernas', '3 × 12 step up por pierna']),
      ] },
    { heading: 'Motor', subtitle: 'Sesión de referencia.', focus: [{ name: 'SkiErg', category: 'time' }],
      blocks: [
        b('A', 'SkiErg', ['5 × 500 m · descanso 90 s'], 'Este es el que importa: intenta que los cinco estén dentro del ritmo de tu test.'),
        b('B', 'Rotatoria · Burpee broad jumps', ['4 × 15 repeticiones · descanso 90 s']),
        b('C', 'Core', ['3 × 20 hollow rock', '3 × 40 s plancha lateral por lado']),
      ] },
    { heading: 'Compromiso', subtitle: 'Una ronda más.', focus: [{ name: 'Compromiso', category: 'time' }],
      blocks: [
        b('A', 'Wall ball + carrera', ['5 rondas: 400 m carrera + 20 wall balls', 'Descanso 90 s entre rondas']),
        b('B', 'Rotatoria · Remo', ['3 × 750 m · descanso 2 min']),
        b('C', 'Accesorio', ['3 × 12 peso muerto rumano']),
      ] },
  ],
  5: [
    { heading: 'Trineos', subtitle: 'Distancias de 50 m con carga alta.', focus: [{ name: 'Sled Push', category: 'time' }, { name: 'Sled Pull', category: 'time' }],
      blocks: [
        b('A', 'Fuerza tren superior', ['A1 · Dominadas lastradas o remo con barra — 5 × 5', 'A2 · Press militar con barra — 4 × 8']),
        b('B', 'Trineos', ['5 × 50 m sled push · descanso 2 min · carga alta', '4 × 50 m sled pull · descanso 2 min']),
        b('C', 'Complementario', ['3 × 12 split squat búlgaro por pierna']),
      ] },
    { heading: 'Motor', subtitle: 'Densidad: descanso corto.', focus: [{ name: 'SkiErg', category: 'time' }],
      blocks: [
        b('A', 'SkiErg', ['10 × 250 m · descanso 30 s'], 'Descanso corto: aquí se entrena la recuperación, no la velocidad punta.'),
        b('B', 'Rotatoria · Sandbag lunges', ['4 × 25 m · descanso 75 s']),
        b('C', 'Core', ['3 × 15 toes to bar o rodillas al pecho']),
      ] },
    { heading: 'Compromiso', subtitle: 'Carrera más larga.', focus: [{ name: 'Compromiso', category: 'time' }],
      blocks: [
        b('A', 'Wall ball + carrera', ['4 rondas: 600 m carrera + 25 wall balls', 'Descanso 90 s entre rondas']),
        b('B', 'Rotatoria · Farmers carry', ['4 × 75 m · descanso 90 s']),
        b('C', 'Accesorio', ['3 × 10 peso muerto rumano']),
      ] },
  ],
  6: [
    { heading: 'Trineos', subtitle: 'El descanso corto es lo que hace dura esta sesión.', focus: [{ name: 'Sled Push', category: 'time' }, { name: 'Sled Pull', category: 'time' }],
      blocks: [
        b('A', 'Fuerza tren superior', ['A1 · Dominadas lastradas o remo con barra — 5 × 5 · más carga', 'A2 · Press militar con barra — 4 × 6']),
        b('B', 'Trineos', ['6 × 50 m alternando push y pull · descanso 60 s'], 'Baja carga si no llegas a completar las seis con el descanso marcado.'),
        b('C', 'Complementario', ['3 × 12 split squat búlgaro por pierna']),
      ] },
    { heading: 'Motor', subtitle: 'Intervalos largos.', focus: [{ name: 'SkiErg', category: 'time' }],
      blocks: [
        b('A', 'SkiErg', ['4 × 750 m · descanso 2 min']),
        b('B', 'Rotatoria · Burpee broad jumps', ['5 × 15 repeticiones · descanso 75 s']),
        b('C', 'Core', ['3 × 15 toes to bar', '3 × 45 s plancha']),
      ] },
    { heading: 'Compromiso', subtitle: 'Cinco rondas de 600 m.', focus: [{ name: 'Compromiso', category: 'time' }],
      blocks: [
        b('A', 'Wall ball + carrera', ['5 rondas: 600 m carrera + 25 wall balls', 'Descanso 75 s entre rondas']),
        b('B', 'Rotatoria · Remo', ['3 × 1000 m · descanso 2 min']),
        b('C', 'Accesorio', ['3 × 10 peso muerto rumano']),
      ] },
  ],
  7: [
    { heading: 'Trineos', subtitle: 'Push y pull encadenados: la transición real de competición.', focus: [{ name: 'Sled Push', category: 'time' }, { name: 'Sled Pull', category: 'time' }],
      blocks: [
        b('A', 'Fuerza tren superior', ['A1 · Remo con barra — 4 × 6', 'A2 · Press militar con barra — 3 × 8']),
        b('B', 'Trineos', ['4 rondas: 50 m sled push + 50 m sled pull SIN descanso entre ellos', '2 min entre rondas'], 'Esto reproduce la transición real de competición. Es el bloque más exigente del ciclo.'),
        b('C', 'Complementario', ['2 × 12 split squat búlgaro por pierna'], 'Volumen bajo a propósito: ya has hecho suficiente.'),
        b('D', 'Transición específica', ['3 rondas: 200 m carrera + 25 m sled push + 25 m sled pull sin descanso entre push y pull', 'Descanso 90 s entre rondas'], 'El trineo nunca se hace "en frío" en competición: esto reproduce llegar a la estación después de correr, que es justo lo que falta entrenar en este día.'),
      ] },
    { heading: 'Motor', subtitle: 'Ritmo de carrera.', focus: [{ name: 'SkiErg', category: 'time' }],
      blocks: [
        b('A', 'SkiErg', ['3 × 1000 m · descanso 2 min'], 'Ritmo de carrera: el que crees que podrías sostener en competición.'),
        b('B', 'Rotatoria · Sandbag lunges', ['5 × 25 m · descanso 75 s']),
        b('C', 'Core', ['3 × 15 toes to bar']),
      ] },
    { heading: 'Compromiso', subtitle: 'Tres rondas largas.', focus: [{ name: 'Compromiso', category: 'time' }],
      blocks: [
        b('A', 'Wall ball + carrera', ['3 rondas: 1000 m carrera + 30 wall balls', 'Descanso 2 min entre rondas']),
        b('B', 'Rotatoria · Farmers carry', ['5 × 75 m · descanso 90 s']),
        b('C', 'Cierre', ['Movilidad y respiración · 10 min'], 'Nada de carga. Empieza la descarga.'),
      ] },
  ],
  8: [
    { heading: 'Descarga', subtitle: 'Baja el volumen, no la carga.',
      blocks: [
        b('A', 'Fuerza', ['Remo con barra — 2 × 6 · mismo peso que semana 6, no bajes carga']),
        b('B', 'Trineos', ['3 × 25 m sled push a la carga de tu test · descanso 2 min'], 'Baja el volumen, no la carga: mantener el peso real es lo que evita llegar "descalibrado" al test, según la evidencia sobre descargas.'),
        b('C', 'Complementario', ['2 × 20 m zancadas sin peso']),
      ] },
    { heading: 'Activación', subtitle: 'Mover, no fatigar.',
      blocks: [
        b('A', 'SkiErg', ['4 × 250 m suave · descanso 90 s']),
        b('B', 'Ligero', ['3 × 10 burpee broad jumps a ritmo cómodo']),
        b('C', 'Movilidad', ['10 min']),
      ] },
    { heading: 'Test final', subtitle: 'Mismo test, mismas cargas, mismo orden.', isTest: true,
      blocks: [
        b('A', 'Las cuatro medidas', ['Sled push 25 m', 'Sled pull 25 m', 'SkiErg 500 m', 'Wall balls × 30'], 'Descanso de 3 min entre pruebas, igual que en la semana 1.'),
        b('B', 'Compara', ['Si has mejorado tiempos con la misma carga, el ciclo ha funcionado'], 'Si quieres subir peso, hazlo en el siguiente ciclo. Nunca en el test.'),
      ] },
  ],
};

/* ==================================================================== */
/* CrossFit — Fuerza en Básicos (8 semanas): Back Squat, Front Squat,    */
/* Peso Muerto, Press Militar. Test de 1RM inicial y final.              */
/* ==================================================================== */

const FUERZA_TEST_FIELDS: TestFieldDef[] = [
  { key: 'backSquat1RM', label: 'Back Squat', placeholder: 'kg' },
  { key: 'pressStrict1RM', label: 'Press Militar', placeholder: 'kg' },
  { key: 'frontSquat1RM', label: 'Front Squat', placeholder: 'kg' },
  { key: 'deadlift1RM', label: 'Peso Muerto', placeholder: 'kg' },
];

const FUERZA_TEST_ROWS: TestRowDef[] = [
  { label: 'Back Squat 1RM', key: 'backSquat1RM', category: 'load' },
  { label: 'Front Squat 1RM', key: 'frontSquat1RM', category: 'load' },
  { label: 'Peso Muerto 1RM', key: 'deadlift1RM', category: 'load' },
  { label: 'Press Militar 1RM', key: 'pressStrict1RM', category: 'load' },
];

const FUERZA_WEEK_META: Record<number, WeekMeta> = {
  1: { phase: 'test', phaseLabel: 'Test de fuerza máxima', intro: 'Busca tu 1RM real en los cuatro básicos. Técnica antes que ego: si la barra se dobla o pierdes la posición, no cuenta.' },
  2: { phase: 'base', phaseLabel: 'Volumen', intro: 'Series de calidad a intensidad moderada. Debes acabar cada serie con margen.' },
  3: { phase: 'base', phaseLabel: 'Volumen', intro: 'Mismo esquema, algo más de peso. La técnica no cambia.' },
  4: { phase: 'fuerza', phaseLabel: 'Fuerza', intro: 'Bajan las repeticiones, sube la carga. Aquí se construye la fuerza real del ciclo.' },
  5: { phase: 'fuerza', phaseLabel: 'Fuerza', intro: 'Sigue subiendo. Si fallas una serie, repite el peso la próxima sesión — nunca lo subas a la fuerza.' },
  6: { phase: 'pico', phaseLabel: 'Pico', intro: 'Series cortas, pesos altos. El objetivo es moverte rápido con carga pesada.' },
  7: { phase: 'pico', phaseLabel: 'Pico · la más pesada', intro: 'La semana más dura del bloque. A partir de aquí solo se descarga.' },
  8: { phase: 'deload', phaseLabel: 'Descarga y test final', intro: 'Mitad de volumen y, al final de la semana, el mismo test con el que empezaste.' },
};

const FUERZA_PROGRAM_DATA: Record<number, ProgramDay[]> = {
  1: [
    { heading: 'Técnica de sentadilla', subtitle: 'Patrón antes que carga — el test es en dos días.',
      blocks: [
        b('A', 'Back Squat técnico', ['5 × 5 con barra vacía o carga muy ligera', 'Pausa de 1 s abajo'], 'Rodillas en la línea de los pies, pecho arriba, misma profundidad en las cinco.'),
        b('B', 'Front Squat técnico', ['4 × 5 ligero'], 'Codos altos: la barra descansa en los hombros, no en las manos.'),
        b('C', 'Core', ['3 × 30 s plancha', '3 × 12 pallof press por lado']),
      ] },
    { heading: 'Técnica de press y peso muerto', subtitle: 'Mecánica antes que peso — mañana o pasado, el test.',
      blocks: [
        b('A', 'Press Militar técnico', ['5 × 5 ligero'], 'Aprieta el glúteo, no arquees la lumbar para compensar.'),
        b('B', 'Peso Muerto técnico', ['5 × 5 con barra ligera, o técnica desde bloques altos'], 'Barra pegada a la espinilla todo el recorrido.'),
        b('C', 'Movilidad', ['Movilidad de cadera y tobillo · 8 min']),
      ] },
    { heading: 'Test: Back Squat, Press, Front Squat y Peso Muerto', subtitle: 'Escalones de 5-10 kg. Descansa 3-5 min entre intentos pesados. Puedes repartirlo en dos días si lo prefieres.', isTest: true,
      blocks: [
        b('A', 'Back Squat', ['Calienta con series de 5-3-1 y sube en escalones hasta tu 1RM técnico'], 'Detén el intento si pierdes la posición del torso: un fallo técnico no es un 1RM.'),
        b('B', 'Press Militar estricto', ['Mismo protocolo de escalones hasta el 1RM'], 'Sin impulso de piernas ni de cadera: si te ayudas con la cadera, no cuenta.'),
        b('C', 'Front Squat', ['Escalones de 5-10 kg hasta el 1RM'], 'Codos altos todo el recorrido; si caen, ese es tu límite de hoy.'),
        b('D', 'Peso Muerto', ['Escalones hasta el 1RM · descansa 3-5 min entre intentos pesados'], 'Si notas la zona lumbar redondearse, para ahí: ese es tu número de hoy.'),
      ] },
  ],
  2: [
    { heading: 'Back Squat + Press', subtitle: 'Arranca el bloque de volumen.', focus: [{ name: 'Back Squat', category: 'load' }, { name: 'Press Militar', category: 'load' }],
      blocks: [
        b('A', 'Back Squat', ['4 × 6 al 70% de tu 1RM · descanso 2 min']),
        b('B', 'Press Militar', ['4 × 6 al 65% de tu 1RM · descanso 90 s']),
        b('C', 'Core', ['3 × 12 pallof press por lado', '3 × 30 s hollow hold']),
      ] },
    { heading: 'Peso Muerto', subtitle: 'Un solo levantamiento pesado hoy, el resto es accesorio.', focus: [{ name: 'Peso Muerto', category: 'load' }],
      blocks: [
        b('A', 'Peso Muerto', ['3 × 5 al 70% de tu 1RM · descanso 2-3 min']),
        b('B', 'Accesorio de tirón', ['4 × 10 remo con barra o mancuerna', '3 × 12 face pull']),
        b('C', 'Core', ['3 × 15 hollow rock']),
      ] },
    { heading: 'Front Squat + Press', subtitle: 'Cierra la semana.', focus: [{ name: 'Front Squat', category: 'load' }],
      blocks: [
        b('A', 'Front Squat', ['4 × 6 al 65% de tu 1RM · descanso 2 min']),
        b('B', 'Accesorio de empuje', ['3 × 10 press con mancuernas o fondos en paralelas']),
        b('C', 'Core', ['3 × 30 s plancha lateral por lado']),
      ] },
  ],
  3: [
    { heading: 'Back Squat + Press', subtitle: 'Mismo esquema, algo más de peso.', focus: [{ name: 'Back Squat', category: 'load' }, { name: 'Press Militar', category: 'load' }],
      blocks: [
        b('A', 'Back Squat', ['4 × 6 al 73% de tu 1RM · descanso 2 min']),
        b('B', 'Press Militar', ['4 × 6 al 68% de tu 1RM · descanso 90 s']),
        b('C', 'Core', ['3 × 12 pallof press por lado', '3 × 30 s hollow hold']),
      ] },
    { heading: 'Peso Muerto', subtitle: 'Sube un poco la carga, mismo volumen.', focus: [{ name: 'Peso Muerto', category: 'load' }],
      blocks: [
        b('A', 'Peso Muerto', ['3 × 5 al 73% de tu 1RM · descanso 2-3 min']),
        b('B', 'Accesorio de tirón', ['4 × 10 remo con barra, agarre más ancho', '3 × 15 elevación de talones']),
        b('C', 'Core', ['3 × 15 v-up']),
      ] },
    { heading: 'Front Squat + Press', subtitle: 'Cierra la semana.', focus: [{ name: 'Front Squat', category: 'load' }],
      blocks: [
        b('A', 'Front Squat', ['4 × 6 al 68% de tu 1RM · descanso 2 min']),
        b('B', 'Accesorio de empuje', ['3 × 10 press con mancuernas, algo más de peso']),
        b('C', 'Core', ['3 × 30 s plancha lateral por lado']),
      ] },
  ],
  4: [
    { heading: 'Back Squat + Press', subtitle: 'Bajan las repeticiones, sube la carga.', focus: [{ name: 'Back Squat', category: 'load' }, { name: 'Press Militar', category: 'load' }],
      blocks: [
        b('A', 'Back Squat', ['5 × 5 al 76% de tu 1RM · descanso 2-3 min']),
        b('B', 'Press Militar', ['5 × 5 al 71% de tu 1RM · descanso 90 s']),
        b('C', 'Core', ['3 × 15 pallof press por lado']),
      ] },
    { heading: 'Peso Muerto', subtitle: 'Empieza el bloque de fuerza.', focus: [{ name: 'Peso Muerto', category: 'load' }],
      blocks: [
        b('A', 'Peso Muerto', ['4 × 4 al 76% de tu 1RM · descanso 2-3 min']),
        b('B', 'Accesorio de tirón', ['4 × 8 remo con barra, más peso que la semana pasada']),
        b('C', 'Core', ['3 × 20 hollow rock']),
      ] },
    { heading: 'Front Squat + Press', subtitle: 'Cierra la semana.', focus: [{ name: 'Front Squat', category: 'load' }],
      blocks: [
        b('A', 'Front Squat', ['5 × 5 al 71% de tu 1RM · descanso 2-3 min']),
        b('B', 'Accesorio de empuje', ['4 × 8 fondos en paralelas o press con mancuernas']),
        b('C', 'Core', ['3 × 40 s plancha lateral por lado']),
      ] },
  ],
  5: [
    { heading: 'Back Squat + Press', subtitle: 'Sigue subiendo. Si fallas, repite el peso, no lo subas.', focus: [{ name: 'Back Squat', category: 'load' }, { name: 'Press Militar', category: 'load' }],
      blocks: [
        b('A', 'Back Squat', ['4 × 4 al 80% de tu 1RM · descanso 3 min']),
        b('B', 'Press Militar', ['4 × 4 al 75% de tu 1RM · descanso 2 min']),
        b('C', 'Core', ['3 × 15 pallof press por lado']),
      ] },
    { heading: 'Peso Muerto', subtitle: 'Series más cortas, más pesadas.', focus: [{ name: 'Peso Muerto', category: 'load' }],
      blocks: [
        b('A', 'Peso Muerto', ['3 × 3 al 80% de tu 1RM · descanso 3 min']),
        b('B', 'Accesorio de tirón', ['3 × 8 remo con barra pesado']),
        b('C', 'Core', ['3 × 20 s hollow hold']),
      ] },
    { heading: 'Front Squat + Press', subtitle: 'Cierra la semana.', focus: [{ name: 'Front Squat', category: 'load' }],
      blocks: [
        b('A', 'Front Squat', ['4 × 4 al 75% de tu 1RM · descanso 3 min']),
        b('B', 'Accesorio de empuje', ['4 × 6 fondos con lastre ligero o press con mancuernas pesado']),
        b('C', 'Core', ['3 × 45 s plancha lateral por lado']),
      ] },
  ],
  6: [
    { heading: 'Back Squat + Press', subtitle: 'Series cortas, pesos altos, movimiento rápido.', focus: [{ name: 'Back Squat', category: 'load' }, { name: 'Press Militar', category: 'load' }],
      blocks: [
        b('A', 'Back Squat', ['4 × 3 al 84% de tu 1RM · descanso 3 min']),
        b('B', 'Press Militar', ['4 × 3 al 79% de tu 1RM · descanso 2 min']),
        b('C', 'Core', ['3 × 15 pallof press por lado']),
      ] },
    { heading: 'Peso Muerto', subtitle: 'La sesión más pesada hasta ahora.', focus: [{ name: 'Peso Muerto', category: 'load' }],
      blocks: [
        b('A', 'Peso Muerto', ['3 × 2 al 84% de tu 1RM · descanso 3 min']),
        b('B', 'Accesorio de tirón', ['3 × 6 remo con barra pesado']),
        b('C', 'Core', ['3 × 20 s hollow hold']),
      ] },
    { heading: 'Front Squat + Press', subtitle: 'Cierra la semana.', focus: [{ name: 'Front Squat', category: 'load' }],
      blocks: [
        b('A', 'Front Squat', ['4 × 3 al 79% de tu 1RM · descanso 3 min']),
        b('B', 'Accesorio de empuje', ['3 × 6 fondos con lastre o press pesado']),
        b('C', 'Core', ['3 × 45 s plancha lateral por lado']),
      ] },
  ],
  7: [
    { heading: 'Back Squat + Press', subtitle: 'La semana más pesada del bloque.', focus: [{ name: 'Back Squat', category: 'load' }, { name: 'Press Militar', category: 'load' }],
      blocks: [
        b('A', 'Back Squat', ['3 × 2 al 88% de tu 1RM + 1 × 1 al 92% si la técnica es sólida · descanso 3 min']),
        b('B', 'Press Militar', ['3 × 2 al 83% de tu 1RM · descanso 2 min']),
        b('C', 'Core', ['2 × 15 pallof press por lado'], 'Volumen bajo a propósito: ya has hecho suficiente esta semana.'),
      ] },
    { heading: 'Peso Muerto', subtitle: 'Pico del ciclo en este levantamiento.', focus: [{ name: 'Peso Muerto', category: 'load' }],
      blocks: [
        b('A', 'Peso Muerto', ['3 × 1 al 88% de tu 1RM · descanso 3-4 min'], 'Si la barra se ralentiza mucho o pierdes la espalda neutra, para: no busques un PR esta semana.'),
        b('B', 'Accesorio de tirón', ['2 × 8 remo con barra ligero']),
        b('C', 'Movilidad', ['Movilidad de cadera · 8 min']),
      ] },
    { heading: 'Front Squat + Press', subtitle: 'Cierra el bloque de pico.', focus: [{ name: 'Front Squat', category: 'load' }],
      blocks: [
        b('A', 'Front Squat', ['3 × 2 al 83% de tu 1RM · descanso 3 min']),
        b('B', 'Accesorio de empuje', ['2 × 8 press con mancuernas ligero']),
        b('C', 'Cierre', ['Movilidad y respiración · 10 min'], 'Nada de carga. Empieza la descarga.'),
      ] },
  ],
  8: [
    { heading: 'Descarga', subtitle: 'Mitad de volumen; una serie corta a más peso solo para activar.',
      blocks: [
        b('A', 'Back Squat', ['2 × 5 al 50% de tu 1RM · descanso 90 s', '1 × 2 al 70% de tu 1RM al terminar, solo para activar'], 'La serie a más peso es activación del sistema nervioso, no un esfuerzo: dos repeticiones limpias y sueltas.'),
        b('B', 'Press Militar', ['2 × 5 al 50% de tu 1RM · descanso 90 s', '1 × 2 al 65% de tu 1RM al terminar, solo para activar']),
        b('C', 'Movilidad', ['Movilidad general · 10 min']),
      ] },
    { heading: 'Activación', subtitle: 'Mover, no fatigar.',
      blocks: [
        b('A', 'Front Squat', ['2 × 5 al 50% de tu 1RM']),
        b('B', 'Peso Muerto', ['2 × 5 al 50% de tu 1RM']),
        b('C', 'Movilidad', ['10 min']),
      ] },
    { heading: 'Test final', subtitle: 'Mismo orden, mismo protocolo que la semana 1.', isTest: true,
      blocks: [
        b('A', 'Back Squat, Press, Front Squat y Peso Muerto', ['Escalones de 5-10 kg hasta el 1RM en cada levantamiento', 'Descansa 3-5 min entre intentos pesados, igual que en la semana 1'], 'Si has mejorado el número con la misma técnica, el ciclo ha funcionado.'),
        b('B', 'Compara', ['Anota los cuatro nuevos 1RM y compáralos con la semana 1']),
      ] },
  ],
};

/* ==================================================================== */
/* CrossFit — Tu Primera Dominada (6 semanas)                            */
/* ==================================================================== */

const DOMINADA_WEEK_META: Record<number, WeekMeta> = {
  1: { phase: 'evaluacion', phaseLabel: 'Evaluación de partida', intro: 'No busques dominadas todavía. Busca datos: cuánto aguantas colgado y cómo respondes a la primera asistencia.' },
  2: { phase: 'base', phaseLabel: 'Base — banda gruesa', intro: 'Negativas más lentas, banda gruesa. La bajada debe durar lo que dice el reloj, no lo que aguanten tus brazos.' },
  3: { phase: 'base', phaseLabel: 'Base — reduciendo asistencia', intro: 'Menos banda, misma paciencia. Si la negativa se hace fácil, es momento de quitar ayuda, no de añadir series.' },
  4: { phase: 'fuerza', phaseLabel: 'Fuerza específica — banda fina', intro: 'Primer contacto con tu peso real en la bajada. Va a costar más y eso es la señal de que vas bien.' },
  5: { phase: 'fuerza', phaseLabel: 'Fuerza específica — parciales', intro: 'Esta semana metes el primer intento de dominada completa. Si no sale entera, no pasa nada: sigues sumando negativas.' },
  6: { phase: 'objetivo', phaseLabel: 'La dominada', intro: 'Dos sesiones de activación y una de verdad. Llega descansado a la última: ahí va el intento real.' },
};

const DOMINADA_PROGRAM_DATA: Record<number, ProgramDay[]> = {
  1: [
    { heading: 'Cuánto aguantas colgado', subtitle: 'Punto de partida: sin banda, sin prisa.', focus: [{ name: 'Dead hang', category: 'time' }],
      blocks: [
        b('A', 'Dead hang máximo', ['3 intentos de cuelgue máximo · descanso 3 min', 'Anota el mejor tiempo de los tres'], 'Agarre prono, hombros activos: no cuelgues como un péndulo muerto.'),
        b('B', 'Activación escapular', ['4 × 8 scapular pulls colgado (sube y baja los hombros sin doblar el codo)', '3 × 10 remo invertido con banda de asistencia total']),
        b('C', 'Agarre y core', ['3 × 20 s farmer carry con mancuernas pesadas', '3 × 12 dead bug']),
        b('D', 'Diagnóstico rápido de tu punto débil', ['Cuelga de la barra e intenta iniciar el tirón: ¿fallas nada más despegar (abajo) o te quedas a medio camino / cerca de la barra (arriba)?', 'Anota dónde fallas — eso decide si en la semana 4 priorizas los tirones parciales de abajo o los holds cerca de la barra'], 'La banda elástica ayuda más en el cuelgue y menos cerca de la barbilla, así que interesa saber cuál es tu punto débil real antes de fiarlo todo a la banda.'),
      ] },
    { heading: 'Primeras negativas asistidas', subtitle: 'Banda gruesa, bajada controlada.', focus: [{ name: 'Negativas asistidas', category: 'reps' }],
      blocks: [
        b('A', 'Negativa con banda gruesa', ['5 × 3 negativas · banda gruesa · bajada de 5 s', 'Descanso 2 min entre series'], 'Sube con salto o escalón; baja tú solo controlando el ritmo.'),
        b('B', 'Remo invertido', ['4 × 8 remo invertido, pies en el suelo · descanso 90 s']),
        b('C', 'Core colgado', ['3 × 10 elevación de rodillas colgado', '3 × 15 s plancha']),
      ] },
    { heading: 'Volumen ligero y agarre', subtitle: 'Cierra la semana sin fatiga acumulada.', focus: [{ name: 'Dead hang', category: 'time' }],
      blocks: [
        b('A', 'Cuelgues repetidos', ['5 × 15-20 s dead hang · descanso 90 s']),
        b('B', 'Remo invertido asistido', ['4 × 10 remo invertido asistido con banda']),
        b('C', 'Agarre', ['3 × 30 s cuelgue con toalla o agarre neutro', '3 × 12 curl con banda']),
      ] },
  ],
  2: [
    { heading: 'Negativas más lentas', subtitle: 'Bajada de 8 segundos, banda gruesa todavía.', focus: [{ name: 'Negativas', category: 'time' }],
      blocks: [
        b('A', 'Negativa controlada', ['5 × 3 negativas de 8 s · banda gruesa · descanso 2 min'], 'Si te caes antes de 6 s, sube un grosor de banda.'),
        b('B', 'Remo invertido pesado', ['4 × 10 remo invertido, pies elevados en un cajón']),
        b('C', 'Core', ['3 × 12 elevación de rodillas colgado', '3 × 20 s hollow hold']),
      ] },
    { heading: 'Fuerza de tirón horizontal', subtitle: 'El remo invertido es tu dominada en horizontal.',
      blocks: [
        b('A', 'Remo invertido', ['5 × 8 remo invertido, pies en el suelo · descanso 90 s']),
        b('B', 'Negativas', ['4 × 3 negativas de 8 s · banda gruesa']),
        b('C', 'Agarre', ['3 × 30 s dead hang con agarre neutro', '3 × 15 curl con banda']),
      ] },
    { heading: 'Cierre de semana', subtitle: 'Consolida técnica, no busques fatiga.', focus: [{ name: 'Remo invertido', category: 'reps' }],
      blocks: [
        b('A', 'Remo invertido', ['4 × 10 remo invertido, pies en el suelo']),
        b('B', 'Negativas ligeras', ['4 × 3 negativas de 6-8 s · banda gruesa']),
        b('C', 'Core y agarre', ['3 × 15 dead bug', '3 × 30 s cuelgue activo']),
      ] },
  ],
  3: [
    { heading: 'Reduce la banda', subtitle: 'Pasa a banda media si la gruesa ya no cuesta.', focus: [{ name: 'Negativas', category: 'time' }],
      blocks: [
        b('A', 'Negativa con banda media', ['5 × 3 negativas de 6-8 s · banda media · descanso 2 min'], 'La bajada debe ser lenta y constante, sin caídas bruscas al final. No persigas segundos extra a toda costa: si controlas bien el rango completo, el siguiente paso es una banda más fina, no una bajada más larga.'),
        b('B', 'Remo invertido pesado', ['5 × 8 remo invertido, pies elevados']),
        b('C', 'Agarre', ['3 × 30 s cuelgue con toalla', '3 × 12 farmer carry pesado']),
      ] },
    { heading: 'Volumen de remo', subtitle: 'Más series, mismo peso.',
      blocks: [
        b('A', 'Remo invertido', ['6 × 8 remo invertido, pies elevados · descanso 90 s']),
        b('B', 'Negativas', ['4 × 3 negativas de 8 s · banda media']),
        b('C', 'Core', ['3 × 15 elevación de piernas colgado', '3 × 20 s hollow hold']),
      ] },
    { heading: 'Cierre técnico', subtitle: 'Última sesión antes de la fuerza específica.', focus: [{ name: 'Negativas', category: 'reps' }],
      blocks: [
        b('A', 'Negativas', ['5 × 3 negativas de 10 s · banda media · descanso 2 min'], 'Cuenta en voz alta la bajada: te obliga a no acelerar al final.'),
        b('B', 'Remo invertido', ['4 × 10 remo invertido, pies en el suelo']),
        b('C', 'Agarre y core', ['3 × 30 s dead hang', '3 × 12 dead bug']),
      ] },
  ],
  4: [
    { heading: 'Negativa sin banda', subtitle: 'Primer contacto con tu peso completo en la bajada.', focus: [{ name: 'Negativas', category: 'time' }],
      blocks: [
        b('A', 'Negativa sin banda', ['5 × 1 negativa sin banda · bajada lo más lenta posible · descanso 2-3 min'], 'Sube con escalón o salto asistido. Controla toda la bajada aunque al principio dure solo 3-4 s.'),
        b('B', 'Remo invertido pesado', ['5 × 6 remo invertido con lastre o pies muy elevados']),
        b('C', 'Agarre', ['3 × 30 s cuelgue a una mano alternando', '3 × 15 curl con banda']),
      ] },
    { heading: 'Intentos parciales', subtitle: 'El primer tramo de la dominada, desde abajo.', focus: [{ name: 'Intentos parciales', category: 'reps' }],
      blocks: [
        b('A', 'Dominada parcial — abajo y arriba', ['4 × 3 tirones parciales desde abajo (primeros 15-20 cm) · banda fina · descanso 2 min', '3 × 8-10 s hold con la barbilla cerca de la barra, apoyo de pies en cajón o silla'], 'La banda te ayuda más abajo y menos arriba: si notas que fallas cerca de la barra, el hold de arriba es el que de verdad entrena ese tramo.'),
        b('B', 'Negativa sin banda', ['4 × 1 negativa sin banda']),
        b('C', 'Core', ['3 × 15 elevación de piernas colgado']),
      ] },
    { heading: 'Cierre de semana', subtitle: 'Consolida antes de subir la intensidad.',
      blocks: [
        b('A', 'Negativa sin banda', ['4 × 1 negativa sin banda · descanso 2-3 min']),
        b('B', 'Remo invertido', ['5 × 8 remo invertido pesado']),
        b('C', 'Agarre y core', ['3 × 30 s dead hang', '3 × 20 s hollow hold']),
      ] },
  ],
  5: [
    { heading: 'Banda muy fina', subtitle: 'Casi tu peso completo en la bajada.', focus: [{ name: 'Negativas', category: 'time' }],
      blocks: [
        b('A', 'Negativa con banda muy fina', ['5 × 2 negativas de 6-8 s · banda muy fina · descanso 2 min'], 'La prioridad es controlar con menos ayuda de banda, no alargar el cronómetro: la duración es un termómetro, no el objetivo.'),
        b('B', 'Remo invertido pesado', ['5 × 6 remo invertido con lastre']),
        b('C', 'Agarre', ['3 × 30 s cuelgue a una mano alternando']),
      ] },
    { heading: 'Primer intento completo', subtitle: 'El primer intento real, sin miedo a fallar.', focus: [{ name: 'Intento de dominada', category: 'reps' }],
      blocks: [
        b('A', 'Intento de dominada estricta', ['3 intentos de dominada completa · descanso 3 min'], 'Si no sale entera, cuenta el recorrido conseguido y sigue con negativas.'),
        b('B', 'Negativa sin banda', ['4 × 1 negativa sin banda']),
        b('C', 'Core', ['3 × 15 elevación de piernas colgado']),
      ] },
    { heading: 'Cierre de semana', subtitle: 'Última sesión de preparación antes del examen final.',
      blocks: [
        b('A', 'Negativa con banda fina', ['4 × 2 negativas de 6-8 s · banda muy fina']),
        b('B', 'Remo invertido', ['4 × 8 remo invertido pesado']),
        b('C', 'Agarre y core', ['3 × 30 s dead hang', '3 × 12 dead bug']),
      ] },
  ],
  6: [
    { heading: 'Activación ligera', subtitle: 'Poco volumen, mantén la frescura.', focus: [{ name: 'Dead hang', category: 'time' }],
      blocks: [
        b('A', 'Activación', ['3 × 15 s dead hang · descanso 2 min']),
        b('B', 'Remo invertido ligero', ['3 × 8 remo invertido, pies en el suelo']),
        b('C', 'Movilidad', ['3 × 10 scapular pulls colgado']),
      ] },
    { heading: 'Técnica y frescura', subtitle: 'Repasa el patrón, no acumules fatiga.',
      blocks: [
        b('A', 'Negativa técnica', ['3 × 1 negativa sin banda · bajada controlada · descanso 3 min'], 'Esto es repaso de patrón, no una serie de fuerza. Para si notas temblor excesivo.'),
        b('B', 'Activación de tirón', ['3 × 3 tirones parciales con banda fina']),
        b('C', 'Descanso activo', ['3 × 20 s hollow hold']),
      ] },
    { heading: 'El día de la primera dominada', subtitle: 'Ve con el sistema nervioso fresco. Hoy es el intento real.', focus: [{ name: 'Dominada estricta', category: 'reps' }],
      blocks: [
        b('A', 'Calentamiento específico', ['2 × 10 s dead hang', '2 × 3 tirones parciales con banda fina']),
        b('B', 'Intento de dominada estricta', ['Tantos intentos como necesites · descanso completo de 3-5 min entre cada uno', 'Para en cuanto consigas una dominada limpia, barbilla sobre la barra'], 'La primera cuenta aunque sea fea. No hay bonificación por estilo hoy.'),
        b('C', 'Cierre', ['1 × dead hang hasta el fallo, para comparar con tu marca de la semana 1']),
      ] },
  ],
};

/* ==================================================================== */
/* CrossFit — Gimnásticos Colgado · Nivel 1 (dominadas kipping +         */
/* toes-to-bar) — 6 semanas.                                             */
/* ==================================================================== */

const GIM1_WEEK_META: Record<number, WeekMeta> = {
  1: { phase: 'tecnica', phaseLabel: 'Técnica de kip y base de toes-to-bar', intro: 'El kip se aprende con el balanceo, no con la dominada. Y el toes-to-bar empieza en la rodilla, no en el pie.' },
  2: { phase: 'volumen', phaseLabel: 'Volumen — series cortas', intro: 'Series de pocas repeticiones y descanso completo. Consistencia semana a semana, no series heroicas.' },
  3: { phase: 'volumen', phaseLabel: 'Volumen — sube el número', intro: 'Mismo esquema, más repeticiones por serie. La pierna estirada entra esta semana en el toes-to-bar.' },
  4: { phase: 'densidad', phaseLabel: 'Densidad — series largas', intro: 'Series más largas y menos descanso. Aquí aparecen las primeras toes-to-bar completas con kip.' },
  5: { phase: 'densidad', phaseLabel: 'Densidad — máximos parciales', intro: 'Empuja el volumen por serie al límite que puedas sostener sin romper el ritmo del kip.' },
  6: { phase: 'test', phaseLabel: 'Test de volumen', intro: 'Dos sesiones de activación y el test real: máximo de dominadas kipping y de toes-to-bar sin soltar la barra.' },
};

const GIM1_PROGRAM_DATA: Record<number, ProgramDay[]> = {
  1: [
    { heading: 'Técnica de kip swing', subtitle: 'El balanceo antes que las repeticiones.', focus: [{ name: 'Dominadas kipping', category: 'reps' }],
      blocks: [
        b('A', 'Kip swing', ['5 × 5 balanceos activos colgado de la barra · descanso 90 s'], 'El impulso sale de la cadera y los hombros, no de los brazos.'),
        b('B', 'Hanging knee raises', ['4 × 10 hanging knee raises']),
        b('C', 'Kip + tracción — primeros intentos', ['5 × 2 (2 balanceos + 1 intento de tracción en el punto alto del kip)'], 'No busques enlazar reps todavía: solo siente en qué punto del balanceo hay que tirar.'),
      ] },
    { heading: 'Consolidando el balanceo', subtitle: 'Ritmo antes que fuerza.',
      blocks: [
        b('A', 'Kip swing con transición', ['5 × 5 balanceos + salida de barra']),
        b('B', 'Hanging knee raises', ['4 × 12 hanging knee raises']),
        b('C', 'Dominadas kipping', ['5 × 3 dominadas kipping · descanso 2 min']),
      ] },
    { heading: 'Cierre técnico', subtitle: 'Repasa antes de meter volumen.', focus: [{ name: 'Toes-to-bar progresión', category: 'reps' }],
      blocks: [
        b('A', 'Kip swing', ['4 × 6 balanceos activos']),
        b('B', 'Hanging knee raises', ['4 × 12 hanging knee raises']),
        b('C', 'Core adicional', ['3 × 20 s hollow hold', '3 × 12 dead bug']),
        b('D', 'Dominadas kipping — evaluación', ['Encuentra tu máximo de dominadas kipping sin soltar la barra', 'Para en cuanto pierdas el ritmo del kip, aunque no hayas llegado al fallo muscular', 'Anota el número: será tu referencia para la semana 6']),
      ] },
  ],
  2: [
    { heading: 'Series cortas y consistentes', subtitle: 'Mejor 6 series de 3 que una serie de 12 fallando.', focus: [{ name: 'Dominadas kipping', category: 'reps' }],
      blocks: [
        b('A', 'Dominadas kipping', ['6 × 3 dominadas kipping · descanso 90 s'], 'Para siempre 1-2 repeticiones antes del fallo.'),
        b('B', 'Hanging straight-leg raises', ['4 × 8 hanging straight-leg raises']),
        b('C', 'Agarre', ['3 × 30 s cuelgue activo']),
      ] },
    { heading: 'Volumen medio', subtitle: 'Sube el número total de repeticiones esta semana.',
      blocks: [
        b('A', 'Dominadas kipping', ['5 × 4 dominadas kipping · descanso 90 s']),
        b('B', 'Hanging knee raises pesadas', ['4 × 12 hanging knee raises, ritmo controlado']),
        b('C', 'Accesorio', ['3 × 10 remo con mancuerna a un brazo']),
      ] },
    { heading: 'Cierre de semana', subtitle: 'Consolida el volumen conseguido.', focus: [{ name: 'Dominadas kipping', category: 'reps' }],
      blocks: [
        b('A', 'Dominadas kipping', ['6 × 3 dominadas kipping · descanso 2 min']),
        b('B', 'Hanging straight-leg raises', ['4 × 8 hanging straight-leg raises']),
        b('C', 'Core', ['3 × 20 s hollow hold']),
      ] },
  ],
  3: [
    { heading: 'Sube el volumen por serie', subtitle: 'De series de 3 a series de 5.', focus: [{ name: 'Dominadas kipping', category: 'reps' }],
      blocks: [
        b('A', 'Dominadas kipping', ['6 × 5 dominadas kipping · descanso 2 min'], 'Si pierdes el ritmo del kip a mitad de serie, corta ahí.'),
        b('B', 'Hanging straight-leg raises', ['5 × 8 hanging straight-leg raises']),
        b('C', 'Agarre y core', ['3 × 30 s cuelgue activo', '3 × 12 dead bug']),
      ] },
    { heading: 'Densidad ligera', subtitle: 'Menos descanso, mismo volumen.',
      blocks: [
        b('A', 'Dominadas kipping', ['6 × 4 dominadas kipping · descanso 75 s']),
        b('B', 'Hanging straight-leg raises', ['4 × 10 hanging straight-leg raises']),
        b('C', 'Accesorio', ['3 × 12 face pull o band pull apart']),
      ] },
    { heading: 'Cierre de semana', subtitle: 'Último repaso antes de la fase de densidad.', focus: [{ name: 'Toes-to-bar progresión', category: 'reps' }],
      blocks: [
        b('A', 'Dominadas kipping', ['5 × 5 dominadas kipping · descanso 2 min']),
        b('B', 'Rodillas al pecho con kip', ['4 × 5 rodillas al pecho aprovechando el balanceo del kip'], 'Es la primera vez que metes kip en el trabajo de piernas: prioriza el ritmo sobre la altura de la rodilla.'),
        b('C', 'Core', ['3 × 20 s hollow hold']),
      ] },
  ],
  4: [
    { heading: 'Series más largas', subtitle: 'Busca series de 6-8 dominadas kipping.', focus: [{ name: 'Dominadas kipping', category: 'reps' }],
      blocks: [
        b('A', 'Toes-to-bar con kip', ['5 × 3 toes-to-bar con kip, apoyándote en el balanceo · descanso 2 min']),
        b('B', 'Dominadas kipping', ['5 × 6-8 dominadas kipping · descanso 2-3 min'], 'Prioriza terminar la serie completa sobre ir más rápido.'),
        b('C', 'Agarre', ['3 × 30 s cuelgue activo']),
      ] },
    { heading: 'Densidad', subtitle: 'Menos descanso entre series de dominadas.',
      blocks: [
        b('A', 'Toes-to-bar con kip', ['5 × 3 toes-to-bar con kip']),
        b('B', 'Dominadas kipping', ['6 × 5 dominadas kipping · descanso 60-75 s']),
        b('C', 'Core', ['3 × 20 s hollow hold', '3 × 12 dead bug']),
      ] },
    { heading: 'Cierre de semana', subtitle: 'Consolida antes de la última semana de densidad.', focus: [{ name: 'Toes-to-bar unbroken', category: 'reps' }],
      blocks: [
        b('A', 'Toes-to-bar con kip', ['5 × 4 toes-to-bar con kip']),
        b('B', 'Dominadas kipping', ['5 × 6 dominadas kipping · descanso 2 min']),
        b('C', 'Agarre y core', ['3 × 30 s cuelgue activo', '3 × 15 dead bug']),
      ] },
  ],
  5: [
    { heading: 'Volumen alto de dominadas', subtitle: 'Esta semana pide el máximo de tu kip.', focus: [{ name: 'Dominadas kipping', category: 'reps' }],
      blocks: [
        b('A', 'Toes-to-bar con kip', ['5 × 4 toes-to-bar con kip · descanso 2 min'], 'Busca tocar la barra con los pies, no solo subir las rodillas.'),
        b('B', 'Dominadas kipping', ['5 × 8 dominadas kipping · descanso 2-3 min']),
        b('C', 'Agarre', ['3 × 30 s cuelgue activo']),
      ] },
    { heading: 'Densidad máxima', subtitle: 'Series largas, descansos cortos.',
      blocks: [
        b('A', 'Toes-to-bar con kip', ['5 × 5 toes-to-bar con kip']),
        b('B', 'Dominadas kipping', ['6 × 6 dominadas kipping · descanso 60 s']),
        b('C', 'Core', ['3 × 20 s hollow hold']),
      ] },
    { heading: 'Cierre de semana', subtitle: 'Última sesión antes del test de volumen.', focus: [{ name: 'Dominadas kipping', category: 'reps' }],
      blocks: [
        b('A', 'Toes-to-bar con kip', ['5 × 5 toes-to-bar con kip']),
        b('B', 'Dominadas kipping', ['5 × 6-8 dominadas kipping · descanso 2 min']),
        b('C', 'Agarre y core', ['3 × 30 s cuelgue activo', '3 × 15 dead bug']),
      ] },
  ],
  6: [
    { heading: 'Activación ligera', subtitle: 'Poco volumen antes del test.',
      blocks: [
        b('A', 'Activación de kip', ['3 × 3 dominadas kipping · descanso 2 min']),
        b('B', 'Toes-to-bar ligero', ['3 × 3 toes-to-bar con kip']),
        b('C', 'Movilidad', ['3 × 10 scapular pulls colgado']),
      ] },
    { heading: 'Técnica y frescura', subtitle: 'Repasa el patrón, no acumules fatiga.',
      blocks: [
        b('A', 'Kip técnico', ['3 × 3 dominadas kipping · descanso 2 min']),
        b('B', 'Toes-to-bar técnico', ['3 × 3 toes-to-bar con kip']),
        b('C', 'Descanso activo', ['3 × 20 s hollow hold']),
      ] },
    { heading: 'Test de volumen', subtitle: 'Máximo de dominadas kipping y de toes-to-bar sin soltar la barra.', focus: [{ name: 'Dominadas kipping sin soltar', category: 'reps' }, { name: 'Toes-to-bar unbroken', category: 'reps' }],
      blocks: [
        b('A', 'Test de dominadas kipping', ['Máximo de dominadas kipping sin soltar la barra · descanso completo de 5 min antes'], 'Cuenta solo si no sueltas la barra en ningún momento.'),
        b('B', 'Test de toes-to-bar', ['Máximo de toes-to-bar unbroken sin soltar la barra']),
        b('C', 'Cierre', ['Compara ambos números con tu marca de la semana 1 y anótalos']),
      ] },
  ],
};

/* ==================================================================== */
/* CrossFit — Gimnásticos Colgado · Nivel 2 (chest-to-bar + bar          */
/* muscle-up) — 6 semanas.                                               */
/* ==================================================================== */

const GIM2_WEEK_META: Record<number, WeekMeta> = {
  1: { phase: 'evaluacion', phaseLabel: 'Evaluación y tirón alto', intro: 'Antes de sumar volumen necesitas saber dónde estás hoy. Mide tu swing, tu tirón alto y cuántas chest-to-bar seguidas consigues sin soltar la barra.' },
  2: { phase: 'volumen', phaseLabel: 'Volumen de chest-to-bar', intro: 'Empiezas a sumar repeticiones en series cortas y a tocar por primera vez la mecánica del muscle-up con mucha ayuda.' },
  3: { phase: 'volumen', phaseLabel: 'Volumen y primeras transiciones', intro: 'Más chest-to-bar por sesión y más contacto con la transición asistida. La técnica manda sobre la fatiga.' },
  4: { phase: 'refinamiento', phaseLabel: 'Refinamiento de la transición', intro: 'Bajamos la asistencia de la banda y empezamos a hablar del código de muñeca y codo en la transición.' },
  5: { phase: 'refinamiento', phaseLabel: 'Transición fina', intro: 'Banda cada vez más fina, chest-to-bar denso y una transición que ya debería sentirse tuya, no prestada.' },
  6: { phase: 'objetivo', phaseLabel: 'Intento de bar muscle-up', intro: 'Las dos primeras sesiones son técnica y activación. El viernes vas a por tu primer bar muscle-up real.' },
};

const GIM2_PROGRAM_DATA: Record<number, ProgramDay[]> = {
  1: [
    { heading: 'Test de chest-to-bar', subtitle: 'Descansa bien entre series: buscamos tu máximo real, no fatiga acumulada.',
      focus: [{ name: 'Chest-to-bar unbroken', category: 'reps' }],
      blocks: [
        b('A', 'Activación de hombro', ['3 × 10 dislocaciones con banda o palo', '3 × 15 face pull', '2 × 30 s cuelgue activo en la barra']),
        b('B', 'Test principal', ['Encuentra tu máximo de chest-to-bar seguidas sin soltar la barra', 'Repite el test 3 veces con 3 min de descanso y anota el mejor'], 'Para que cuente el chest-to-bar el pecho debe tocar la barra, no solo la barbilla.'),
        b('C', 'Tirón alto · técnica', ['4 × 3 chest-to-bar con kip controlado, sin prisa · descanso 90 s'], 'Piensa en llevar el esternón a la barra, no en subir la barbilla.'),
        b('D', 'Test de fondos en paralelas', ['Encuentra tu máximo de fondos en paralelas estrictos, con pausa arriba y abajo', 'Si no llegas a 8 fondos estrictos, dedica esta semana y la siguiente a sumar fondos antes de subir el volumen de muscle-up de la semana 2'], 'La transición falla tanto por tirón débil como por empuje débil: necesitas los dos.'),
      ] },
    { heading: 'Técnica de tirón alto', subtitle: 'El kip se arregla en la fase de tirón, no en el swing.',
      blocks: [
        b('A', 'Swing y ritmo', ['5 × 30 s kipping swing en barra baja o anillas', 'Marca el ritmo tirón-empuje-tirón en voz alta si hace falta']),
        b('B', 'Tirón alto asistido', ['5 × 3 high pull-up con banda ligera · descanso 90 s'], 'La banda debe ayudarte solo en el último tercio del tirón, no en todo el recorrido.'),
        b('C', 'Core para el kip', ['4 × 12 toes-to-bar', '3 × 20 s hollow hold']),
      ] },
    { heading: 'Volumen ligero de chest-to-bar', subtitle: 'Series cortas, técnica limpia, sin llegar al fallo.',
      focus: [{ name: 'Chest-to-bar por serie', category: 'reps' }],
      blocks: [
        b('A', 'Chest-to-bar en series cortas', ['8 × 2 chest-to-bar · descanso 60 s'], 'Prioriza técnica sobre velocidad: cada rep debe tocar limpio.'),
        b('B', 'Complemento de tirón', ['4 × 6 dominadas estrictas con lastre ligero o con banda de ayuda']),
        b('C', 'Accesorio de agarre', ['3 × 20 s cuelgue con toalla o agarre cerrado'], 'En barra no necesitas agarre falso como en anillas: aquí el patrón clave es el giro de muñeca en la transición, que trabajarás a partir de la semana 4.'),
      ] },
  ],
  2: [
    { heading: 'Chest-to-bar denso', subtitle: 'Series más largas, mismo descanso.',
      focus: [{ name: 'Chest-to-bar unbroken', category: 'reps' }],
      blocks: [
        b('A', 'Activación', ['3 × 10 dislocaciones con banda', '2 × 30 s cuelgue activo']),
        b('B', 'Series de chest-to-bar', ['6 × 3 chest-to-bar unbroken · descanso 90 s']),
        b('C', 'Primer contacto con el muscle-up', ['5 × 1 jumping muscle-up desde cajón'], 'Salta guiando los codos hacia atrás y arriba; no fuerces la rotación de muñeca.'),
      ] },
    { heading: 'Transición asistida', subtitle: 'Primera sesión formal de muscle-up con banda gruesa.',
      blocks: [
        b('A', 'Calentamiento de hombro y muñeca', ['2 × 10 rotaciones de muñeca con peso ligero', '2 × 10 remo invertido']),
        b('B', 'Muscle-up con banda gruesa', ['6 × 1 muscle-up con banda gruesa, reseteo completo entre repeticiones · descanso 90 s'], 'Es tu primer contacto formal con la transición completa: van sueltas, no encadenadas. Para la serie si notas la muñeca cargada o si la técnica se degrada — la próxima sesión ya sí las harás en series de 2.'),
        b('C', 'Fuerza de empuje', ['4 × 8 fondos en paralelas o en anillas bajas']),
      ] },
    { heading: 'Volumen y densidad', subtitle: 'Chest-to-bar por minuto, sin perder la técnica al final.',
      focus: [{ name: 'Chest-to-bar unbroken', category: 'reps' }],
      blocks: [
        b('A', 'EMOM de chest-to-bar', ['EMOM 8 min: 3 chest-to-bar por minuto']),
        b('B', 'Jumping muscle-up', ['5 × 2 jumping muscle-up desde cajón'], 'Si golpeas la muñeca al recibir, baja la altura del cajón.'),
        b('C', 'Core', ['3 × 15 toes-to-bar', '3 × 20 s hollow hold']),
      ] },
  ],
  3: [
    { heading: 'Chest-to-bar en fatiga controlada', subtitle: 'Simulamos un poco de fatiga antes de tirar.',
      focus: [{ name: 'Chest-to-bar unbroken', category: 'reps' }],
      blocks: [
        b('A', 'Activación', ['3 × 10 dislocaciones con banda', '2 × 30 s cuelgue activo']),
        b('B', 'Chest-to-bar tras esfuerzo', ['3 rondas: 10 burpees + 5 chest-to-bar · descanso 2 min'], 'El objetivo es mantener la técnica del tirón incluso con el pulso alto.'),
        b('C', 'Muscle-up con banda gruesa', ['5 × 2 muscle-up con banda gruesa · descanso 2 min']),
      ] },
    { heading: 'Transición · segundo contacto', subtitle: 'Más volumen de transición, misma banda.',
      blocks: [
        b('A', 'Calentamiento de muñeca y codo', ['2 × 10 rotaciones de muñeca', '2 × 10 extensión de tríceps con banda']),
        b('B', 'Muscle-up con banda gruesa', ['7 × 2 muscle-up con banda gruesa · descanso 2 min'], 'Marca la pausa arriba en el fondo: consolida la posición final antes de bajar.'),
        b('C', 'Fuerza de empuje', ['4 × 10 fondos en paralelas']),
      ] },
    { heading: 'Volumen denso de chest-to-bar', subtitle: 'Cierre de bloque de volumen.',
      focus: [{ name: 'Chest-to-bar unbroken', category: 'reps' }],
      blocks: [
        b('A', 'Series largas', ['5 × 4 chest-to-bar unbroken · descanso 2 min']),
        b('B', 'Jumping muscle-up', ['6 × 2 jumping muscle-up desde cajón']),
        b('C', 'Accesorio', ['3 × 12 remo con mancuerna a un brazo', '3 × 15 face pull']),
      ] },
  ],
  4: [
    { heading: 'Banda fina · primer contacto', subtitle: 'Menos asistencia, más control.',
      focus: [{ name: 'Muscle-ups con banda', category: 'reps' }],
      blocks: [
        b('A', 'Activación', ['3 × 10 dislocaciones con banda', '2 × 30 s cuelgue activo']),
        b('B', 'Muscle-up con banda fina', ['6 × 2 muscle-up con banda fina (violeta o roja) · descanso 2 min'], 'El código de muñeca: rota la muñeca por encima de la barra en el mismo instante en que el pecho la sobrepasa. No esperes a estar arriba del todo.'),
        b('C', 'Chest-to-bar denso', ['4 × 4 chest-to-bar unbroken · descanso 90 s']),
      ] },
    { heading: 'Codo y muñeca en la transición', subtitle: 'Trabajo específico de la fase más técnica del movimiento.',
      blocks: [
        b('A', 'Drill de codos altos', ['5 × 3 tirón explosivo a barra alta seguido de pausa con codos por delante de la muñeca'], 'Si sientes pinchazo en la muñeca al pasar, es que estás llegando tarde con la rotación: adelántala.'),
        b('B', 'Muscle-up con banda fina', ['6 × 2 muscle-up con banda fina · descanso 2 min'], 'Con banda más fina la muñeca recibe más carga real. En cuanto notes un pinchazo (no solo cansancio) en la muñeca, para la serie y termina la sesión con la banda gruesa de la semana anterior.'),
        b('C', 'Fuerza de empuje', ['4 × 10 fondos en paralelas con pausa de 2 s abajo']),
      ] },
    { heading: 'Volumen combinado', subtitle: 'Chest-to-bar y muscle-up en la misma sesión.',
      focus: [{ name: 'Muscle-ups con banda', category: 'reps' }],
      blocks: [
        b('A', 'Chest-to-bar', ['5 × 3 chest-to-bar unbroken · descanso 90 s']),
        b('B', 'Muscle-up con banda fina', ['7 × 2 muscle-up con banda fina · descanso 2 min']),
        b('C', 'Core', ['3 × 15 toes-to-bar']),
      ] },
  ],
  5: [
    { heading: 'Banda mínima', subtitle: 'Última reducción de asistencia antes del intento real.',
      focus: [{ name: 'Muscle-ups con banda', category: 'reps' }],
      blocks: [
        b('A', 'Activación', ['3 × 10 dislocaciones con banda', '2 × 30 s cuelgue activo']),
        b('B', 'Muscle-up con banda mínima', ['5 × 2 muscle-up con banda mínima (negra fina o sin banda con salto asistido) · descanso 2 min'], 'Si notas que la banda ya casi no trabaja, es buena señal: el cuerpo está aprendiendo el patrón real.'),
        b('C', 'Chest-to-bar', ['4 × 4 chest-to-bar unbroken · descanso 90 s']),
      ] },
    { heading: 'Repaso del código de transición', subtitle: 'Repetición de patrón sin buscar cansancio.',
      blocks: [
        b('A', 'Drill de codos altos', ['5 × 3 tirón explosivo con pausa de codos altos']),
        b('B', 'Muscle-up con banda mínima', ['6 × 2 muscle-up con banda mínima · descanso 2 min'], 'Controla la bajada: baja siempre con control, nunca sueltes en caída libre desde arriba.'),
        b('C', 'Fuerza de empuje', ['3 × 10 fondos en anillas']),
      ] },
    { heading: 'Última sesión de banda', subtitle: 'Cierre del bloque de refinamiento.',
      focus: [{ name: 'Muscle-ups con banda', category: 'reps' }],
      blocks: [
        b('A', 'Chest-to-bar', ['4 × 3 chest-to-bar unbroken · descanso 90 s']),
        b('B', 'Muscle-up con banda mínima', ['6 × 2 muscle-up con banda mínima · descanso 2 min']),
        b('C', 'Accesorio', ['3 × 12 remo con mancuerna a un brazo']),
      ] },
  ],
  6: [
    { heading: 'Técnica y activación', subtitle: 'Sin volumen alto: guardamos energía para el viernes.',
      blocks: [
        b('A', 'Activación de hombro y muñeca', ['3 × 10 dislocaciones con banda', '2 × 30 s cuelgue activo']),
        b('B', 'Repaso técnico', ['4 × 2 muscle-up con banda mínima · descanso 2 min'], 'Enfócate en el timing de la rotación de muñeca, no en la fuerza.'),
        b('C', 'Chest-to-bar suave', ['3 × 3 chest-to-bar unbroken · descanso 90 s']),
      ] },
    { heading: 'Activación ligera', subtitle: 'Sesión corta, intensidad baja, patrón limpio.',
      blocks: [
        b('A', 'Movilidad de hombro', ['3 × 10 dislocaciones con banda o palo']),
        b('B', 'Patrón de transición', ['3 × 2 muscle-up con banda mínima · descanso 2 min']),
        b('C', 'Descarga', ['2 × 20 s cuelgue activo', '2 × 10 remo invertido']),
      ] },
    { heading: 'Intento de bar muscle-up', subtitle: 'Ve descansado. Hoy no hay reloj: solo el patrón.',
      focus: [{ name: 'Bar muscle-up', category: 'reps' }],
      blocks: [
        b('A', 'Activación completa', ['3 × 10 dislocaciones con banda', '3 × 30 s cuelgue activo', '10 balanceos de muñeca en apoyo de manos en el suelo, cargando el peso adelante y atrás', '5 × 3 tirón explosivo a barra alta'], 'El balanceo de muñeca en el suelo replica la carga en extensión que vas a sentir en la transición: mejor sentirla por primera vez aquí que en tu primer intento.'),
        b('B', 'Intentos de bar muscle-up', ['Hasta 8 intentos de bar muscle-up estricto o con kip · descanso 2-3 min entre intentos'], 'Para en cuanto la técnica se degrade o sientas la muñeca cargada: la calidad del intento importa más que la cantidad.'),
        b('C', 'Cierre', ['Si consigues el muscle-up, repite 2-3 veces más para consolidar la sensación', 'Si no, cierra con 3 × 2 muscle-up con banda mínima para terminar en positivo']),
      ] },
  ],
};

/* ==================================================================== */
/* CrossFit — Anillas: Camino al Ring Muscle-Up (8 semanas)              */
/* ==================================================================== */

const RMU_WEEK_META: Record<number, WeekMeta> = {
  1: { phase: 'evaluacion', phaseLabel: 'Evaluación en anillas', intro: 'Las anillas se mueven: antes de nada necesitamos saber cuánto aguantas quieto, cuánto empujas y cómo se siente tu agarre falso.' },
  2: { phase: 'base', phaseLabel: 'Falso agarre y fondos profundos', intro: 'Construimos la base de fuerza específica: falso agarre sostenido, fondos profundos y primer contacto con la transición baja asistida.' },
  3: { phase: 'base', phaseLabel: 'Transiciones bajas asistidas', intro: 'Más volumen de falso agarre y las primeras transiciones completas, con las anillas casi a la altura del pecho y mucha ayuda de banda.' },
  4: { phase: 'progresion', phaseLabel: 'Dominadas explosivas con falso agarre', intro: 'Bajamos ligeramente la asistencia y sumamos explosividad: el tirón tiene que llegar más alto antes de rotar.' },
  5: { phase: 'progresion', phaseLabel: 'Transiciones más altas', intro: 'Las anillas suben de altura y la banda se afina. Cada sesión se parece un poco más al movimiento final.' },
  6: { phase: 'refinamiento', phaseLabel: 'Banda mínima', intro: 'Muy poca asistencia ya. El objetivo es que el patrón se sienta tuyo, no prestado por la banda.' },
  7: { phase: 'refinamiento', phaseLabel: 'Kipping y banda mínima', intro: 'Sumamos la opción de kip para quienes lo necesiten y seguimos reduciendo la asistencia al mínimo tolerable.' },
  8: { phase: 'objetivo', phaseLabel: 'Intento de ring muscle-up', intro: 'Las dos primeras sesiones son descarga y activación. El viernes es el intento real: hombro y muñeca frescos, técnica ante todo.' },
};

const RMU_PROGRAM_DATA: Record<number, ProgramDay[]> = {
  1: [
    { heading: 'Soporte y fondos', subtitle: 'Anillas quietas, control total antes de mover nada.',
      focus: [{ name: 'Support hold', category: 'time' }],
      blocks: [
        b('A', 'Activación de hombro', ['3 × 10 dislocaciones con banda', '2 × 30 s plancha en anillas bajas']),
        b('B', 'Test de soporte', ['3 × máximo tiempo de support hold en anillas · descanso 2 min', 'Anota el mejor tiempo'], 'Brazos bloqueados, anillas giradas ligeramente hacia fuera (turnout), hombros lejos de las orejas.'),
        b('C', 'Fondos en anillas', ['3 × máximo de fondos estrictos en anillas · descanso 2 min'], 'Si las anillas tiemblan mucho, reduce el rango antes que perder el control del turnout.'),
      ] },
    { heading: 'Primer contacto con el falso agarre', subtitle: 'El agarre más incómodo de todo el programa: ve con paciencia.',
      blocks: [
        b('A', 'Movilidad de muñeca', ['3 × 10 rotaciones de muñeca con peso ligero', '2 × 20 s estiramiento de muñeca en extensión']),
        b('B', 'Falso agarre colgado', ['5 × 15-20 s falso agarre colgado en anillas bajas · descanso 90 s'], 'La muñeca debe apoyarse sobre el borde de la anilla, no solo los dedos. Para si sientes dolor agudo, no solo incomodidad.'),
        b('C', 'Dominadas normales', ['3 × 8 dominadas estrictas en anillas']),
      ] },
    { heading: 'Fuerza de empuje y tirón', subtitle: 'Cierre de la semana de evaluación.',
      focus: [{ name: 'Fondos en anillas', category: 'reps' }],
      blocks: [
        b('A', 'Activación', ['3 × 10 dislocaciones con banda']),
        b('B', 'Fondos profundos', ['4 × 6 fondos en anillas con pausa de 2 s abajo · descanso 2 min']),
        b('C', 'Falso agarre + dominada', ['4 × 3 dominadas con falso agarre asistidas por banda ligera · descanso 2 min'], 'Es normal que las primeras veces la muñeca se sienta rara: es una posición nueva para la articulación.'),
      ] },
  ],
  2: [
    { heading: 'Falso agarre denso', subtitle: 'Más tiempo bajo tensión en la posición incómoda.',
      focus: [{ name: 'Falso agarre colgado', category: 'time' }],
      blocks: [
        b('A', 'Activación de muñeca y hombro', ['3 × 10 rotaciones de muñeca', '2 × 30 s plancha en anillas']),
        b('B', 'Falso agarre colgado', ['6 × 20-25 s falso agarre colgado · descanso 90 s']),
        b('C', 'Fondos profundos', ['4 × 8 fondos en anillas · descanso 2 min']),
      ] },
    { heading: 'Primera transición baja asistida', subtitle: 'Anillas casi a la altura del pecho, banda gruesa.',
      blocks: [
        b('A', 'Calentamiento específico', ['3 × 10 dislocaciones con banda', '3 × 15 s falso agarre colgado']),
        b('B', 'Transición baja con banda gruesa', ['6 × 2 ring muscle-up con banda gruesa, anillas a la altura del pecho · descanso 2 min'], 'Con las anillas bajas el riesgo de la muñeca es menor: es el punto de partida más seguro para aprender la rotación.'),
        b('C', 'Falso agarre + dominada', ['4 × 3 dominadas con falso agarre asistidas por banda ligera']),
      ] },
    { heading: 'Volumen combinado', subtitle: 'Falso agarre, fondos y primer contacto de transición en la misma sesión.',
      focus: [{ name: 'Fondos en anillas', category: 'reps' }],
      blocks: [
        b('A', 'Falso agarre colgado', ['5 × 20 s falso agarre colgado · descanso 90 s']),
        b('B', 'Fondos profundos', ['4 × 8 fondos en anillas · descanso 2 min']),
        b('C', 'Transición baja con banda gruesa', ['5 × 2 ring muscle-up con banda gruesa, anillas bajas · descanso 2 min']),
      ] },
  ],
  3: [
    { heading: 'Falso agarre bajo fatiga', subtitle: 'Sostener el agarre falso cuando ya no es la primera serie del día.',
      focus: [{ name: 'Falso agarre colgado', category: 'time' }],
      blocks: [
        b('A', 'Activación', ['3 × 10 rotaciones de muñeca', '2 × 30 s plancha en anillas']),
        b('B', 'Falso agarre denso', ['3 rondas: 20 s falso agarre colgado + 20 s descanso, × 3 dentro de la ronda · descanso 2 min entre rondas']),
        b('C', 'Transición baja con banda gruesa', ['6 × 2 ring muscle-up con banda gruesa, anillas bajas · descanso 2 min']),
      ] },
    { heading: 'Fondos y transición', subtitle: 'Más volumen de transición asistida, misma altura de anillas.',
      blocks: [
        b('A', 'Calentamiento específico', ['3 × 10 dislocaciones con banda', '3 × 15 s falso agarre colgado']),
        b('B', 'Fondos profundos', ['4 × 8 fondos en anillas con pausa abajo · descanso 2 min']),
        b('C', 'Transición baja con banda gruesa', ['6 × 2 ring muscle-up con banda gruesa · descanso 2 min'], 'Marca la pausa arriba en el fondo antes de bajar: consolida la posición final.'),
      ] },
    { heading: 'Cierre de bloque base', subtitle: 'Última sesión con anillas bajas antes de subirlas.',
      focus: [{ name: 'Ring muscle-up con banda', category: 'reps' }],
      blocks: [
        b('A', 'Falso agarre colgado', ['5 × 20 s falso agarre colgado · descanso 90 s']),
        b('B', 'Transición baja con banda gruesa', ['6 × 2 ring muscle-up con banda gruesa, anillas bajas · descanso 2 min'], 'Si las 6 series salen técnicamente limpias, el volumen sigue subiendo la semana que viene: no hace falta forzarlo hoy.'),
        b('C', 'Fuerza de empuje', ['3 × 10 fondos en anillas']),
      ] },
  ],
  4: [
    { heading: 'Dominadas explosivas con falso agarre', subtitle: 'El tirón necesita llegar más alto antes de rotar.',
      focus: [{ name: 'Dominadas con falso agarre', category: 'reps' }],
      blocks: [
        b('A', 'Activación', ['3 × 10 rotaciones de muñeca', '2 × 30 s plancha en anillas']),
        b('B', 'Dominadas explosivas', ['6 × 3 dominadas con falso agarre, lo más explosivas posible · descanso 2 min'], 'Busca que el pecho suba por encima de las anillas, no solo la barbilla.'),
        b('C', 'Fondos profundos', ['4 × 8 fondos en anillas · descanso 2 min']),
      ] },
    { heading: 'Transición con banda media', subtitle: 'Anillas un poco más altas, banda un poco más fina.',
      blocks: [
        b('A', 'Calentamiento específico', ['3 × 10 dislocaciones con banda', '3 × 15 s falso agarre colgado']),
        b('B', 'Transición con banda media', ['6 × 2 ring muscle-up con banda media, anillas a media altura · descanso 2 min'], 'Con menos asistencia el hombro trabaja más en la fase de rotación: si sientes pinchazo, baja un nivel de banda esa sesión.'),
        b('C', 'Dominadas explosivas', ['4 × 3 dominadas con falso agarre explosivas']),
      ] },
    { heading: 'Volumen combinado', subtitle: 'Fuerza y transición en la misma sesión.',
      focus: [{ name: 'Ring muscle-up con banda', category: 'reps' }],
      blocks: [
        b('A', 'Falso agarre colgado', ['4 × 20 s falso agarre colgado · descanso 90 s']),
        b('B', 'Dominadas explosivas', ['5 × 3 dominadas con falso agarre explosivas · descanso 2 min']),
        b('C', 'Transición con banda media', ['6 × 2 ring muscle-up con banda media · descanso 2 min']),
      ] },
  ],
  5: [
    { heading: 'Transiciones más altas', subtitle: 'Las anillas ya están casi a su altura normal de trabajo.',
      focus: [{ name: 'Ring muscle-up con banda', category: 'reps' }],
      blocks: [
        b('A', 'Activación', ['3 × 10 dislocaciones con banda', '2 × 30 s plancha en anillas']),
        b('B', 'Transición con banda media-fina', ['6 × 2 ring muscle-up con banda media-fina, anillas altas · descanso 2 min']),
        b('C', 'Fondos profundos', ['4 × 8 fondos en anillas · descanso 2 min']),
      ] },
    { heading: 'Fuerza específica de rotación', subtitle: 'Trabajo aislado del momento más técnico del movimiento.',
      blocks: [
        b('A', 'Calentamiento de hombro y muñeca', ['3 × 10 rotaciones de muñeca', '3 × 15 s falso agarre colgado']),
        b('B', 'Drill de rotación', ['5 × 3 tirón explosivo con falso agarre hasta el pecho, pausa en el punto de rotación'], 'La muñeca rota justo cuando el pecho pasa el plano de las anillas, ni antes ni después: adelantarla demasiado sobrecarga el hombro.'),
        b('C', 'Transición con banda media-fina', ['6 × 2 ring muscle-up con banda media-fina · descanso 2 min']),
      ] },
    { heading: 'Cierre de bloque de progresión', subtitle: 'Última sesión antes de bajar a banda mínima.',
      focus: [{ name: 'Ring muscle-up con banda', category: 'reps' }],
      blocks: [
        b('A', 'Falso agarre colgado', ['4 × 20 s falso agarre colgado · descanso 90 s']),
        b('B', 'Transición con banda media-fina', ['7 × 2 ring muscle-up con banda media-fina, anillas altas · descanso 2 min']),
        b('C', 'Fuerza de empuje', ['3 × 10 fondos en anillas']),
      ] },
  ],
  6: [
    { heading: 'Banda mínima · primer contacto', subtitle: 'Muy poca ayuda ya: el patrón debe sostenerse casi solo.',
      focus: [{ name: 'Ring muscle-up con banda', category: 'reps' }],
      blocks: [
        b('A', 'Activación completa', ['3 × 10 dislocaciones con banda', '3 × 15 s falso agarre colgado']),
        b('B', 'Transición con banda mínima', ['5 × 2 ring muscle-up con banda mínima · descanso 2-3 min'], 'Controla siempre la bajada: nunca sueltes en caída libre desde el fondo, el hombro lo paga.'),
        b('C', 'Dominadas explosivas', ['3 × 3 dominadas con falso agarre explosivas']),
      ] },
    { heading: 'Repaso técnico sin fatiga', subtitle: 'Pocas repeticiones, máxima calidad.',
      blocks: [
        b('A', 'Calentamiento de hombro y muñeca', ['3 × 10 rotaciones de muñeca', '2 × 30 s plancha en anillas']),
        b('B', 'Transición con banda mínima', ['6 × 1-2 ring muscle-up con banda mínima · descanso 2-3 min']),
        b('C', 'Fondos profundos', ['3 × 8 fondos en anillas · descanso 2 min']),
      ] },
    { heading: 'Volumen en banda mínima', subtitle: 'Cierre de la semana con el patrón casi limpio.',
      focus: [{ name: 'Ring muscle-up con banda', category: 'reps' }],
      blocks: [
        b('A', 'Falso agarre colgado', ['3 × 20 s falso agarre colgado · descanso 90 s']),
        b('B', 'Transición con banda mínima', ['4 × 2 ring muscle-up con banda mínima · descanso 2-3 min'], 'Al bajar de nivel de banda cada repetición exige más al hombro: bajamos el volumen esta semana y lo reconstruimos en la 7.'),
        b('C', 'Accesorio', ['3 × 12 remo con mancuerna a un brazo']),
      ] },
  ],
  7: [
    { heading: 'Kipping asistido', subtitle: 'Para quien lo necesite, sumamos algo de kip a la ecuación.',
      focus: [{ name: 'Ring muscle-up con banda', category: 'reps' }],
      blocks: [
        b('A', 'Activación', ['3 × 10 dislocaciones con banda', '3 × 15 s falso agarre colgado']),
        b('B', 'Kipping muscle-up con banda mínima', ['5 × 2 ring muscle-up con kip y banda mínima · descanso 2-3 min'], 'El kip en anillas es más inestable que en barra: si las anillas se abren o giran demasiado, vuelve un momento a la versión estricta.'),
        b('C', 'Fondos profundos', ['3 × 8 fondos en anillas']),
      ] },
    { heading: 'Repaso estricto sin banda', subtitle: 'Quitamos la banda, no metemos kip: una variable nueva por sesión.',
      blocks: [
        b('A', 'Calentamiento completo', ['3 × 10 rotaciones de muñeca', '2 × 30 s plancha en anillas', '3 × 15 s falso agarre colgado']),
        b('B', 'Transición sin banda, estricta', ['4-6 × 1 ring muscle-up estricto sin banda · descanso 2-3 min'], 'Hoy quitamos la banda pero mantenemos el patrón estricto, sin kip: cambiar banda y kip en la misma sesión dispara el riesgo de hombro y muñeca. El kip vuelve la próxima sesión, ya sin banda. Si dos intentos seguidos salen técnicamente mal, vuelve a la banda mínima esa sesión: mejor consolidar que forzar en falso.'),
        b('C', 'Dominadas explosivas', ['3 × 3 dominadas con falso agarre explosivas']),
      ] },
    { heading: 'Última sesión antes de la descarga', subtitle: 'Sin banda y con kip si hace falta: las dos variables ya validadas por separado.',
      focus: [{ name: 'Ring muscle-up', category: 'reps' }],
      blocks: [
        b('A', 'Falso agarre colgado', ['3 × 20 s falso agarre colgado · descanso 90 s']),
        b('B', 'Transición sin banda, estricta o con kip', ['6 × 1-2 ring muscle-up sin banda, estricto o con kip según sensación · descanso 2-3 min'], 'Escucha la muñeca antes que el ego: si aparece un pinchazo (no solo fatiga muscular), para el intento y vuelve a banda mínima el resto de la sesión.'),
        b('C', 'Fuerza de empuje', ['3 × 8 fondos en anillas']),
      ] },
  ],
  8: [
    { heading: 'Descarga y activación', subtitle: 'Volumen bajo esta semana: guardamos energía para el viernes.',
      blocks: [
        b('A', 'Activación de hombro y muñeca', ['3 × 10 dislocaciones con banda', '3 × 15 s falso agarre colgado']),
        b('B', 'Repaso técnico', ['4 × 1 ring muscle-up con banda mínima · descanso 2-3 min'], 'Enfócate en el timing de la rotación, no en la fuerza.'),
        b('C', 'Fondos suaves', ['2 × 6 fondos en anillas']),
      ] },
    { heading: 'Activación ligera', subtitle: 'Sesión corta, patrón limpio, sin acumular fatiga.',
      blocks: [
        b('A', 'Movilidad de hombro y muñeca', ['3 × 10 rotaciones de muñeca', '2 × 20 s plancha en anillas']),
        b('B', 'Patrón de transición', ['3 × 1 ring muscle-up con banda mínima · descanso 2-3 min']),
        b('C', 'Descarga', ['2 × 15 s falso agarre colgado', '2 × 8 dominadas normales suaves']),
      ] },
    { heading: 'Intento de ring muscle-up', subtitle: 'Ve descansado. Hoy no hay reloj: solo el patrón y la sensación de las anillas.',
      focus: [{ name: 'Ring muscle-up', category: 'reps' }],
      blocks: [
        b('A', 'Activación completa', ['3 × 10 dislocaciones con banda', '3 × 20 s falso agarre colgado', '3 × 3 tirón explosivo con falso agarre']),
        b('B', 'Intentos de ring muscle-up', ['Hasta 6 intentos de ring muscle-up estricto o con kip · descanso 3 min entre intentos'], 'Este es el movimiento con más riesgo de hombro y muñeca de los cinco programas: para en cuanto notes pinchazo, fatiga en la rotación o pérdida de control en la bajada. La calidad del intento importa más que la cantidad.'),
        b('C', 'Cierre', ['Si consigues el muscle-up, repite 1-2 veces más con calma para consolidar la sensación', 'Si no, cierra con 3 × 2 ring muscle-up con banda mínima para terminar en positivo']),
      ] },
  ],
};

/* ==================================================================== */
/* Hyrox — Mejora tu Carrera (8 semanas): la habilidad más específica de */
/* Hyrox — correr con las piernas ya fatigadas por la estación anterior. */
/* ==================================================================== */

const CARRERA_TEST_FIELDS: TestFieldDef[] = [
  { key: 'run1kmTime', label: '1 km liso (fresco)', placeholder: 'mm:ss' },
  { key: 'compromisedRunTime', label: '1 km tras 50 burpees', placeholder: 'mm:ss' },
  { key: 'run5kmTime', label: '5 km continuos', placeholder: 'mm:ss' },
];

const CARRERA_TEST_ROWS: TestRowDef[] = [
  { label: '1 km liso (fresco)', key: 'run1kmTime', category: 'time' },
  { label: '1 km tras 50 burpees', key: 'compromisedRunTime', category: 'time' },
  { label: '5 km continuos', key: 'run5kmTime', category: 'time' },
];

const CARRERA_WEEK_META: Record<number, WeekMeta> = {
  1: { phase: 'test', phaseLabel: 'Test y familiarización', intro: 'Esta semana mide tres cosas: tu ritmo en fresco, cómo corres con las piernas cargadas y tu base aeróbica. Son tus tres referencias para las próximas 8 semanas.' },
  2: { phase: 'base', phaseLabel: 'Base aeróbica', intro: 'Rodajes suaves y técnica de zancada. Si puedes hablar mientras corres, vas al ritmo correcto.' },
  3: { phase: 'base', phaseLabel: 'Base', intro: 'Entra el primer trabajo de series cortas. La técnica manda sobre la velocidad.' },
  4: { phase: 'base', phaseLabel: 'Base', intro: 'Cierre del bloque aeróbico. La sesión de referencia de esta semana marca tu ritmo crítico/VO2máx para las series de las próximas semanas.' },
  5: { phase: 'specific', phaseLabel: 'Carrera comprometida', intro: 'Empieza lo específico de Hyrox: correr con las piernas ya cargadas por el esfuerzo anterior. Aquí se gana o se pierde la carrera real.' },
  6: { phase: 'specific', phaseLabel: 'Carrera comprometida', intro: 'Sube el volumen de carrera fatigada. Si entrenas 5-6 días en el box, valora quitar una clase esta semana.' },
  7: { phase: 'specific', phaseLabel: 'Carrera comprometida · la más dura', intro: 'El pico del ciclo. A partir de aquí solo se descarga.' },
  8: { phase: 'deload', phaseLabel: 'Descarga y test final', intro: 'Baja el volumen a la mitad. El objetivo es llegar fresco al test, no seguir entrenando fuerte hasta el final.' },
};

const CARRERA_PROGRAM_DATA: Record<number, ProgramDay[]> = {
  1: [
    { heading: 'Test: 1 km fresco y 1 km fatigado', subtitle: 'El número que de verdad importa en Hyrox: cuánto se cae tu ritmo con las piernas cargadas.', isTest: true,
      blocks: [
        b('A', 'Test 1 · 1 km liso', ['1 km a máximo esfuerzo sostenible · anota el tiempo', 'Descansa 8-10 min trotando suave antes de continuar'], 'Ritmo parejo: el primer y el último 250 m no deberían diferenciarse en más de 3-4 segundos.'),
        b('B', 'Puente de fatiga', ['50 burpees seguidos, ritmo constante'], 'No sprintes los burpees: el objetivo es llegar con las piernas cargadas, no con los brazos reventados.'),
        b('C', 'Test 2 · 1 km fatigado', ['1 km inmediatamente después de los burpees, mismo esfuerzo máximo'], 'Compara con el tiempo del test 1: esa diferencia es justo lo que este programa quiere reducir.'),
      ] },
    { heading: 'Test: 5 km continuos', subtitle: 'Tu marcador de base aeróbica para las 8 semanas.', isTest: true,
      blocks: [
        b('A', '5 km continuos', ['5 km al ritmo más rápido que puedas sostener sin parar', 'Anota el tiempo total'], 'Empieza controlado: es mejor acelerar el último kilómetro que reventarte en el segundo.'),
      ] },
    { heading: 'Técnica de carrera', subtitle: 'Cadencia y postura antes que ritmo.',
      blocks: [
        b('A', 'Drills de técnica · 10 min', ['4 × 20 m skipping bajo', '4 × 20 m skipping alto', '4 × 20 m talón-glúteo'], 'Busca 170-180 pasos por minuto: cuenta los pasos de un pie durante 15 s y multiplica por 4.'),
        b('B', 'Progresiones', ['4 × 80 m progresivo, de trote a rápido · vuelta caminando']),
        b('C', 'Rodaje suave', ['15 min a ritmo conversación'], 'Debes poder hablar en frases completas todo el rato.'),
      ] },
  ],
  2: [
    { heading: 'Rodaje base + técnica', subtitle: 'Aeróbico puro.', focus: [{ name: 'Rodaje', category: 'time' }],
      blocks: [
        b('A', 'Técnica', ['3 × 20 m skipping alto', '3 × 20 m talón-glúteo']),
        b('B', 'Rodaje continuo', ['25 min a ritmo conversación'], 'Ritmo fácil: si no puedes hablar, vas demasiado rápido.'),
        b('C', 'Fuerza para correr', ['3 × 12 zancadas caminando por pierna', '3 × 10 elevación de talones']),
      ] },
    { heading: 'Series cortas de técnica', subtitle: 'Introducción a intervalos suaves.', focus: [{ name: 'Series 200 m', category: 'time' }],
      blocks: [
        b('A', 'Activación', ['5 min trote suave', '4 × 20 m progresivo']),
        b('B', 'Series', ['6 × 200 m a ritmo moderado · recuperación trotando 200 m'], 'Ritmo controlado: deberías poder hacer una serie más al final.'),
        b('C', 'Core', ['3 × 20 s plancha', '3 × 12 puente de glúteo']),
      ] },
    { heading: 'Rodaje largo suave', subtitle: 'El día de más volumen de la semana.', focus: [{ name: 'Rodaje largo', category: 'time' }],
      blocks: [
        b('A', 'Rodaje', ['30-35 min a ritmo conversación']),
        b('B', 'Movilidad', ['Movilidad de cadera y tobillo · 8 min']),
      ] },
  ],
  3: [
    { heading: 'Rodaje + técnica', subtitle: 'Sube el tiempo de rodaje.', focus: [{ name: 'Rodaje', category: 'time' }],
      blocks: [
        b('A', 'Técnica', ['4 × 20 m skipping alto', '4 × 20 m talón-glúteo']),
        b('B', 'Rodaje continuo', ['30 min a ritmo conversación']),
        b('C', 'Fuerza para correr', ['3 × 12 zancadas caminando con mancuernas ligeras', '3 × 12 step up por pierna']),
      ] },
    { heading: 'Series 400 m', subtitle: 'Series algo más largas que la semana pasada.', focus: [{ name: 'Series 400 m', category: 'time' }],
      blocks: [
        b('A', 'Activación', ['5 min trote suave', '4 × 20 m progresivo']),
        b('B', 'Series', ['6 × 400 m a ritmo moderado-fuerte · recuperación trotando 200 m']),
        b('C', 'Core', ['3 × 15 hollow rock', '3 × 30 s plancha lateral por lado']),
      ] },
    { heading: 'Fartlek suave', subtitle: 'Cambios de ritmo sin estructura rígida.',
      blocks: [
        b('A', 'Fartlek', ['20 min alternando 2 min a ritmo moderado + 2 min a ritmo suave']),
        b('B', 'Movilidad', ['Movilidad de tobillo y cadera · 8 min']),
      ] },
  ],
  4: [
    { heading: 'Rodaje + técnica', subtitle: 'Última semana antes de subir la intensidad.', focus: [{ name: 'Rodaje', category: 'time' }],
      blocks: [
        b('A', 'Técnica', ['4 × 20 m skipping alto', '4 × 20 m talón-glúteo']),
        b('B', 'Rodaje continuo', ['30 min a ritmo conversación']),
        b('C', 'Fuerza para correr', ['3 × 12 zancadas caminando con mancuernas', '3 × 12 step up por pierna']),
      ] },
    { heading: 'Sesión de referencia: 2 km', subtitle: 'Este ritmo es tu referencia de ritmo crítico/VO2máx para el resto del ciclo.', focus: [{ name: '2 km ritmo crítico/VO2máx', category: 'time' }],
      blocks: [
        b('A', 'Activación', ['8 min trote suave + 4 × 20 m progresivo']),
        b('B', '2 km de referencia', ['2 km al ritmo más rápido que puedas sostener de forma controlada'], 'Anota el ritmo por kilómetro: es el número que vas a usar de guía en las series de las próximas semanas. A esta distancia y esfuerzo estás corriendo cerca de tu ritmo crítico/VO2máx, no de tu ritmo de umbral de lactato — por eso las series que vienen son más cortas y más intensas que un entreno de umbral clásico.'),
        b('C', 'Vuelta a la calma', ['10 min trote muy suave']),
      ] },
    { heading: 'Rodaje largo', subtitle: 'El día de más volumen del bloque base.', focus: [{ name: 'Rodaje largo', category: 'time' }],
      blocks: [
        b('A', 'Rodaje', ['35-40 min a ritmo conversación']),
        b('B', 'Movilidad', ['Movilidad de cadera y tobillo · 8 min']),
      ] },
  ],
  5: [
    { heading: 'Primera carrera comprometida', subtitle: 'Correr con las piernas cargadas — la habilidad central de Hyrox.', focus: [{ name: 'Carrera comprometida', category: 'time' }],
      blocks: [
        b('A', 'Activación', ['8 min trote suave']),
        b('B', 'Carrera comprometida', ['3 rondas: 30 air squats + 800 m carrera a ritmo fuerte controlado', 'Descanso 2 min entre rondas'], 'El objetivo no es correr rápido con piernas frescas: es notar cuánto se cae el ritmo y entrenar para que se caiga menos.'),
        b('C', 'Vuelta a la calma', ['10 min trote muy suave']),
      ] },
    { heading: 'Series a ritmo crítico/VO2máx', subtitle: 'Al ritmo de tu referencia de la semana 4.', focus: [{ name: 'Series 600 m', category: 'time' }],
      blocks: [
        b('A', 'Activación', ['8 min trote suave + 4 × 20 m progresivo']),
        b('B', 'Series', ['5 × 600 m al ritmo de tu 2 km de referencia · recuperación trotando 200 m']),
        b('C', 'Core', ['3 × 20 hollow rock', '3 × 40 s plancha']),
      ] },
    { heading: 'Rodaje suave + técnica', subtitle: 'Recuperación activa entre los dos días duros.',
      blocks: [
        b('A', 'Técnica', ['4 × 20 m skipping alto', '4 × 20 m talón-glúteo']),
        b('B', 'Rodaje', ['25 min a ritmo conversación']),
      ] },
  ],
  6: [
    { heading: 'Carrera comprometida', subtitle: 'Sube a 4 rondas.', focus: [{ name: 'Carrera comprometida', category: 'time' }],
      blocks: [
        b('A', 'Activación', ['8 min trote suave']),
        b('B', 'Carrera comprometida', ['4 rondas: 30 zancadas con mancuernas + 800 m carrera a ritmo fuerte controlado', 'Descanso 2 min entre rondas'], 'Cambiamos el air squat por la zancada cargada: más parecida a la fatiga de pierna real de una estación de Hyrox y evita que el cuerpo se acostumbre siempre al mismo puente.'),
        b('C', 'Vuelta a la calma', ['10 min trote muy suave']),
      ] },
    { heading: 'Series a ritmo crítico/VO2máx', subtitle: 'Series más largas, mismo ritmo de referencia.', focus: [{ name: 'Series 800 m', category: 'time' }],
      blocks: [
        b('A', 'Activación', ['8 min trote suave + 4 × 20 m progresivo']),
        b('B', 'Series', ['4 × 800 m al ritmo de tu 2 km de referencia o algo más rápido · recuperación trotando 200 m']),
        b('C', 'Core', ['3 × 20 hollow rock', '3 × 45 s plancha']),
      ] },
    { heading: 'Rodaje largo', subtitle: 'El día de más volumen de esta semana de carga.', focus: [{ name: 'Rodaje largo', category: 'time' }],
      blocks: [
        b('A', 'Rodaje', ['35-40 min a ritmo conversación']),
        b('B', 'Movilidad', ['Movilidad de cadera y tobillo · 8 min']),
      ] },
  ],
  7: [
    { heading: 'Carrera comprometida', subtitle: 'El día más exigente del ciclo: cinco rondas.', focus: [{ name: 'Carrera comprometida', category: 'time' }],
      blocks: [
        b('A', 'Activación', ['8 min trote suave']),
        b('B', 'Carrera comprometida', ['5 rondas: 30 burpees + 800 m carrera a ritmo fuerte controlado', 'Descanso 2 min entre rondas'], 'Esto reproduce la sensación real de competir: piernas y brazos cargados ronda tras ronda. Mantenemos el descanso en 2 min en vez de bajarlo a 90 s: en la semana más dura del ciclo, subir rondas y exigencia del ejercicio ya es suficiente estímulo nuevo sin recortar también la recuperación.'),
        b('C', 'Vuelta a la calma', ['10 min trote muy suave']),
      ] },
    { heading: 'Series a ritmo crítico/VO2máx', subtitle: 'Ritmo de competición.', focus: [{ name: 'Series 1 km', category: 'time' }],
      blocks: [
        b('A', 'Activación', ['8 min trote suave + 4 × 20 m progresivo']),
        b('B', 'Series', ['3 × 1 km al ritmo que crees que podrías sostener en competición · recuperación trotando 3 min']),
        b('C', 'Cierre', ['Movilidad y respiración · 10 min'], 'Nada de intensidad extra. Empieza la descarga.'),
      ] },
    { heading: 'Rodaje suave', subtitle: 'Recuperación activa antes de la descarga.',
      blocks: [
        b('A', 'Rodaje', ['25 min a ritmo conversación']),
        b('B', 'Movilidad', ['Movilidad general · 8 min']),
      ] },
  ],
  8: [
    { heading: 'Descarga', subtitle: 'Mitad de volumen, pero con un toque de ritmo — no todo suave.',
      blocks: [
        b('A', 'Rodaje', ['15 min a ritmo conversación']),
        b('B', 'Técnica + toque de ritmo', ['3 × 20 m skipping alto', '2 × 100 m progresivo hasta ritmo de carrera comprometida'], 'La descarga baja el volumen, no la intensidad: este toque corto mantiene la pierna despierta sin acumular fatiga de cara al test.'),
        b('C', 'Movilidad', ['10 min']),
      ] },
    { heading: 'Activación', subtitle: 'Mover, no fatigar.',
      blocks: [
        b('A', 'Rodaje muy suave', ['15 min']),
        b('B', 'Progresiones', ['3 × 80 m progresivo suave']),
        b('C', 'Movilidad', ['8 min']),
      ] },
    { heading: 'Test final', subtitle: 'Mismo protocolo que la semana 1: 1 km fresco, burpees, 1 km fatigado.', isTest: true,
      blocks: [
        b('A', 'Test 1 · 1 km liso', ['1 km a máximo esfuerzo sostenible', 'Descansa 8-10 min trotando suave']),
        b('B', 'Puente de fatiga', ['50 burpees seguidos, ritmo constante']),
        b('C', 'Test 2 · 1 km fatigado', ['1 km inmediatamente después de los burpees, mismo esfuerzo máximo'], 'Compara los tres tiempos con la semana 1. Si la caída entre el test 1 y el test 2 es menor, el ciclo ha funcionado.'),
      ] },
  ],
};

/* ==================================================================== */
/* Registro de programas                                                 */
/* ==================================================================== */

export const PROGRAM_DEFS: Record<string, ProgramDef> = {
  hyrox8: {
    id: 'hyrox8', name: 'Hyrox — Mejorar Estaciones', short: 'Hyrox', discipline: 'hyrox',
    weeks: 8, days: [1, 3, 5], hasTestProtocol: true, testFields: HYROX_TEST_FIELDS, testRows: HYROX_TEST_ROWS,
  },
  'cf-fuerza': {
    id: 'cf-fuerza', name: 'CrossFit — Fuerza en Básicos', short: 'Fuerza', discipline: 'crossfit',
    weeks: 8, days: [1, 3, 5], hasTestProtocol: true, testFields: FUERZA_TEST_FIELDS, testRows: FUERZA_TEST_ROWS,
  },
  'cf-primera-dominada': {
    id: 'cf-primera-dominada', name: 'CrossFit — Tu Primera Dominada', short: 'Dominada', discipline: 'crossfit',
    weeks: 6, days: [1, 3, 5],
  },
  'cf-gim-nivel1': {
    id: 'cf-gim-nivel1', name: 'CrossFit — Gimnásticos Colgado · Nivel 1', short: 'Gim. N1', discipline: 'crossfit',
    weeks: 6, days: [1, 3, 5],
  },
  'cf-gim-nivel2': {
    id: 'cf-gim-nivel2', name: 'CrossFit — Gimnásticos Colgado · Nivel 2', short: 'Gim. N2', discipline: 'crossfit',
    weeks: 6, days: [1, 3, 5],
  },
  'cf-anillas-rmu': {
    id: 'cf-anillas-rmu', name: 'CrossFit — Anillas: Camino al Ring Muscle-Up', short: 'Anillas RMU', discipline: 'crossfit',
    weeks: 8, days: [1, 3, 5],
  },
  'hyrox-carrera': {
    id: 'hyrox-carrera', name: 'Hyrox — Mejora tu Carrera', short: 'Carrera', discipline: 'hyrox',
    weeks: 8, days: [1, 3, 5], hasTestProtocol: true, testFields: CARRERA_TEST_FIELDS, testRows: CARRERA_TEST_ROWS,
  },
};

// Códigos de demo — se aceptan además de una licencia real de Lemon Squeezy,
// para poder probar el flujo de cada producto sin comprar.
export const DEMO_CODES: Record<string, string> = {
  'HYROX-8W-DEMO': 'hyrox8',
  'FUERZA-8W-DEMO': 'cf-fuerza',
  'DOMINADA-DEMO': 'cf-primera-dominada',
  'GIM1-DEMO': 'cf-gim-nivel1',
  'GIM2-DEMO': 'cf-gim-nivel2',
  'RMU-DEMO': 'cf-anillas-rmu',
  'CARRERA-DEMO': 'hyrox-carrera',
};

// Código maestro de "coach" — pensado para appkairos2026@gmail.com (la
// cuenta de la propia Kairos/Korriban Club), para ver los 7 programas a la
// vez sin comprarlos uno a uno. Aviso importante: la app no tiene login por
// email (es solo código de licencia), así que esto NO comprueba ningún
// correo de verdad — es un código privado que solo debe usar quien lo tenga.
// Además, como todo el código de esta app corre en el navegador, este valor
// es técnicamente visible para cualquiera que inspeccione el JS publicado
// (igual que ya pasa con los DEMO_CODES de arriba) — no lo compartas ni lo
// publiques en ningún sitio.
export const COACH_UNLOCK_CODE = 'KAIROS-COACH-ADRIAN-2026';

export interface ProgramExtras {
  warmupStandard: string[];
  warmupNote: string;
  substitutions: { station: string; main: string; alt: string }[];
  coachNotes: { title: string; text: string }[];
}

export const PROGRAM_EXTRAS: Record<string, ProgramExtras> = {
  hyrox8: {
    warmupStandard: [
      '3 min de máquina suave (ski, remo o bici) o carrera',
      'Movilidad de tobillo, cadera y torácica — 30 s por zona',
      '10 sentadillas sin peso · 10 buenos días con barra vacía · 10 rotaciones de hombro',
      'Dos series ligeras del primer ejercicio del día',
    ],
    warmupNote: 'En los días de trineo, añade una pasada de 25 m sin carga antes de empezar.',
    substitutions: [
      { station: 'Sled push', main: 'Zancadas caminando con barra en espalda, misma distancia', alt: 'Prensa horizontal 15-20 rep · cinta a inclinación máxima 45 s' },
      { station: 'Sled pull', main: 'Remo en polea de pie, series de 15-20 rep', alt: 'Remo con barra pesado · remo invertido con chaleco' },
      { station: 'SkiErg', main: 'Remo, misma distancia', alt: 'Bici de aire, distancia × 2' },
      { station: 'Remo', main: 'SkiErg, misma distancia', alt: 'Carrera, distancia × 1,5' },
      { station: 'Sandbag lunges', main: 'Zancadas con barra en zercher', alt: 'Mancuernas pesadas · chaleco lastrado' },
      { station: 'Farmers carry', main: 'Mancuernas o kettlebells pesadas', alt: 'Trap bar · discos con pinza' },
      { station: 'Wall ball', main: 'Thruster con mancuerna + lanzamiento', alt: 'Goblet squat + press estricto, mismo número' },
      { station: 'Burpee broad jump', main: 'Burpee + salto al cajón', alt: 'Burpee + salto vertical máximo' },
    ],
    coachNotes: [
      { title: 'El ritmo', text: 'El error más común es salir rápido en los intervalos de ski. Un intervalo bien hecho es aquel en el que el último es igual que el primero. Si el sexto es 10 segundos más lento que el primero, saliste demasiado fuerte.' },
      { title: 'La carga del trineo', text: 'No busques la máxima. Busca la mayor con la que no te detengas. El trineo que te obliga a parar cada cinco metros no entrena lo que necesitas para competir.' },
      { title: 'Los wall balls', text: 'La recepción en sentadilla completa es lo que se rompe primero cuando llega la fatiga. Si empiezas a hacer medias sentadillas, para, respira cinco segundos y sigue. Es mejor partir la serie que hacerla mal.' },
      { title: 'Combinar con tus clases', text: 'Este ciclo añade 3 sesiones a lo que ya haces. Si entrenas cinco o seis días en el box, valora quitar una clase las semanas 6 y 7, que son las de más carga.' },
      { title: 'Si te pierdes una sesión', text: 'No la recuperes metiendo dos seguidas. Sáltatela y sigue por donde toca. La progresión aguanta que falte una sesión; no aguanta que acumules fatiga.' },
      { title: 'Si algo te molesta', text: 'Dolor articular no es fatiga muscular. Si algo duele en la articulación, cambia el ejercicio por su sustituto y consulta. Ninguna sesión de este ciclo merece una lesión.' },
      { title: 'Correr es lo que más pesa', text: 'En una carrera Hyrox, correr ocupa cerca del 60% del tiempo total, y la capacidad aeróbica es el mejor predictor del resultado — por delante de la fuerza (Brandt et al., 2025, Frontiers in Physiology). Este ciclo se centra en las estaciones porque es lo que falta en tus clases de CrossFit. Si además puedes sumar 1-2 carreras suaves de 20-30 min por semana fuera de estas tres sesiones, es la mejora individual con más impacto que puedes hacer en este bloque.' },
    ],
  },
  'cf-fuerza': {
    warmupStandard: [
      '5 min de bici o remo suave',
      'Movilidad de cadera y tobillo — 10 sentadillas con pausa abajo',
      '10 buenos días con barra vacía · 10 dislocaciones de hombro con banda',
      '2-3 series ligeras del primer ejercicio del día, subiendo de peso poco a poco',
    ],
    warmupNote: 'En los días de peso muerto, añade 2 series de peso muerto rumano ligero antes de la barra.',
    substitutions: [
      { station: 'Back Squat', main: 'Si no hay rack, sentadilla goblet pesada con mancuerna o kettlebell', alt: 'Sentadilla búlgara cargada, ambas piernas' },
      { station: 'Front Squat', main: 'Goblet squat con mancuerna o kettlebell', alt: 'Sentadilla con barra en zercher' },
      { station: 'Peso Muerto', main: 'Peso muerto con mancuernas o kettlebells', alt: 'Peso muerto rumano con barra' },
      { station: 'Press Militar', main: 'Press con mancuernas de pie', alt: 'Press en máquina o con banda pesada' },
    ],
    coachNotes: [
      { title: 'La técnica manda sobre el número', text: 'Un 1RM con mala técnica no cuenta para nada: no lo vas a poder repetir en la semana 8 ni vas a poder construir fuerza real sobre él.' },
      { title: 'Si fallas una serie', text: 'Repite el mismo peso la sesión siguiente. No lo subas por orgullo: el ciclo está diseñado para que el peso final de la semana 7 sea alcanzable si respetas los pesos de las semanas anteriores.' },
      { title: 'RPE de referencia', text: 'Si no tienes un 1RM reciente, usa el RPE: un 70% debería sentirse a un RPE 6-7 en series de 6, un 88% a un RPE 8-9 en series de 2-3.' },
      { title: 'Si no quieres ir a 1RM real, estima', text: 'Si un cliente lleva tiempo sin cargar peso máximo en el press estricto o el front squat, no fuerces el 1RM real: sube hasta una serie de 3 repeticiones sólidas y estima con Epley (1RM ≈ peso × (1 + reps/30)). El error frente al 1RM real es pequeño y el riesgo baja mucho.' },
      { title: 'Combinar con tus clases', text: 'Este ciclo añade 3 sesiones de fuerza a tu semana. Si entrenas también CrossFit, evita hacer piernas pesadas en clase el mismo día que Back Squat o Peso Muerto.' },
    ],
  },
  'cf-primera-dominada': {
    warmupStandard: [
      'Movilidad de hombro y escápula — 2 min de circunducciones y dislocaciones con banda',
      '10 remo invertido suave para activar la espalda',
      '2 cuelgues de 10-15 s para activar el agarre',
    ],
    warmupNote: 'Si te duele la muñeca al colgar, calienta con un agarre más grueso (toalla) antes de pasar a la barra.',
    substitutions: [
      { station: 'Barra de dominadas', main: 'Anillas de gimnasia a la misma altura', alt: 'Máquina de dominada asistida, si hay en el box' },
      { station: 'Banda de asistencia', main: 'Silla o cajón para reducir el peso a levantar', alt: 'Compañero sujetando los pies o las caderas' },
    ],
    coachNotes: [
      { title: 'La paciencia es el programa', text: 'Nadie consigue su primera dominada en dos semanas. Si en la semana 6 todavía no sale, repite el bloque desde la semana 4: ya tienes la base construida.' },
      { title: 'El agarre falla antes que la espalda', text: 'Si sueltas la barra antes de terminar la serie, el problema suele ser el agarre, no la fuerza de tracción. Añade trabajo de cuelgue si te pasa a menudo.' },
      { title: 'Cuenta la bajada, no la subida', text: 'Una negativa que se convierte en caída libre no sirve de mucho — pero tampoco hace falta perseguir los 10-12 segundos como si fueran mágicos: la evidencia sobre duración excéntrica no muestra que "más lento" sea automáticamente "más estímulo". Lo que importa es que la bajada sea continua y controlada, sin acelerarse al final. Usa la duración como termómetro de control, no como objetivo: si controlas bien 4-6 s con la banda actual, el siguiente paso es una banda más fina, no una bajada más larga.' },
    ],
  },
  'cf-gim-nivel1': {
    warmupStandard: [
      'Movilidad de hombro — 2 min circunducciones y dislocaciones con banda',
      '5 balanceos suaves colgado de la barra para activar el kip',
      '10 hollow rock para activar el core antes del toes-to-bar',
    ],
    warmupNote: 'Si notas las manos calientes o con ampollas, usa magnesio y revisa el punto de contacto en la barra.',
    substitutions: [
      { station: 'Toes-to-bar', main: 'Hanging knee raises o hanging straight-leg raises, según tu nivel', alt: 'Rodillas al pecho en paralelas o en silla romana' },
      { station: 'Dominada kipping', main: 'Dominada estricta si todavía no dominas el kip', alt: 'Remo invertido con más volumen ese día' },
    ],
    coachNotes: [
      { title: 'El kip se aprende sin barra', text: 'Practica el balanceo de cadera y hombros en el suelo o colgado sin buscar la repetición: el ritmo es lo primero que hay que automatizar.' },
      { title: 'Corta antes de perder el ritmo', text: 'En cuanto el kip se descoordina, para la serie. Series feas no construyen técnica, solo malos hábitos.' },
      { title: 'Toes-to-bar: primero rango, luego velocidad', text: 'Antes de buscar hacerlo rápido, asegúrate de tocar la barra con los pies cada vez. La velocidad sin rango completo no cuenta en competición.' },
      { title: 'No abandones la dominada estricta', text: 'Este bloque es de kip, no reemplaza la fuerza de tracción. Si notas que la estricta se resiente, mete 2-3 series sueltas en el calentamiento, no hace falta más.' },
    ],
  },
  'cf-gim-nivel2': {
    warmupStandard: [
      'Movilidad de hombro y muñeca — dislocaciones con banda y rotaciones de muñeca con peso ligero',
      '10 remo invertido para activar la espalda',
      '2 cuelgues activos de 20-30 s',
    ],
    warmupNote: 'Antes de meter volumen de muscle-up, calienta siempre la muñeca: es la articulación que más sufre en la transición.',
    substitutions: [
      { station: 'Muscle-up con banda', main: 'Jumping muscle-up desde un cajón, ajustando la altura a tu nivel', alt: 'Trabajo separado de chest-to-bar + fondos en paralelas' },
      { station: 'Chest-to-bar', main: 'Dominada kipping estricta hasta la barbilla si el pecho aún no llega', alt: 'Remo invertido con lastre' },
    ],
    coachNotes: [
      { title: 'La muñeca manda', text: 'Si sientes pinchazo en la muñeca al pasar la transición, casi siempre es que rotas tarde. Adelanta el momento de girar la muñeca respecto al punto más alto del tirón.' },
      { title: 'La banda es una herramienta, no una muleta permanente', text: 'Baja de grosor de banda en cuanto la transición se sienta fácil, no esperes a dominarla del todo: el aprendizaje ocurre en el punto donde todavía cuesta un poco.' },
      { title: 'Si fallas la transición muchas veces seguidas', text: 'Vuelve a trabajar chest-to-bar y fondos por separado esa sesión. Forzar transiciones falladas construye mal hábito, no fuerza.' },
    ],
  },
  'cf-anillas-rmu': {
    warmupStandard: [
      'Movilidad de hombro en rotación externa — dislocaciones con banda, 2-3 min',
      'Movilidad de muñeca — rotaciones con peso ligero',
      '2 cuelgues activos de 20-30 s en anillas para activar el turnout',
    ],
    warmupNote: 'Las anillas exigen más estabilidad de hombro que la barra: no saltes el calentamiento específico aunque tengas prisa.',
    substitutions: [
      { station: 'Anillas altas', main: 'Anillas a menor altura para reducir el riesgo en las primeras semanas', alt: 'Barra fija para el trabajo de falso agarre si las anillas no están disponibles' },
      { station: 'Ring muscle-up con banda', main: 'Transición baja (anillas a la altura del pecho) con más asistencia', alt: 'Trabajo separado de falso agarre + fondos en anillas' },
    ],
    coachNotes: [
      { title: 'El movimiento con más riesgo del catálogo', text: 'El ring muscle-up es la habilidad más exigente para hombro y muñeca de los cinco programas. Ante cualquier dolor agudo (no solo fatiga), para la sesión y no la fuerces la semana siguiente.' },
      { title: 'El falso agarre se entrena en frío', text: 'Practica el falso agarre al principio de la sesión, con el agarre fresco. Al final del entreno, con la mano fatigada, el riesgo de que se suelte la anilla en la transición sube mucho.' },
      { title: 'Las anillas premian la calma', text: 'Cuanto más rápido intentas forzar la rotación, más se mueven las anillas y peor sale la transición. Es un movimiento técnico, no explosivo puro: la velocidad llega después de la técnica.' },
      { title: 'Cambia una variable cada vez', text: 'Quitar banda y añadir kip son dos progresiones distintas: si las juntas en la misma sesión no sabes cuál te está generando molestia en la muñeca. Cuando dudes, sacrifica volumen antes que mezclar dos novedades el mismo día.' },
    ],
  },
  'hyrox-carrera': {
    warmupStandard: [
      '5 min de trote muy suave',
      '4 × 20 m skipping bajo · 4 × 20 m talón-glúteo',
      'Movilidad de tobillo y cadera — 30 s por zona',
      '2 × 20 m progresivo antes de la parte principal',
    ],
    warmupNote: 'En los días de carrera comprometida, añade un par de air squats de activación antes de empezar la primera ronda.',
    substitutions: [
      { station: 'Carrera en asfalto o pista', main: 'Cinta de correr, misma duración o distancia', alt: 'Bici de aire o remo, distancia equivalente × 1,5' },
      { station: 'Air squats (puente de fatiga)', main: 'Step ups sin peso, mismo número', alt: 'Burpees, mismo número' },
    ],
    coachNotes: [
      { title: 'La habilidad real es la caída de ritmo', text: 'No importa lo rápido que corras fresco: en Hyrox corres seis veces fatigado por una. Lo que este programa entrena es que esa caída de ritmo sea lo más pequeña posible.' },
      { title: 'El ritmo de las series es tuyo, no de una tabla', text: 'Usa siempre tu propio 2 km de referencia de la semana 4 para calcular el ritmo de las series de umbral. Correr las series de otra persona no sirve de nada.' },
      { title: 'Los rodajes suaves son parte del plan, no un relleno', text: 'Si corres todos los días rápido, el cuerpo no absorbe el estímulo. Los días de rodaje suave son los que permiten que las series y la carrera comprometida funcionen.' },
      { title: 'Combinar con tus clases', text: 'Este ciclo añade 3 sesiones de carrera a tu semana. Si entrenas también CrossFit o Hyrox en el box, evita piernas pesadas en clase el mismo día que carrera comprometida o series.' },
    ],
  },
};

/* ==================================================================== */
/* Construcción de sesiones                                              */
/* ==================================================================== */

const PROGRAM_CONTENT: Record<string, { weekMeta: Record<number, WeekMeta>; data: Record<number, ProgramDay[]> }> = {
  hyrox8: { weekMeta: HYROX_WEEK_META, data: HYROX_PROGRAM_DATA },
  'cf-fuerza': { weekMeta: FUERZA_WEEK_META, data: FUERZA_PROGRAM_DATA },
  'cf-primera-dominada': { weekMeta: DOMINADA_WEEK_META, data: DOMINADA_PROGRAM_DATA },
  'cf-gim-nivel1': { weekMeta: GIM1_WEEK_META, data: GIM1_PROGRAM_DATA },
  'cf-gim-nivel2': { weekMeta: GIM2_WEEK_META, data: GIM2_PROGRAM_DATA },
  'cf-anillas-rmu': { weekMeta: RMU_WEEK_META, data: RMU_PROGRAM_DATA },
  'hyrox-carrera': { weekMeta: CARRERA_WEEK_META, data: CARRERA_PROGRAM_DATA },
};

function buildSessions(def: ProgramDef, weekMeta: Record<number, WeekMeta>, programData: Record<number, ProgramDay[]>): Session[] {
  const out: Session[] = [];
  for (let week = 1; week <= def.weeks; week++) {
    const meta = weekMeta[week];
    const days: ProgramDay[] = programData[week];
    days.forEach((day, dayIdx) => {
      out.push({
        week,
        slot: dayIdx,
        weekdayIso: def.days[dayIdx],
        phase: meta.phase,
        phaseLabel: meta.phaseLabel,
        weekIntro: meta.intro,
        heading: day.heading,
        subtitle: day.subtitle,
        blocks: day.blocks,
        isTest: !!day.isTest,
        focus: day.focus || null,
        warmupNote: def.id === 'hyrox8' && dayIdx === 0
          ? 'Calentamiento estándar (8-10 min) + 1 pasada de 25 m sin carga. Rutina completa en Ajustes.'
          : 'Calentamiento estándar (8-10 min). Rutina completa en Ajustes.',
        key: def.id + '_w' + week + '_d' + dayIdx,
      });
    });
  }
  return out;
}

const SESSIONS_CACHE: Record<string, Session[]> = {};
export function sessionsFor(programId: string): Session[] {
  if (!SESSIONS_CACHE[programId]) {
    const def = PROGRAM_DEFS[programId];
    const content = PROGRAM_CONTENT[programId];
    SESSIONS_CACHE[programId] = buildSessions(def, content.weekMeta, content.data);
  }
  return SESSIONS_CACHE[programId];
}
