// /enlaces — página "link in bio" para Instagram, con medición propia:
// cada visita cuenta como pageview de /enlaces en Vercel Analytics, y cada
// clic dispara un evento `bio_link_click` (con el enlace pulsado) además de
// llevar UTM (instagram/bio/<campaña>) para que el desglose por origen
// aparezca también en Analytics aunque el plan no muestre eventos custom.
// CTR = clics de bio_link_click ÷ pageviews de /enlaces.
import { useEffect } from 'react';
import './block.css';
import { PROGRAM_DEFS, PROGRAM_PRODUCTS, PROGRAM_ORDER } from './data';

const UTM = 'utm_source=instagram&utm_medium=bio';

function track(link: string) {
  try {
    (window as unknown as { va?: (ev: string, props: object) => void }).va?.('event', {
      name: 'bio_link_click',
      data: { link },
    });
  } catch { /* analytics no disponible: el enlace funciona igual */ }
}

export function EnlacesPage() {
  useEffect(() => {
    document.title = 'Kairos — Enlaces';
  }, []);

  return (
    <div className="kb-root">
      <div className="kb-app">
        <div className="kb-content" style={{ paddingTop: 28 }}>
          <div style={{ textAlign: 'center', marginBottom: 18 }}>
            <div className="kb-wordmark kb-display" style={{ fontSize: 30 }}>KAI<span>ROS</span></div>
            <p className="kb-muted" style={{ fontSize: 13.5, margin: '6px auto 0', maxWidth: '32ch' }}>
              Programas de 6-8 semanas con test inicial y final. Pago único, sin suscripción.
            </p>
            <p className="kb-hand" style={{ fontSize: 20, color: 'var(--kb-accent)', margin: '4px 0 0', transform: 'rotate(-1deg)' }}>
              elige tu objetivo ↓
            </p>
          </div>

          {PROGRAM_ORDER.map((pid) => {
            const def = PROGRAM_DEFS[pid];
            const product = PROGRAM_PRODUCTS[pid];
            return (
              <a
                key={pid}
                className="kb-program-crosslink"
                style={{ marginBottom: 8 }}
                href={`/programas/${pid}?${UTM}&utm_campaign=${pid}`}
                onClick={() => track(pid)}
              >
                <span>{def.name.replace(/ · para (Hyrox|CrossFit)$/, '')}
                  <span className="kb-faint" style={{ fontWeight: 400 }}> · {def.discipline === 'hyrox' ? 'para Hyrox' : 'para CrossFit'}</span>
                </span>
                <span className="kb-mono" style={{ color: 'var(--kb-accent-2)' }}>{product.priceLabel}</span>
              </a>
            );
          })}

          <a
            className="kb-btn kb-btn-primary"
            style={{ textDecoration: 'none', marginTop: 14 }}
            href={`/?${UTM}&utm_campaign=home`}
            onClick={() => track('home')}
          >
            Ver la web completa
          </a>
          <a
            className="kb-btn kb-btn-ghost"
            style={{ textDecoration: 'none', marginTop: 10 }}
            href={`/?activate=1&${UTM}&utm_campaign=activar`}
            onClick={() => track('activar')}
          >
            Ya tengo un código
          </a>

          <p className="kb-footnote">
            HYROX® y CrossFit® son marcas registradas de sus respectivos titulares.
            Kairos no está afiliado, patrocinado ni avalado por ellas.
          </p>
        </div>
      </div>
    </div>
  );
}
