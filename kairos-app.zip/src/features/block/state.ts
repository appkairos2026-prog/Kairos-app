import { PROGRAM_DEFS, sessionsFor } from './data';
import type { BlockAppState, BlockLog, Session } from './types';

export const STORE_KEY = 'kairos_block_state_v1';

export function loadState(): BlockAppState {
  try {
    const raw = localStorage.getItem(STORE_KEY);
    if (raw) return JSON.parse(raw) as BlockAppState;
  } catch { /* ignore corrupt storage */ }
  return { unlocked: {}, activeProgram: null, logs: {}, theme: 'auto', hideInstallHint: false };
}

export function saveState(state: BlockAppState) {
  try { localStorage.setItem(STORE_KEY, JSON.stringify(state)); } catch { /* storage full/blocked */ }
}

/* ---------------- date helpers ---------------- */

export function todayMidnight(): Date {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
}
export function isoDate(d: Date): string {
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}
export function mondayOnOrAfter(d: Date): Date {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  const iso = x.getDay() === 0 ? 7 : x.getDay();
  x.setDate(x.getDate() + (iso === 1 ? 0 : 8 - iso));
  return x;
}
export function addDays(d: Date, n: number): Date {
  const x = new Date(d);
  x.setDate(x.getDate() + n);
  return x;
}
export const DOW = ['LUN', 'MAR', 'MIÉ', 'JUE', 'VIE', 'SÁB', 'DOM'];
export const DOW_FULL = ['lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado', 'domingo'];

export function programStart(state: BlockAppState, programId: string): Date {
  const meta = state.unlocked[programId];
  return mondayOnOrAfter(new Date(meta.activatedAt));
}
export function sessionDate(state: BlockAppState, programId: string, session: Session): Date {
  return addDays(programStart(state, programId), (session.week - 1) * 7 + (session.weekdayIso - 1));
}

/* ---------------- log helpers ---------------- */

export function getLog(state: BlockAppState, programId: string, key: string): BlockLog | null {
  return (state.logs[programId] && state.logs[programId][key]) || null;
}

export function withLog(state: BlockAppState, programId: string, key: string, patch: Partial<BlockLog>): BlockAppState {
  const cur: BlockLog = (state.logs[programId] && state.logs[programId][key]) || { completed: false, values: {}, rpe: null };
  const merged: BlockLog = { ...cur, ...patch };
  return {
    ...state,
    logs: {
      ...state.logs,
      [programId]: { ...(state.logs[programId] || {}), [key]: merged },
    },
  };
}

/* ---------------- stats ---------------- */

export interface ProgramStats {
  dated: { s: Session; date: Date }[];
  past: { s: Session; date: Date }[];
  completedCount: number;
  adherence: number;
  streak: number;
  daysRemaining: number;
  totalSessions: number;
}

export function programStats(state: BlockAppState, programId: string): ProgramStats {
  const sessions = sessionsFor(programId);
  const today = todayMidnight();
  const todayIso = isoDate(today);
  const dated = sessions
    .map((s) => ({ s, date: sessionDate(state, programId, s) }))
    .sort((a, b) => a.date.getTime() - b.date.getTime());
  const past = dated.filter((x) => x.date <= today);
  const pastCompleted = past.filter((x) => getLog(state, programId, x.s.key)?.completed).length;
  const completedCount = dated.filter((x) => getLog(state, programId, x.s.key)?.completed).length;
  const adherence = past.length ? Math.round((100 * pastCompleted) / past.length) : 0;
  let streak = 0;
  for (let i = past.length - 1; i >= 0; i--) {
    const x = past[i];
    const log = getLog(state, programId, x.s.key);
    const done = !!log?.completed;
    if (isoDate(x.date) === todayIso && !done) continue;
    if (done) streak++; else break;
  }
  const last = dated[dated.length - 1];
  const daysRemaining = last ? Math.max(0, Math.round((last.date.getTime() - today.getTime()) / 86400000)) : 0;
  return { dated, past, completedCount, adherence, streak, daysRemaining, totalSessions: sessions.length };
}

/* ---------------- session lookup ---------------- */

export function findSessionForDate(state: BlockAppState, programId: string, dateObj: Date): Session | null {
  const sessions = sessionsFor(programId);
  const iso = isoDate(dateObj);
  for (const s of sessions) {
    if (isoDate(sessionDate(state, programId, s)) === iso) return s;
  }
  return null;
}
export function findNextSession(state: BlockAppState, programId: string, fromDate: Date): { s: Session; d: Date } | null {
  const list = sessionsFor(programId)
    .map((s) => ({ s, d: sessionDate(state, programId, s) }))
    .sort((a, b) => a.d.getTime() - b.d.getTime());
  for (const item of list) {
    if (item.d >= fromDate) return item;
  }
  return null;
}
export function currentWeekNumber(state: BlockAppState, programId: string): number {
  const start = programStart(state, programId);
  const diffDays = Math.round((todayMidnight().getTime() - start.getTime()) / 86400000);
  const wk = Math.floor(diffDays / 7) + 1;
  return Math.min(PROGRAM_DEFS[programId].weeks, Math.max(1, wk));
}

/* ---------------- test inicial vs. final ---------------- */

export type TestComparisonResult =
  | { status: 'need-initial' }
  | { status: 'need-final' }
  | { status: 'done'; rows: { label: string; initial: number | null; final: number | null; delta: number | null; category: string }[] };

function parseValueForCategory(raw: string | null | undefined, category: string): number | null {
  if (category === 'time') return parseTimeToSec(raw);
  if (raw == null || raw === '') return null;
  const n = parseFloat(String(raw));
  return isNaN(n) ? null : n;
}

export function testComparison(state: BlockAppState, programId: string): TestComparisonResult {
  const def = PROGRAM_DEFS[programId];
  const testRows = def.testRows || [];
  const sessions = sessionsFor(programId);
  const weeks = def.weeks;
  const initialS = sessions.find((s) => s.isTest && s.week === 1);
  const finalS = sessions.find((s) => s.isTest && s.week === weeks);
  if (!initialS || !finalS) return { status: 'need-initial' };
  const li = getLog(state, programId, initialS.key);
  const lf = getLog(state, programId, finalS.key);
  if (!li || !li.completed) return { status: 'need-initial' };
  if (!lf || !lf.completed) return { status: 'need-final' };
  const rows = testRows.map((r) => {
    const a = parseValueForCategory((li.values as Record<string, string>)?.[r.key], r.category);
    const bVal = parseValueForCategory((lf.values as Record<string, string>)?.[r.key], r.category);
    const delta = a != null && bVal != null ? bVal - a : null;
    return { label: r.label, initial: a, final: bVal, delta, category: r.category };
  });
  return { status: 'done', rows };
}

/* ---------------- formatting ---------------- */

export function categoryUnitLabel(cat: string): string {
  return ({ reps: 'reps', time: 's', load: 'kg' } as Record<string, string>)[cat] || '';
}
export function formatMetricValue(v: number, cat: string): string {
  if (cat === 'time') {
    return v >= 60 ? Math.floor(v / 60) + ':' + String(Math.round(v % 60)).padStart(2, '0') : Math.round(v) + 's';
  }
  return v + ' ' + categoryUnitLabel(cat);
}
export function parseTimeToSec(str: string | null | undefined): number | null {
  if (str == null || str === '') return null;
  const s = String(str).trim();
  if (s.indexOf(':') > -1) {
    const p = s.split(':');
    const mm = parseFloat(p[0]);
    const ss = parseFloat(p[1]);
    if (isNaN(mm) || isNaN(ss)) return null;
    return mm * 60 + ss;
  }
  const n = parseFloat(s);
  return isNaN(n) ? null : n;
}
