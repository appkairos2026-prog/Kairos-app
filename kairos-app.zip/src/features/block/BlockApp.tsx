import { useState } from 'react';
import { PROGRAM_DEFS, PROGRAM_EXTRAS, sessionsFor } from './data';
import {
  DOW, DOW_FULL, currentWeekNumber, findNextSession, findSessionForDate, getLog, isoDate,
  programStats, sessionDate, testComparison, todayMidnight, withLog, STORE_KEY,
} from './state';
import type { BlockAppState } from './types';
import { IconProgress, IconSettings, IconToday, IconWeek } from './icons';
import { SessionCard } from './SessionCard';
import { WeeklyBarChart, TestComparisonCard } from './Charts';

type Tab = 'today' | 'week' | 'progress' | 'settings';

interface Props {
  state: BlockAppState;
  update: (updater: (s: BlockAppState) => BlockAppState) => void;
  /** Id del programa que se acaba de desbloquear en esta sesión (o null). */
  justUnlocked?: string | null;
  onDismissJustUnlocked?: () => void;
}

export function BlockApp({ state, update, justUnlocked, onDismissJustUnlocked }: Props) {
  const [tab, setTab] = useState<Tab>('today');
  const [weekOffset, setWeekOffset] = useState(0);
  const [selectedKey, setSelectedKey] = useState<string | null>(null);

  const programId = state.activeProgram || Object.keys(state.unlocked)[0];
  const def = PROGRAM_DEFS[programId];

  const setLogFor = (key: string, patch: Parameters<typeof withLog>[3]) => {
    update((s) => withLog(s, programId, key, patch));
  };

  const goTab = (t: Tab) => {
    setTab(t); setWeekOffset(0); setSelectedKey(null);
    window.scrollTo(0, 0);
  };

  return (
    <div className={`kb-app program-${def.discipline}`}>
      <div className="kb-topbar">
        <div className="kb-topbar-row">
          <div className="kb-wordmark kb-display">KAI<span>ROS</span></div>
          <button className="kb-chip" onClick={() => setTab('settings')}>{def.short}</button>
        </div>
      </div>
      <div className="kb-content">
        {tab === 'today' && justUnlocked === programId && (
          <ActivatedBanner def={def} onDismiss={() => onDismissJustUnlocked?.()} />
        )}
        {tab === 'today' && <TodayTab state={state} update={update} programId={programId} onSetLog={setLogFor} />}
        {tab === 'week' && (
          <WeekTab state={state} programId={programId} weekOffset={weekOffset} setWeekOffset={setWeekOffset}
            selectedKey={selectedKey} setSelectedKey={setSelectedKey} onSetLog={setLogFor} />
        )}
        {tab === 'progress' && <ProgressTab state={state} programId={programId} />}
        {tab === 'settings' && <SettingsTab state={state} update={update} programId={programId} />}
      </div>
      <div className="kb-tabbar">
        {([
          ['today', 'Hoy', <IconToday key="i" />],
          ['week', 'Semana', <IconWeek key="i" />],
          ['progress', 'Progreso', <IconProgress key="i" />],
          ['settings', 'Ajustes', <IconSettings key="i" />],
        ] as [Tab, string, JSX.Element][]).map(([t, label, icon]) => (
          <button key={t} className="kb-tab" data-active={tab === t ? '1' : '0'} onClick={() => goTab(t)}>
            {icon}<span>{label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

function ActivatedBanner({ def, onDismiss }: { def: (typeof PROGRAM_DEFS)[string]; onDismiss: () => void }) {
  return (
    <div className="kb-banner kb-banner-success">
      <div style={{ flex: '1 1 auto' }}>
        <div style={{ fontWeight: 700, fontSize: 13, marginBottom: 3 }}>¡Programa activado! · {def.name.replace(/^(Hyrox|CrossFit) — /, '')}</div>
        <div className="kb-muted" style={{ fontSize: 12.5, lineHeight: 1.5 }}>
          Ya tienes acceso completo a las {def.weeks} semanas. Empieza por tu sesión de hoy, o mira Ajustes → {def.short} para el calentamiento estándar y las notas del coach.
        </div>
      </div>
      <button className="kb-dismiss" aria-label="Cerrar aviso" onClick={onDismiss}>✕</button>
    </div>
  );
}

function InstallBanner({ state, update }: { state: BlockAppState; update: Props['update'] }) {
  if (state.hideInstallHint) return null;
  return (
    <div className="kb-banner">
      <div style={{ flex: '1 1 auto' }}>
        <div style={{ fontWeight: 700, fontSize: 13, marginBottom: 3 }}>Instálala como tu atajo de iPhone</div>
        <div className="kb-muted" style={{ fontSize: 12.5, lineHeight: 1.5 }}>
          Toca <strong>Compartir</strong> en Safari → <strong>Añadir a pantalla de inicio</strong>. Se abre a pantalla completa y sigue funcionando sin conexión.
        </div>
      </div>
      <button className="kb-dismiss" aria-label="Cerrar aviso" onClick={() => update((s) => ({ ...s, hideInstallHint: true }))}>✕</button>
    </div>
  );
}

function TodayTab({ state, update, programId, onSetLog }: { state: BlockAppState; update: Props['update']; programId: string; onSetLog: (key: string, patch: any) => void }) {
  const def = PROGRAM_DEFS[programId];
  const today = todayMidnight();
  const session = findSessionForDate(state, programId, today);
  return (
    <>
      <InstallBanner state={state} update={update} />
      {session ? (
        <SessionCard def={def} session={session} dateObj={today} log={getLog(state, programId, session.key) || { completed: false, rpe: null }}
          onSetLog={(patch) => onSetLog(session.key, patch)} />
      ) : (
        <div className="kb-card">
          <div className="kb-eyebrow">Hoy descansas</div>
          <h3 className="kb-display" style={{ margin: '6px 0 8px' }}>Recuperación activa</h3>
          <p className="kb-muted">
            Sin sesión programada hoy. {(() => {
              const next = findNextSession(state, programId, today);
              return next ? `Tu próxima sesión es el ${DOW_FULL[next.s.weekdayIso - 1]} ${next.d.getDate()}/${next.d.getMonth() + 1}: "${next.s.heading}".` : 'Bloque completado.';
            })()}
          </p>
        </div>
      )}
    </>
  );
}

function WeekTab({ state, programId, weekOffset, setWeekOffset, selectedKey, setSelectedKey, onSetLog }: {
  state: BlockAppState; programId: string; weekOffset: number; setWeekOffset: (n: number) => void;
  selectedKey: string | null; setSelectedKey: (k: string | null) => void; onSetLog: (key: string, patch: any) => void;
}) {
  const def = PROGRAM_DEFS[programId];
  const totalWeeks = def.weeks;
  const week = Math.min(totalWeeks, Math.max(1, currentWeekNumber(state, programId) + weekOffset));
  const sessions = sessionsFor(programId).filter((s) => s.week === week);
  const todayIso = isoDate(todayMidnight());

  const selected = selectedKey ? sessionsFor(programId).find((s) => s.key === selectedKey) : null;

  return (
    <>
      <div className="kb-eyebrow">{sessions[0]?.phaseLabel}</div>
      <div className="kb-weeknav">
        <button disabled={week <= 1} onClick={() => setWeekOffset(weekOffset - 1)}>‹</button>
        <h2 className="kb-display" style={{ margin: 0 }}>Semana {week} / {totalWeeks}</h2>
        <button disabled={week >= totalWeeks} onClick={() => setWeekOffset(weekOffset + 1)}>›</button>
      </div>
      {sessions[0]?.weekIntro && <p className="kb-muted" style={{ margin: '-4px 0 14px' }}>{sessions[0].weekIntro}</p>}
      <div className="kb-daylist">
        {sessions.map((s) => {
          const d = sessionDate(state, programId, s);
          const log = getLog(state, programId, s.key);
          const iso = isoDate(d);
          const status = log?.completed ? 'done' : d < todayMidnight() ? 'missed' : iso === todayIso ? 'today' : 'pending';
          return (
            <button key={s.key} className="kb-daycell" data-selected={selectedKey === s.key ? '1' : '0'}
              onClick={() => setSelectedKey(selectedKey === s.key ? null : s.key)}>
              <span className="kb-dow">{DOW[s.weekdayIso - 1]} {d.getDate()}/{d.getMonth() + 1}</span>
              <span className="kb-dtitle"><div className="kb-n">{s.heading}</div><div className="kb-f">{s.subtitle}</div></span>
              <span className={`kb-status-dot ${status}`} />
            </button>
          );
        })}
      </div>
      {selected && (
        <>
          <hr className="kb-divider" />
          <SessionCard def={def} session={selected} dateObj={sessionDate(state, programId, selected)}
            log={getLog(state, programId, selected.key) || { completed: false, rpe: null }}
            onSetLog={(patch) => onSetLog(selected.key, patch)} />
        </>
      )}
    </>
  );
}

function ProgressTab({ state, programId }: { state: BlockAppState; programId: string }) {
  const def = PROGRAM_DEFS[programId];
  const stats = programStats(state, programId);
  const sessions = sessionsFor(programId);

  const weekVals = [];
  for (let w = 1; w <= def.weeks; w++) {
    const wsessions = sessions.filter((s) => s.week === w);
    const wdone = wsessions.filter((s) => getLog(state, programId, s.key)?.completed).length;
    const wpast = wsessions.filter((s) => sessionDate(state, programId, s) <= todayMidnight()).length;
    const pct = wpast ? Math.round((100 * wdone) / wpast) : 0;
    weekVals.push({ v: pct, label: 'S' + w });
  }

  const heatWeeks = [];
  for (let wk = 1; wk <= def.weeks; wk++) {
    const cells = sessions.filter((s) => s.week === wk).map((s) => {
      const d = sessionDate(state, programId, s);
      const log = getLog(state, programId, s.key);
      const iso = isoDate(d);
      let cls = log?.completed ? 'done' : d < todayMidnight() ? 'missed' : '';
      if (iso === isoDate(todayMidnight())) cls += ' today';
      return <button key={s.key} className={`kb-heat-cell ${cls}`} title={`${DOW_FULL[s.weekdayIso - 1]} ${d.getDate()}/${d.getMonth() + 1}`} />;
    });
    heatWeeks.push(<div className="kb-heat-week" key={wk}><div className="kb-heat-label">S{wk}</div>{cells}</div>);
  }

  return (
    <>
      <div className="kb-stat-grid">
        <div className="kb-stat-tile"><div className="kb-stat-num kb-mono">{stats.adherence}%</div><div className="kb-stat-label">Adherencia</div></div>
        <div className="kb-stat-tile"><div className="kb-stat-num kb-mono">{stats.streak}</div><div className="kb-stat-label">Racha (sesiones)</div></div>
        <div className="kb-stat-tile"><div className="kb-stat-num kb-mono">{stats.completedCount}/{stats.totalSessions}</div><div className="kb-stat-label">Sesiones hechas</div></div>
        <div className="kb-stat-tile"><div className="kb-stat-num kb-mono">{stats.daysRemaining}</div><div className="kb-stat-label">Días para acabar</div></div>
      </div>
      <WeeklyBarChart values={weekVals} />
      {def.hasTestProtocol && <TestComparisonCard result={testComparison(state, programId)} />}
      <div className="kb-card">
        <div className="kb-eyebrow" style={{ marginBottom: 10 }}>Calendario del bloque</div>
        <div className="kb-legend-row">
          <div className="kb-legend-item"><span className="kb-legend-swatch" style={{ background: 'var(--kb-good)' }} />Completada</div>
          <div className="kb-legend-item"><span className="kb-legend-swatch" style={{ background: 'var(--kb-critical)' }} />No registrada</div>
          <div className="kb-legend-item"><span className="kb-legend-swatch" style={{ background: 'var(--kb-line)' }} />Pendiente</div>
        </div>
        <div className="kb-heatmap">{heatWeeks}</div>
      </div>
    </>
  );
}

function SettingsTab({ state, update, programId }: { state: BlockAppState; update: Props['update']; programId: string }) {
  const ids = Object.keys(state.unlocked);
  const [resetArmed, setResetArmed] = useState(false);
  const activeDef = PROGRAM_DEFS[programId];
  const extras = PROGRAM_EXTRAS[programId];

  return (
    <>
      <div className="kb-card">
        <div className="kb-eyebrow" style={{ marginBottom: 8 }}>Tus programas</div>
        {ids.map((pid) => {
          const def = PROGRAM_DEFS[pid];
          const stats = programStats(state, pid);
          const isActive = pid === programId;
          return (
            <button
              key={pid}
              className="kb-kv"
              style={{
                width: '100%', textAlign: 'left', border: 'none', borderRadius: 8,
                background: isActive ? 'var(--kb-line)' : 'transparent',
                cursor: ids.length > 1 ? 'pointer' : 'default',
              }}
              onClick={() => { if (ids.length > 1) update((s) => ({ ...s, activeProgram: pid })); }}
            >
              <span className="kb-k">{isActive ? '● ' : ''}{def.name}</span>
              <span className="kb-v">{stats.completedCount}/{stats.totalSessions} · {stats.adherence}%</span>
            </button>
          );
        })}
        {ids.length > 1 && <p className="kb-faint" style={{ fontSize: 11, marginTop: 8 }}>Toca un programa para verlo en Hoy, Semana y Progreso.</p>}
      </div>

      <div className="kb-card">
        <div className="kb-eyebrow" style={{ marginBottom: 10 }}>Apariencia</div>
        <div style={{ display: 'flex', gap: 8 }}>
          {(['auto', 'light', 'dark'] as const).map((t) => (
            <button key={t} className={`kb-btn-sm ${state.theme === t ? 'kb-btn-primary' : 'kb-btn-ghost'}`} style={{ flex: 1 }}
              onClick={() => update((s) => ({ ...s, theme: t }))}>
              {{ auto: 'Auto', light: 'Claro', dark: 'Oscuro' }[t]}
            </button>
          ))}
        </div>
      </div>

      {extras && (
        <>
          <div className="kb-card">
            <div className="kb-eyebrow" style={{ marginBottom: 8 }}>Calentamiento estándar · {activeDef.short}</div>
            <p className="kb-muted" style={{ fontSize: 12.5 }}>El mismo todos los días · 8-10 minutos.</p>
            <ul className="kb-linelist">{extras.warmupStandard.map((l, i) => <li key={i}>{i + 1}. {l}</li>)}</ul>
            <p className="kb-faint" style={{ fontSize: 11.5, marginTop: 8 }}>→ {extras.warmupNote}</p>
          </div>

          <div className="kb-card">
            <div className="kb-eyebrow" style={{ marginBottom: 4 }}>Sustituciones · si no tienes el material</div>
            <p className="kb-muted" style={{ fontSize: 12.5 }}>Usa el equivalente y anótalo. Mantenlo todo el ciclo.</p>
            {extras.substitutions.map((r, i) => (
              <div key={i} style={{ padding: '10px 0', borderTop: i ? '1px solid var(--kb-line)' : 'none' }}>
                <div style={{ fontWeight: 700, fontSize: 12.5, marginBottom: 4 }}>{r.station}</div>
                <div className="kb-muted" style={{ fontSize: 12.5 }}>Sustituto: {r.main}</div>
                <div className="kb-faint" style={{ fontSize: 11.5 }}>Alternativa: {r.alt}</div>
              </div>
            ))}
          </div>

          <div className="kb-card">
            <div className="kb-eyebrow" style={{ marginBottom: 4 }}>Notas del coach · {activeDef.short}</div>
            {extras.coachNotes.map((n, i) => (
              <div key={i} style={{ padding: '10px 0', borderTop: i ? '1px solid var(--kb-line)' : 'none' }}>
                <div style={{ fontWeight: 700, fontSize: 12.5, marginBottom: 3 }}>{n.title}</div>
                <div className="kb-muted" style={{ fontSize: 12.5, lineHeight: 1.5 }}>{n.text}</div>
              </div>
            ))}
          </div>
        </>
      )}

      <div className="kb-card">
        <div className="kb-eyebrow" style={{ marginBottom: 10 }}>Acerca de Kairos</div>
        <p className="kb-muted">
          Tus datos se guardan en este dispositivo (sin servidor). Si compraste con Lemon Squeezy,
          tu código sigue siendo válido para activar el programa en otro dispositivo si lo necesitas.
        </p>
      </div>

      <button className="kb-btn kb-btn-danger" onClick={() => {
        if (resetArmed) {
          try { localStorage.removeItem(STORE_KEY); } catch { /* ignore */ }
          update(() => ({ unlocked: {}, activeProgram: null, logs: {}, theme: state.theme, hideInstallHint: false }));
        } else {
          setResetArmed(true);
        }
      }}>
        {resetArmed ? '¿Seguro? Toca de nuevo para borrar todo' : 'Reiniciar (borra todos los datos)'}
      </button>
    </>
  );
}
