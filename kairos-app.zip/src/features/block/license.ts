// Cliente para /api/license — un pequeño proxy serverless hacia la License API
// de Lemon Squeezy (evita depender de CORS del navegador y permite validar
// server-side que la licencia pertenece al producto correcto).

export type LicenseAction = 'activate' | 'validate' | 'deactivate';

export interface LicenseApiResult {
  ok: boolean;
  status?: string;
  instanceId?: string;
  /** A qué programa pertenece esta licencia (resuelto en el servidor vía
   *  LEMONSQUEEZY_PRODUCT_MAP). Ausente si el servidor no tiene esa config. */
  programId?: string;
  error?: string;
}

const INSTANCE_NAME = 'kairos-app-web';

export async function callLicenseApi(action: LicenseAction, licenseKey: string, instanceId?: string): Promise<LicenseApiResult> {
  try {
    const resp = await fetch('/api/license', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action, license_key: licenseKey.trim(), instance_name: INSTANCE_NAME, instance_id: instanceId }),
    });
    const data = await resp.json().catch(() => ({}));

    if (action === 'activate') {
      if (data && data.activated) {
        return { ok: true, status: data.license_key?.status, instanceId: data.instance?.id, programId: data.internal_program_id };
      }
      return { ok: false, error: data?.error || 'No se pudo activar el código. Revisa que esté bien escrito.' };
    }
    if (action === 'validate') {
      if (data && data.valid) {
        return { ok: true, status: data.license_key?.status, programId: data.internal_program_id };
      }
      return { ok: false, error: data?.error || 'Este código ya no es válido.' };
    }
    if (action === 'deactivate') {
      return { ok: !!(data && data.deactivated) };
    }
    return { ok: false, error: 'Acción desconocida.' };
  } catch {
    return { ok: false, error: 'No se pudo conectar. Revisa tu conexión e inténtalo de nuevo.' };
  }
}
