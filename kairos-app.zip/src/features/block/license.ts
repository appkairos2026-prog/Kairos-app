// Cliente para /api/license — un pequeño proxy serverless hacia la License API
// de Lemon Squeezy (evita depender de CORS del navegador y permite validar
// server-side que la licencia pertenece al producto correcto).

export type LicenseAction = 'activate' | 'validate' | 'deactivate';

export interface LicenseApiResult {
  ok: boolean;
  status?: string;
  instanceId?: string;
  /** A qué programa pertenece esta licencia (resuelto en el servidor vía
   *  LEMONSQUEEZY_PRODUCT_MAP). Ausente si el servidor no tiene esa config. */
  programId?: string;
  error?: string;
}

const INSTANCE_NAME = 'kairos-app-web';

// Lemon Squeezy devuelve sus errores en inglés y con redacción interna
// (p. ej. "This license key has reached the maximum number of activations
// allowed."). Enseñar eso tal cual confunde más que ayuda, así que
// traducimos los casos conocidos a un mensaje claro y accionable en
// español. Si el texto no coincide con ninguno, usamos un mensaje genérico
// en vez de mostrar el inglés sin traducir.
function translateActivationError(raw: string | undefined | null, fallback: string): string {
  const text = (raw || '').toLowerCase();
  if (!text) return fallback;
  if (text.includes('too_many_requests')) {
    return 'Demasiados intentos seguidos. Espera unos minutos y vuelve a probar.';
  }
  if (text.includes('activation') && (text.includes('limit') || text.includes('maximum') || text.includes('already been activated'))) {
    return 'Este código ya se activó en el máximo de dispositivos permitidos. Escríbenos indicando tu email de compra y te ayudamos a moverlo de dispositivo.';
  }
  if (text.includes('expired')) {
    return 'Este código ha caducado. Escríbenos indicando tu email de compra para revisarlo.';
  }
  if (text.includes('disabled') || text.includes('not activatable') || text.includes('inactive')) {
    return 'Este código no está activo. Escríbenos indicando tu email de compra para revisarlo.';
  }
  if (text.includes('does not exist') || text.includes('not found')) {
    return 'No encontramos ese código. Revisa mayúsculas y guiones, o cópialo directamente del email de compra.';
  }
  return fallback;
}

export async function callLicenseApi(action: LicenseAction, licenseKey: string, instanceId?: string): Promise<LicenseApiResult> {
  try {
    const resp = await fetch('/api/license', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action, license_key: licenseKey.trim(), instance_name: INSTANCE_NAME, instance_id: instanceId }),
    });
    const data = await resp.json().catch(() => ({}));

    if (action === 'activate') {
      if (data && data.activated) {
        return { ok: true, status: data.license_key?.status, instanceId: data.instance?.id, programId: data.internal_program_id };
      }
      return { ok: false, error: translateActivationError(data?.error, 'No se pudo activar el código. Revisa que esté bien escrito.') };
    }
    if (action === 'validate') {
      if (data && data.valid) {
        return { ok: true, status: data.license_key?.status, programId: data.internal_program_id };
      }
      return { ok: false, error: translateActivationError(data?.error, 'Este código ya no es válido.') };
    }
    if (action === 'deactivate') {
      return { ok: !!(data && data.deactivated) };
    }
    return { ok: false, error: 'Acción desconocida.' };
  } catch {
    return { ok: false, error: 'No se pudo conectar. Revisa tu conexión e inténtalo de nuevo.' };
  }
}
