// Paso de post-build (se ejecuta después de "vite build", ver package.json):
// genera una página HTML estática y autocontenida por cada programa dentro
// de dist/programas/<id>/index.html, a partir de la MISMA dist/index.html
// que acaba de compilar Vite (mismos <script>/<link> con hash, misma app).
//
// Por qué: Kairos es una SPA sin SSR. Sin este paso, todas las rutas
// devolverían el mismo <title>/meta genérico, lo cual es un problema para:
//   - Google y buscadores (title/description por página, aunque ejecuten JS)
//   - Bots de redes sociales (Instagram/WhatsApp/Twitter/Facebook) que NO
//     ejecutan JavaScript y solo leen las etiquetas <meta> del HTML crudo.
// Esta solución genera HTML real por URL sin tocar la arquitectura de la
// app: la misma app React se sigue montando igual en cada página.
//
// También genera dist/sitemap.xml a partir de la misma lista de programas
// (PROGRAM_ORDER), para que nunca se pueda quedar desactualizado a mano.

import { readFileSync, writeFileSync, mkdirSync } from 'fs';
import { resolve, dirname } from 'path';
import { fileURLToPath } from 'url';
import { PROGRAM_DEFS, PROGRAM_PRODUCTS, PROGRAM_EXTRAS, PROGRAM_ORDER } from '../src/features/block/data';
import { PROGRAM_LANDING_COPY, UNIVERSAL_FAQ, HOME_FAQ, type FaqItem } from '../src/features/block/landingContent';

const __dirname = dirname(fileURLToPath(import.meta.url));
const DIST = resolve(__dirname, '..', 'dist');
const SITE_URL = 'https://kairostraining.es';
const OG_IMAGE = `${SITE_URL}/icons/icon-512.png`;
const SITE_NAME = 'Kairos';

function esc(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function faqSchema(items: FaqItem[]) {
  return {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: items.map((f) => ({
      '@type': 'Question',
      name: f.q,
      acceptedAnswer: { '@type': 'Answer', text: f.a },
    })),
  };
}

function priceToAmount(priceLabel: string): string {
  const digits = priceLabel.match(/\d+/);
  return digits ? `${digits[0]}.00` : '0.00';
}

function scriptTag(obj: unknown): string {
  return `<script type="application/ld+json">${JSON.stringify(obj)}</script>`;
}

interface HeadOpts {
  title: string;
  description: string;
  canonical: string;
  ogType: 'website' | 'product';
  jsonLd: string[];
}

// Sustituye <title>/<meta description> del template y añade canonical + OG +
// Twitter Card + JSON-LD justo antes de </head>. El resto del <head>
// (charset, viewport, manifest, iconos, theme-color) se conserva tal cual.
function buildHead(template: string, opts: HeadOpts): string {
  let html = template;
  html = html.replace(/<title>.*?<\/title>/s, `<title>${esc(opts.title)}</title>`);
  html = html.replace(/<meta name="description"[^>]*>/, `<meta name="description" content="${esc(opts.description)}" />`);

  const tags = [
    `<link rel="canonical" href="${opts.canonical}" />`,
    `<meta property="og:site_name" content="${esc(SITE_NAME)}" />`,
    `<meta property="og:type" content="${opts.ogType}" />`,
    `<meta property="og:title" content="${esc(opts.title)}" />`,
    `<meta property="og:description" content="${esc(opts.description)}" />`,
    `<meta property="og:url" content="${opts.canonical}" />`,
    `<meta property="og:image" content="${OG_IMAGE}" />`,
    `<meta property="og:image:width" content="512" />`,
    `<meta property="og:image:height" content="512" />`,
    `<meta property="og:image:alt" content="Logo de Kairos" />`,
    `<meta property="og:locale" content="es_ES" />`,
    `<meta name="twitter:card" content="summary_large_image" />`,
    `<meta name="twitter:title" content="${esc(opts.title)}" />`,
    `<meta name="twitter:description" content="${esc(opts.description)}" />`,
    `<meta name="twitter:image" content="${OG_IMAGE}" />`,
    ...opts.jsonLd,
  ].join('\n    ');

  return html.replace('</head>', `    ${tags}\n  </head>`);
}

function injectNoscript(html: string, bodyHtml: string): string {
  const noscript = `<noscript>${bodyHtml}</noscript>`;
  return html.replace('<div id="root">', `${noscript}\n    <div id="root">`);
}

function writeHtml(outPath: string, html: string) {
  mkdirSync(dirname(outPath), { recursive: true });
  writeFileSync(outPath, html, 'utf8');
  console.log('SEO:', outPath.replace(DIST, ''));
}

const template = readFileSync(resolve(DIST, 'index.html'), 'utf8');

// ---------------------------------------------------------------------
// HOME
// ---------------------------------------------------------------------
const homeDescription = 'Siete programas de entrenamiento de 6 a 8 semanas, cada uno para un objetivo concreto: primera dominada, ring muscle-up, mejorar tus estaciones o tu carrera en Hyrox, fuerza en los básicos. Pago único, activación al momento, entrena sin conexión.';

const homeJsonLd = [
  scriptTag({
    '@context': 'https://schema.org',
    '@type': 'WebSite',
    name: SITE_NAME,
    url: `${SITE_URL}/`,
    description: homeDescription,
  }),
  scriptTag({
    '@context': 'https://schema.org',
    '@type': 'ItemList',
    itemListElement: PROGRAM_ORDER.map((id, i) => ({
      '@type': 'ListItem',
      position: i + 1,
      url: `${SITE_URL}/programas/${id}`,
      name: PROGRAM_DEFS[id].name,
    })),
  }),
  scriptTag(faqSchema(HOME_FAQ)),
];

const homeNoscript = [
  '<h1>Elige tu objetivo. Entrénalo.</h1>',
  `<p>${esc(homeDescription)}</p>`,
  '<ul>',
  ...PROGRAM_ORDER.map((id) => {
    const def = PROGRAM_DEFS[id];
    const product = PROGRAM_PRODUCTS[id];
    return `<li><a href="/programas/${id}">${esc(def.name)} — ${esc(product.priceLabel)}</a></li>`;
  }),
  '</ul>',
].join('');

let homeHtml = buildHead(template, {
  title: 'Kairos — Entrenamiento por objetivos',
  description: homeDescription,
  canonical: `${SITE_URL}/`,
  ogType: 'website',
  jsonLd: homeJsonLd,
});
homeHtml = injectNoscript(homeHtml, homeNoscript);
writeHtml(resolve(DIST, 'index.html'), homeHtml);

// ---------------------------------------------------------------------
// PÁGINAS DE PRODUCTO — dist/programas/<id>/index.html
// ---------------------------------------------------------------------
for (const id of PROGRAM_ORDER) {
  const def = PROGRAM_DEFS[id];
  const product = PROGRAM_PRODUCTS[id];
  const copy = PROGRAM_LANDING_COPY[id];
  const extras = PROGRAM_EXTRAS[id];
  const canonical = `${SITE_URL}/programas/${id}`;
  const title = `${def.name} — Kairos`;
  const description = product.pitch;

  const productJsonLd = [
    scriptTag({
      '@context': 'https://schema.org',
      '@type': 'Product',
      name: def.name,
      description: product.pitch,
      url: canonical,
      brand: { '@type': 'Brand', name: SITE_NAME },
      offers: {
        '@type': 'Offer',
        url: product.checkoutUrl,
        price: priceToAmount(product.priceLabel),
        priceCurrency: 'EUR',
        availability: 'https://schema.org/InStock',
      },
    }),
    scriptTag(faqSchema([copy.specificFaq, ...UNIVERSAL_FAQ])),
  ];

  const noscriptParts = [
    `<h1>${esc(copy.resultTitle)}</h1>`,
    `<p>${esc(product.pitch)}</p>`,
    `<p>${esc(copy.forWhom)}</p>`,
    `<p>Precio: ${esc(product.priceLabel)} (pago único). Duración: ${def.weeks} semanas, 3 sesiones por semana.</p>`,
  ];
  if (extras?.warmupNote) noscriptParts.push(`<p>${esc(extras.warmupNote)}</p>`);
  noscriptParts.push(`<p><a href="${product.checkoutUrl}">Comprar programa</a></p>`);
  noscriptParts.push('<p><a href="/">Ver los 7 programas de Kairos</a></p>');

  let html = buildHead(template, {
    title,
    description,
    canonical,
    ogType: 'product',
    jsonLd: productJsonLd,
  });
  html = injectNoscript(html, noscriptParts.join(''));
  writeHtml(resolve(DIST, 'programas', id, 'index.html'), html);
}

// ---------------------------------------------------------------------
// sitemap.xml
// ---------------------------------------------------------------------
const today = new Date().toISOString().slice(0, 10);
const urls = [
  { loc: `${SITE_URL}/`, priority: '1.0' },
  ...PROGRAM_ORDER.map((id) => ({ loc: `${SITE_URL}/programas/${id}`, priority: '0.8' })),
];
const sitemap = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls
  .map((u) => `  <url>\n    <loc>${u.loc}</loc>\n    <lastmod>${today}</lastmod>\n    <priority>${u.priority}</priority>\n  </url>`)
  .join('\n')}\n</urlset>\n`;
writeFileSync(resolve(DIST, 'sitemap.xml'), sitemap, 'utf8');
console.log('SEO: /sitemap.xml');

console.log(`SEO: listo — home + ${PROGRAM_ORDER.length} páginas de producto + sitemap.xml`);
