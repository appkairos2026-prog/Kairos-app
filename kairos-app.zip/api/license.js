// Vercel serverless function — proxy hacia la License API de Lemon Squeezy.
// Evita depender del soporte CORS del navegador y permite comprobar en
// servidor que la licencia pertenece a uno de nuestros productos antes de
// devolver "activado" al cliente, y le dice al cliente A QUÉ PROGRAMA
// pertenece esa licencia (ahora vendemos 7 productos, no solo Hyrox).
//
// Config (Vercel → Settings → Environment Variables):
//   LEMONSQUEEZY_PRODUCT_MAP — JSON con la forma {"<product_id>":"<programId>"},
//     con los 7 productos actuales, por ejemplo:
//     {"111111":"hyrox8","222222":"hyrox-carrera","333333":"cf-fuerza",
//      "444444":"cf-primera-dominada","555555":"cf-gim-nivel1",
//      "666666":"cf-gim-nivel2","777777":"cf-anillas-rmu"}
//     Los product_id salen de Lemon Squeezy → cada producto → Product ID.
//
//   IMPORTANTE: si esta variable NO está configurada (o le falta algún
//   producto), el cliente (BlockGate.tsx) cae por compatibilidad en
//   'hyrox8' para CUALQUIER código que active correctamente — es decir,
//   alguien que compró otro programa vería desbloqueado Hyrox por error.
//   Con 7 productos a la venta esta variable ya no es opcional: hay que
//   configurarla con los 7 Product ID reales antes de lanzar tráfico de pago.
//
//   LEMONSQUEEZY_HYROX_PRODUCT_ID — variable antigua, se sigue soportando por
//     compatibilidad si LEMONSQUEEZY_PRODUCT_MAP no está definida (mapea ese
//     único product_id a 'hyrox8'). No cubre los otros 6 programas.

const ALLOWED_ACTIONS = ['activate', 'validate', 'deactivate'];

// ---------------------------------------------------------------------
// Rate limit básico por IP (en memoria). En serverless cada instancia
// tiene su propia memoria, así que esto no es un límite global exacto,
// pero corta en seco el abuso barato (fuerza bruta de códigos, hammering
// de la API de Lemon Squeezy) sin necesitar infraestructura extra.
// ---------------------------------------------------------------------
const RATE_WINDOW_MS = 10 * 60 * 1000; // 10 minutos
const RATE_MAX = 30;                   // 30 peticiones por IP y ventana
const rateBuckets = new Map();

function clientIp(req) {
  const fwd = req.headers['x-forwarded-for'];
  if (typeof fwd === 'string' && fwd.length) return fwd.split(',')[0].trim().slice(0, 64);
  return (req.socket && req.socket.remoteAddress) || 'unknown';
}

function rateLimited(ip) {
  const now = Date.now();
  if (rateBuckets.size > 2000) {
    for (const [k, v] of rateBuckets) { if (v.reset < now) rateBuckets.delete(k); }
  }
  const bucket = rateBuckets.get(ip);
  if (!bucket || bucket.reset < now) {
    rateBuckets.set(ip, { count: 1, reset: now + RATE_WINDOW_MS });
    return false;
  }
  bucket.count += 1;
  return bucket.count > RATE_MAX;
}

// Deja pasar al cliente SOLO los campos que la app necesita. La respuesta
// cruda de Lemon Squeezy incluye datos del comprador (nombre, email) en
// `meta`: no deben viajar a cualquiera que envíe un código válido/robado.
function sanitizeResponse(data) {
  const out = {};
  if (data && typeof data === 'object') {
    if ('activated' in data) out.activated = !!data.activated;
    if ('valid' in data) out.valid = !!data.valid;
    if ('deactivated' in data) out.deactivated = !!data.deactivated;
    if (typeof data.error === 'string') out.error = data.error.slice(0, 300);
    if (data.license_key && typeof data.license_key.status === 'string') {
      out.license_key = { status: data.license_key.status };
    }
    if (data.instance && data.instance.id != null) {
      out.instance = { id: String(data.instance.id) };
    }
    if (typeof data.internal_program_id === 'string') {
      out.internal_program_id = data.internal_program_id;
    }
  }
  return out;
}

function resolveProductMap() {
  const raw = process.env.LEMONSQUEEZY_PRODUCT_MAP;
  if (raw) {
    try {
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed === 'object') return parsed;
    } catch { /* JSON mal formado — se ignora, mejor no bloquear activaciones */ }
  }
  if (process.env.LEMONSQUEEZY_HYROX_PRODUCT_ID) {
    return { [process.env.LEMONSQUEEZY_HYROX_PRODUCT_ID]: 'hyrox8' };
  }
  return null;
}

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'method_not_allowed' });
    return;
  }

  if (rateLimited(clientIp(req))) {
    res.setHeader('Retry-After', '600');
    res.status(429).json({ error: 'too_many_requests' });
    return;
  }

  let body = req.body;
  if (typeof body === 'string') {
    try { body = JSON.parse(body); } catch { body = {}; }
  }
  const { action, license_key, instance_name, instance_id } = body || {};

  if (!ALLOWED_ACTIONS.includes(action) || !license_key || typeof license_key !== 'string'
      || license_key.length > 128 || (instance_id != null && String(instance_id).length > 128)) {
    res.status(400).json({ error: 'bad_request' });
    return;
  }

  const params = new URLSearchParams();
  params.set('license_key', license_key.trim());
  if (action === 'activate') {
    params.set('instance_name', (instance_name || 'kairos-app').slice(0, 100));
  } else if (instance_id) {
    params.set('instance_id', String(instance_id));
  }

  try {
    const upstream = await fetch(`https://api.lemonsqueezy.com/v1/licenses/${action}`, {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: params.toString(),
    });
    const data = await upstream.json();

    const productMap = resolveProductMap();
    if (productMap) {
      const productId = data && data.meta && data.meta.product_id != null ? String(data.meta.product_id) : null;
      if (productId == null || !productMap[productId]) {
        res.status(200).json({ activated: false, valid: false, error: 'Este código no corresponde a ninguno de nuestros programas.' });
        return;
      }
      data.internal_program_id = productMap[productId];
    }

    res.status(upstream.status).json(sanitizeResponse(data));
  } catch {
    res.status(502).json({ error: 'upstream_error' });
  }
}
