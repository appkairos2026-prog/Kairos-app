// Vercel serverless function — proxy hacia la License API de Lemon Squeezy.
// Evita depender del soporte CORS del navegador y permite comprobar en
// servidor que la licencia pertenece a uno de nuestros productos antes de
// devolver "activado" al cliente, y le dice al cliente A QUÉ PROGRAMA
// pertenece esa licencia (ahora vendemos 6 productos, no solo Hyrox).
//
// Config (Vercel → Settings → Environment Variables):
//   LEMONSQUEEZY_PRODUCT_MAP — JSON con la forma {"<product_id>":"<programId>"},
//     por ejemplo:
//     {"111111":"hyrox8","222222":"cf-fuerza","333333":"cf-primera-dominada",
//      "444444":"cf-gim-nivel1","555555":"cf-gim-nivel2","666666":"cf-anillas-rmu"}
//     Los product_id salen de Lemon Squeezy → cada producto → Product ID.
//   LEMONSQUEEZY_HYROX_PRODUCT_ID — variable antigua, se sigue soportando por
//     compatibilidad si LEMONSQUEEZY_PRODUCT_MAP no está definida (mapea ese
//     único product_id a 'hyrox8').

const ALLOWED_ACTIONS = ['activate', 'validate', 'deactivate'];

function resolveProductMap() {
  const raw = process.env.LEMONSQUEEZY_PRODUCT_MAP;
  if (raw) {
    try {
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed === 'object') return parsed;
    } catch { /* JSON mal formado — se ignora, mejor no bloquear activaciones */ }
  }
  if (process.env.LEMONSQUEEZY_HYROX_PRODUCT_ID) {
    return { [process.env.LEMONSQUEEZY_HYROX_PRODUCT_ID]: 'hyrox8' };
  }
  return null;
}

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'method_not_allowed' });
    return;
  }

  let body = req.body;
  if (typeof body === 'string') {
    try { body = JSON.parse(body); } catch { body = {}; }
  }
  const { action, license_key, instance_name, instance_id } = body || {};

  if (!ALLOWED_ACTIONS.includes(action) || !license_key || typeof license_key !== 'string') {
    res.status(400).json({ error: 'bad_request' });
    return;
  }

  const params = new URLSearchParams();
  params.set('license_key', license_key.trim());
  if (action === 'activate') {
    params.set('instance_name', (instance_name || 'kairos-app').slice(0, 100));
  } else if (instance_id) {
    params.set('instance_id', String(instance_id));
  }

  try {
    const upstream = await fetch(`https://api.lemonsqueezy.com/v1/licenses/${action}`, {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: params.toString(),
    });
    const data = await upstream.json();

    const productMap = resolveProductMap();
    if (productMap) {
      const productId = data && data.meta && data.meta.product_id != null ? String(data.meta.product_id) : null;
      if (productId == null || !productMap[productId]) {
        res.status(200).json({ activated: false, valid: false, error: 'Este código no corresponde a ninguno de nuestros programas.' });
        return;
      }
      data.internal_program_id = productMap[productId];
    }

    res.status(upstream.status).json(data);
  } catch (err) {
    res.status(502).json({ error: 'upstream_error', message: String(err && err.message || err) });
  }
}
